"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import Link from "next/link"
import { useIsMobile } from "@/hooks/use-mobile"
import { t } from "@/lib/i18n"

// ── Ambient neural background ─────────────────────────────────────────────────
function BgNeuralCanvas({ opacity = 0.07, nodeCount = 28 }: { opacity?: number; nodeCount?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rafRef = useRef<number>()
  const nodesRef = useRef<{ x: number; y: number; vx: number; vy: number; r: number }[]>([])
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")!
    let W = 0, H = 0
    function resize() {
      W = canvas.offsetWidth; H = canvas.offsetHeight
      canvas.width = W; canvas.height = H
      nodesRef.current = Array.from({ length: nodeCount }, () => ({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - 0.5) * 0.28, vy: (Math.random() - 0.5) * 0.28,
        r: Math.random() * 2.5 + 1,
      }))
    }
    function draw() {
      ctx.clearRect(0, 0, W, H)
      const nodes = nodesRef.current
      nodes.forEach(n => {
        n.x += n.vx; n.y += n.vy
        if (n.x < 0 || n.x > W) n.vx *= -1
        if (n.y < 0 || n.y > H) n.vy *= -1
      })
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < 175) {
            ctx.beginPath(); ctx.moveTo(nodes[i].x, nodes[i].y); ctx.lineTo(nodes[j].x, nodes[j].y)
            ctx.strokeStyle = `rgba(220,120,90,${(1 - dist / 175) * 0.11})`; ctx.lineWidth = 0.6; ctx.stroke()
          }
        }
      }
      nodes.forEach(n => {
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(220,120,90,0.10)`; ctx.fill()
      })
      rafRef.current = requestAnimationFrame(draw)
    }
    resize()
    window.addEventListener("resize", resize)
    rafRef.current = requestAnimationFrame(draw)
    return () => { window.removeEventListener("resize", resize); if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [nodeCount])
  return <canvas ref={canvasRef} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity, pointerEvents: "none", zIndex: 0 }} />
}

const BG = "#0d0d12"
const BG2 = "#111118"
const BORDER = "rgba(255,255,255,0.06)"
const os = "'Oswald', sans-serif"
const it = "'Inter', sans-serif"
const ACCENT = "#dc785a"

const TG_URL = "https://t.me/generationai_support?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5%2C%20%D0%BC%D0%B5%D0%BD%D1%8F%20%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D1%83%D0%B5%D1%82%20%D1%82%D1%80%D0%B5%D0%BD%D0%B8%D0%BD%D0%B3%20%D0%BF%D0%BE%20%D0%B2%D0%BD%D0%B5%D0%B4%D1%80%D0%B5%D0%BD%D0%B8%D1%8E%20AI%20%D0%B2%20%D0%B1%D0%B8%D0%B7%D0%BD%D0%B5%D1%81%2C%20%D1%85%D0%BE%D1%82%D0%B5%D0%BB%D0%BE%D1%81%D1%8C%20%D0%B1%D1%8B%20%D0%BE%D0%B1%D1%81%D1%83%D0%B4%D0%B8%D1%82%D1%8C%20%D1%81%D0%BE%D1%82%D1%80%D1%83%D0%B4%D0%BD%D0%B8%D1%87%D0%B5%D1%81%D1%82%D0%B2%D0%BE"
const FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLSdDgJrFvkpzFqPBl06DxkU4hEuGbVkMlXJJWuykTZ3MjDh3fA/viewform?usp=header"

// ── Wistia embed ──────────────────────────────────────────────────────────────
function WistiaPlayer({ mediaId }: { mediaId: string }) {
  useEffect(() => {
    if (!document.querySelector('script[src*="wistia.com/player.js"]')) {
      const s = document.createElement("script"); s.src = "https://fast.wistia.com/player.js"; s.async = true; document.head.appendChild(s)
    }
    const embedId = `${mediaId}.js`
    if (!document.querySelector(`script[src*="${embedId}"]`)) {
      const s2 = document.createElement("script"); s2.src = `https://fast.wistia.com/embed/${mediaId}.js`; s2.async = true; s2.setAttribute("type", "module"); document.head.appendChild(s2)
    }
  }, [mediaId])
  return (
    <div style={{ position: "absolute", inset: 0 }}
      dangerouslySetInnerHTML={{ __html: `<wistia-player media-id="${mediaId}" autoplay="true" muted="true" playsinline="true" controls="false" aspect="0.5625" style="width:100%;height:100%;display:block;object-fit:cover;"></wistia-player>` }}
    />
  )
}

// ── Logo rows ─────────────────────────────────────────────────────────────────
const LOGOS_ROW1 = [
  { name: "Thomson Reuters", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA1-pRdbrUmffXcJ8nMfZO6JHTxSqZkedo.png" },
  { name: "RR Donnelley", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA2-cON2CNlfKLdR8LjpxZdi7ggScixtRb.jpg" },
  { name: "Dash", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA3-3DJwHWsPDC5w5YzPsGw6st3LrGy8kQ.png" },
  { name: "LUUP", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA4-9jEmwJaJ64cWj7cvLXyfv1pxqxq4Kg.png" },
  { name: "Kantar", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA5-O2SwfrY1APSqvmjkqOMRLZQS8l7M14.png" },
  { name: "Nestlé", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA6-RsoCgOczYVF4UKX8SNT66GIYCVyPrf.jpg" },
  { name: "Just Eat", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA7-gr6vsgrCWtyvGxeBCKJV3OsPi5LPHo.png" },
  { name: "Unisport", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA8-Z349UDh3BID5GIYU8QvC9Z5lwbp2ZS.png" },
  { name: "METRO", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA9-cxUFk9mV4ULoAv9Lr526fOpsJd3DMl.png" },
  { name: "Dev.by", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA15-gal0xjE7X6N0LJIMmPk8t7rLSFnS26.png" },
  { name: "BT", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA21-1L2uR6Eh4iwOCkIiMeQMNcISODp0mB.png" },
  { name: "Topcon", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA22-ikcCHnW8uH3krhu691MWpJNQpgr6GU.png" },
  { name: "BSH", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA23-XUxnzRTELrudWbIwom850IafCwfxLl.png" },
  { name: "Facts", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA24-cPZ3GZ83jUmkmO90AGpxxHY0eU3IVT.png" },
  { name: "EDC", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA25-7y5MtTmVB584ATp5up9h1IjN6xLVlx.png" },
  { name: "SBTech", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA26-ghSqGosuIki59v0xM2bwoaf838xsx0.png" },
  { name: "Playtika", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA29-o846U4VbsrgxjGbX6SUoCzyO2wS97V.png" },
]
const LOGOS_ROW2 = [
  { name: "OneOffixx", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA11-0iqE35cjBdCDeHo0HBGNNU6BAhaBri.png" },
  { name: "Bipper", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA12-q7PxruEh5Bym0HkX92havhFtj9skD1.png" },
  { name: "Solarwinds", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA13-J1Ni8A4uUuJ7aJgb2sm4Rvsznc0C9f.png" },
  { name: "Bonial", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA18-L0ewC9S3ueHoHHw4pkF7c57v4L9jtR.png" },
  { name: "ebuilders", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA19-YThAYjXyjSr4tNJ8WzE69Mecj4O4xV.png" },
  { name: "Wargaming", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA31-C2tNuTqP9zzI9ay0GeFaq0CO5VpOEB.png" },
  { name: "Namecheap", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA32-XGkcbnugezttgzSLEJspGB8yoBYrsv.png" },
  { name: "Intellica", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA33-Ey2mlLpQQvFSmLsSYZRbHgVuyj5kkI.png" },
  { name: "Instinctools", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA34-fERfqrwVnrmcX0jFAy9peVrFA2ZtWo.png" },
  { name: "Velcom", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA36-XSbjAUeXOrf6yePGQLCclnlORt7TaQ.png" },
  { name: "Magticom", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA37-9CYBXAzoBbSeSwyGfENgT5Qm0HxrvD.png" },
  { name: "TBC Bank", src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA38-VPKegLHeSsZ1GnrtTDbooeZ9MOwZRM.jpg" },
]

const trainerPhotos = {
  anton: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%B0%D0%BD%D1%82%D0%BE%D0%BD.jpg-OCjtCCzHs9SwXnHilB8ikP7X6bauxI.png",
  dima: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%B4%D0%B8%D0%BC%D0%B0-nbIa8tt8DLsNWp99e6w9UNCFFpD5us.jpg",
  liza: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%BB%D0%B8%D0%B7%D0%B0%20%D0%BE%D0%B1%D1%8B%D1%87%D0%BD%D0%B0%D1%8F-pTu9zBrXdFBMaWG9XaWM9jneusyjtl.jpg",
  hanna: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D1%85%D0%B0%D0%BD%D0%BD%D0%B0-8NOlR8Lhg5jAb1Ab3IBjpHmeKVnxwg.jpg",
}
const teamAccents = ["#dc785a", "#b478dc", "#5aa0dc", "#5ac878"]
const team = t.corporate.team.members.map((m, i) => ({
  ...m,
  photo: [trainerPhotos.anton, trainerPhotos.hanna, trainerPhotos.liza, trainerPhotos.dima][i],
  accent: teamAccents[i],
}))

const programs = t.corporate.programs.tabs
const howItWorksFormats = t.corporate.howItWorks.formats
const results = t.corporate.results.items
const testimonials = t.corporate.testimonials.items
const faq = t.corporate.faq.items
const forWho = t.corporate.forWho.items

// ── Marquee ───────────────────────────────────────────────────────────────────
function LogoMarquee({ logos, reverse = false }: { logos: { name: string; src: string }[]; reverse?: boolean }) {
  return (
    <div style={{ overflow: "hidden" }}>
      <div style={{ display: "flex", animation: `${reverse ? "marqueeRight" : "marqueeLeft"} 28s linear infinite`, width: "fit-content" }}>
        {[...logos, ...logos].map((logo, i) => (
          <div key={i} style={{ flexShrink: 0, width: "140px", height: "48px", background: "rgba(255,255,255,0.03)", border: `1px solid ${BORDER}`, display: "flex", alignItems: "center", justifyContent: "center", marginRight: "12px" }}>
            <img src={logo.src} alt={logo.name} style={{ height: "24px", objectFit: "contain", opacity: 0.5, filter: "grayscale(100%) brightness(1.5)" }} onError={e => { e.currentTarget.style.display = "none" }} />
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Hero Video ────────────────────────────────────────────────────────────────
function HeroVideo() {
  useEffect(() => {
    if (!document.querySelector('script[src*="wistia.com/player.js"]')) {
      const s = document.createElement("script"); s.src = "https://fast.wistia.com/player.js"; s.async = true; document.head.appendChild(s)
    }
    if (!document.querySelector('script[src*="tlzwiurxpy.js"]')) {
      const s2 = document.createElement("script"); s2.src = "https://fast.wistia.com/embed/tlzwiurxpy.js"; s2.async = true; s2.setAttribute("type", "module"); document.head.appendChild(s2)
    }
  }, [])
  return (
    <div style={{ position: "relative", width: "min(260px, 40vw)", aspectRatio: "9/16", borderRadius: "28px", border: "2px solid rgba(255,255,255,0.1)", background: "#050508", overflow: "hidden", boxShadow: "0 32px 80px rgba(0,0,0,0.65)", flexShrink: 0 }}>
      <div style={{ position: "absolute", top: "10px", left: "50%", transform: "translateX(-50%)", width: "40px", height: "5px", background: "rgba(255,255,255,0.18)", borderRadius: "3px", zIndex: 20, pointerEvents: "none" }} />
      <div style={{ position: "absolute", inset: 0, zIndex: 1 }}
        dangerouslySetInnerHTML={{ __html: `<wistia-player media-id="tlzwiurxpy" autoplay="true" muted="true" playsinline="true" controls="false" aspect="0.5625" style="width:100%;height:100%;display:block;"></wistia-player>` }}
      />
    </div>
  )
}

// ── Team Carousel ─────────────────────────────────────────────────────────────
function TeamCarousel() {
  const isMobile = useIsMobile()
  const [active, setActive] = useState(0)
  const total = team.length
  const m = team[active]
  return (
    <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
      <BgNeuralCanvas opacity={0.07} nodeCount={24} />
      <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
        <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "flex-end", marginBottom: isMobile ? "32px" : "64px", gap: isMobile ? "20px" : "0" }}>
          <div>
            <div style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "14px" }}>{t.corporate.team.label}</div>
            <h2 style={{ fontFamily: os, fontSize: isMobile ? "36px" : "80px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}>{t.corporate.team.heading}</h2>
          </div>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <span style={{ fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.2)", marginRight: "8px" }}>{String(active + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}</span>
            <button onClick={() => setActive(i => (i - 1 + total) % total)} style={{ width: "52px", height: "52px", border: `1px solid ${BORDER}`, borderRadius: "50%", background: "none", color: "white", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
            <button onClick={() => setActive(i => (i + 1) % total)} style={{ width: "52px", height: "52px", border: `1px solid ${BORDER}`, borderRadius: "50%", background: "none", color: "white", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>→</button>
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "360px 1fr", gap: "1px", background: BORDER }}>
          <div style={{ minHeight: isMobile ? "280px" : "440px", position: "relative", overflow: "hidden" }}>
            <img src={m.photo} alt={m.name} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top", position: "absolute", inset: 0 }} />
            <div style={{ position: "absolute", top: 0, left: 0, width: "48px", height: "3px", background: m.accent }} />
          </div>
          <div style={{ background: BG, padding: isMobile ? "28px 20px" : "52px 52px" }}>
            <div style={{ fontFamily: it, fontSize: "14px", color: m.accent, letterSpacing: "0.06em", marginBottom: "8px" }}>{m.role}</div>
            <h3 style={{ fontFamily: os, fontSize: isMobile ? "30px" : "44px", color: "white", fontWeight: 700, marginBottom: "16px" }}>{m.name}</h3>
            <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "16px", color: "rgba(255,255,255,0.45)", lineHeight: 1.7, marginBottom: "28px" }}>{m.bio}</p>
            <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
              {m.items.map((item, j) => (
                <li key={j} style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", color: "rgba(255,255,255,0.35)", padding: "10px 0", borderTop: `1px solid ${BORDER}`, display: "flex", gap: "10px" }}>
                  <span style={{ color: m.accent, flexShrink: 0 }}>—</span>{item}
                </li>
              ))}
            </ul>
            <div style={{ display: "flex", gap: "8px", marginTop: "32px" }}>
              {team.map((_, i) => (
                <button key={i} onClick={() => setActive(i)} style={{ width: i === active ? "28px" : "8px", height: "2px", background: i === active ? m.accent : "rgba(255,255,255,0.12)", border: "none", cursor: "pointer", padding: 0, transition: "all 0.3s", borderRadius: "1px" }} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ── Programs Tabs ─────────────────────────────────────────────────────────────
function ProgramsTabs() {
  const isMobile = useIsMobile()
  const [activeTab, setActiveTab] = useState<number | "custom">(0)
  const [openModule, setOpenModule] = useState<number | null>(null)

  const isCustom = activeTab === "custom"
  const prog = isCustom ? null : programs[activeTab as number]

  function handleTabClick(idx: number) { setActiveTab(idx); setOpenModule(null) }
  function handleCustomClick() { setActiveTab("custom"); setOpenModule(null) }

  return (
    <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
      <BgNeuralCanvas opacity={0.07} nodeCount={26} />
      <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
        <div style={{ fontFamily: it, fontSize: isMobile ? "12px" : "11px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "16px" }}>{t.corporate.programs.label}</div>
        <h2
          style={{ fontFamily: os, fontSize: isMobile ? "38px" : "80px", color: "white", lineHeight: 0.9, marginBottom: "16px", textTransform: "uppercase" as const, fontWeight: 700 }}
          dangerouslySetInnerHTML={{ __html: t.corporate.programs.heading }}
        />
        <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "17px", color: "rgba(255,255,255,0.35)", marginBottom: isMobile ? "32px" : "48px", maxWidth: "560px", lineHeight: 1.7 }}>{t.corporate.programs.subtitle}</p>

        {/* Tabs */}
        <div style={{ display: "flex", flexWrap: "wrap" as const, gap: "10px", marginBottom: "16px" }}>
          {programs.map((p, i) => (
            <button key={i} onClick={() => handleTabClick(i)} style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", padding: isMobile ? "8px 14px" : "10px 20px", borderRadius: "100px", border: `1px solid ${activeTab === i ? ACCENT + "80" : BORDER}`, background: activeTab === i ? `${ACCENT}15` : "rgba(255,255,255,0.02)", color: activeTab === i ? "white" : "rgba(255,255,255,0.45)", cursor: "pointer", display: "flex", alignItems: "center", gap: "8px" }}>
              <span>{p.icon}</span>{isMobile ? p.title.split("/")[0].trim() : p.title}
            </button>
          ))}
          <button onClick={handleCustomClick} style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", padding: isMobile ? "8px 14px" : "10px 20px", borderRadius: "100px", border: `1px solid ${isCustom ? ACCENT + "80" : BORDER}`, background: isCustom ? `${ACCENT}15` : "rgba(255,255,255,0.02)", color: isCustom ? "white" : "rgba(255,255,255,0.45)", cursor: "pointer", display: "flex", alignItems: "center", gap: "8px" }}>
            🎯 {isMobile ? t.corporate.programs.customTab.split(" ")[0] : t.corporate.programs.customTab}
          </button>
        </div>

        {/* Meta badges */}
        {!isCustom && prog && (
          <div style={{ display: "flex", flexWrap: "wrap" as const, gap: "8px", marginBottom: "44px" }}>
            {prog.meta.map((m, i) => (
              <span key={i} style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.45)", border: `1px solid ${BORDER}`, padding: "5px 14px", borderRadius: "100px" }}>{m}</span>
            ))}
          </div>
        )}

        {/* Accordion */}
        {!isCustom && prog && (
          <div style={{ borderTop: `1px solid ${BORDER}` }}>
            {prog.modules.map((mod, i) => (
              <div key={i} style={{ borderBottom: `1px solid ${BORDER}` }}>
                <button onClick={() => setOpenModule(openModule === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: isMobile ? "16px 0" : "22px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const }}>
                  <span style={{ fontFamily: it, fontSize: isMobile ? "14px" : "16px", color: "white", maxWidth: "85%", fontWeight: openModule === i ? 600 : 400 }}>{mod.title}</span>
                  <span style={{ fontFamily: os, fontSize: "24px", color: "rgba(255,255,255,0.2)", flexShrink: 0, marginLeft: "20px", lineHeight: 1 }}>{openModule === i ? "−" : "+"}</span>
                </button>
                {openModule === i && (
                  <div style={{ paddingBottom: "24px" }}>
                    {Array.isArray((mod as any).content) ? (
                      <ul style={{ listStyle: "none", padding: 0, margin: 0, maxWidth: "680px" }}>
                        {((mod as any).content as string[]).map((bullet: string, j: number) => (
                          <li key={j} style={{ display: "flex", alignItems: "flex-start", gap: "10px", padding: "5px 0" }}>
                            <span style={{ color: ACCENT, flexShrink: 0, marginTop: "3px", fontSize: "8px" }}>●</span>
                            <span style={{ fontFamily: it, fontSize: isMobile ? "14px" : "14px", color: "rgba(255,255,255,0.45)", lineHeight: 1.65 }}>{bullet}</span>
                          </li>
                        ))}
                      </ul>
                    ) : (mod as any).text ? (
                      <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "15px", color: "rgba(255,255,255,0.38)", lineHeight: 1.75, maxWidth: "680px" }}>
                        {(mod as any).text}
                      </p>
                    ) : null}
                  </div>
                )}
                {/* Custom program block */}
                {isCustom && (
                  <div style={{ marginTop: "8px", background: BG2, border: `1px solid ${BORDER}`, padding: isMobile ? "40px 24px" : "72px 56px", display: "flex", flexDirection: "column" as const, alignItems: "center", textAlign: "center" as const, position: "relative", overflow: "hidden" }}>
                    <BgNeuralCanvas opacity={0.10} nodeCount={30} />
                    <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(to right, transparent, ${ACCENT}, transparent)` }} />
                    <div style={{ position: "relative", zIndex: 1, maxWidth: "560px" }}>
                      <div style={{ width: "56px", height: "56px", border: `1px solid ${ACCENT}40`, background: `${ACCENT}10`, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 28px", fontSize: "24px" }}>🎯</div>
                      <div style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "16px" }}>{t.corporate.programs.customLabel}</div>
                      <h3 style={{ fontFamily: os, fontSize: isMobile ? "30px" : "48px", color: "white", fontWeight: 700, lineHeight: 0.95, marginBottom: "20px", textTransform: "uppercase" as const }}>{t.corporate.programs.customHeading}</h3>
                      <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "17px", color: "rgba(255,255,255,0.38)", lineHeight: 1.7, marginBottom: "40px" }}>{t.corporate.programs.customBody}</p>
                      <div style={{ display: "flex", justifyContent: "center", gap: isMobile ? "24px" : "56px", marginBottom: "44px" }}>
                        {[
                          { n: "1", label: t.corporate.programs.customSteps?.[0] ?? "Расскажите о команде" },
                          { n: "2", label: t.corporate.programs.customSteps?.[1] ?? "Выберите темы" },
                          { n: "3", label: t.corporate.programs.customSteps?.[2] ?? "Получите программу" },
                        ].map((step, i) => (
                          <div key={i} style={{ display: "flex", flexDirection: "column" as const, alignItems: "center", gap: "10px" }}>
                            <div style={{ width: "40px", height: "40px", borderRadius: "50%", background: `${ACCENT}20`, border: `1px solid ${ACCENT}60`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                              <span style={{ fontFamily: os, fontSize: "15px", fontWeight: 700, color: ACCENT }}>{step.n}</span>
                            </div>
                            <span style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.3)", maxWidth: "80px", lineHeight: 1.4, textAlign: "center" as const }}>{step.label}</span>
                          </div>
                        ))}
                      </div>
                      <a href={FORM_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: ACCENT, color: "white", padding: isMobile ? "14px 36px" : "17px 52px", fontFamily: os, fontSize: isMobile ? "13px" : "15px", letterSpacing: "0.12em", textDecoration: "none", textTransform: "uppercase" as const }}>{t.corporate.programs.customCta}</a>
                    </div>
                  </div>
                )}
              </div>
            </section>
        )
        }

// ── Nav courses dropdown ──────────────────────────────────────────────────────
        function NavCoursesDropdown({isMobile}: {isMobile: boolean }) {
  const [open, setOpen] = useState(false)
        const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
            function handle(e: MouseEvent) { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener("mousedown", handle)
    return () => document.removeEventListener("mousedown", handle)
  }, [])
          return (
          <div ref={ref} style={{ position: "relative" }}>
            <button
              onClick={() => setOpen(o => !o)}
              style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.6)", textDecoration: "none", padding: isMobile ? "6px 10px" : "8px 18px", borderRadius: "3px", background: "transparent", letterSpacing: "0.03em", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: "5px" }}
            >
              {t.common.nav.courses}
              <span style={{ fontSize: "8px", opacity: 0.45, transition: "transform 0.2s", transform: open ? "rotate(180deg)" : "rotate(0deg)", display: "inline-block" }}>▼</span>
            </button>
            {open && (
              <div style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, background: "#15151f", border: `1px solid ${BORDER}`, borderRadius: "4px", padding: "6px 0", minWidth: "190px", zIndex: 60, boxShadow: "0 16px 40px rgba(0,0,0,0.6)" }}>
                <div style={{ fontFamily: it, fontSize: "9px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.2em", textTransform: "uppercase" as const, padding: "4px 16px 6px" }}>{t.common.nav.courses}</div>
                <Link href="/photo" onClick={() => setOpen(false)} style={{ display: "flex", alignItems: "center", gap: "12px", fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.75)", textDecoration: "none", padding: "10px 16px" }}
                  onMouseEnter={e => { e.currentTarget.style.background = "rgba(90,160,220,0.08)"; e.currentTarget.style.color = "#5aa0dc" }}
                  onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "rgba(255,255,255,0.75)" }}
                >
                  <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#5aa0dc", flexShrink: 0 }} />
                  {t.common.coursesDropdown.aiPhoto}
                </Link>
                <Link href="/video" onClick={() => setOpen(false)} style={{ display: "flex", alignItems: "center", gap: "12px", fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.75)", textDecoration: "none", padding: "10px 16px" }}
                  onMouseEnter={e => { e.currentTarget.style.background = "rgba(90,200,120,0.08)"; e.currentTarget.style.color = "#5ac878" }}
                  onMouseLeave={e => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "rgba(255,255,255,0.75)" }}
                >
                  <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#5ac878", flexShrink: 0 }} />
                  {t.common.coursesDropdown.aiCreator}
                </Link>
              </div>
            )}
          </div>
          )
}

          // ── Footer courses dropdown ───────────────────────────────────────────────────
          function CoursesDropdown({isMobile}: {isMobile: boolean }) {
  const [open, setOpen] = useState(false)
          const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
              function handle(e: MouseEvent) { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener("mousedown", handle)
    return () => document.removeEventListener("mousedown", handle)
  }, [])
            return (
            <div ref={ref} style={{ position: "relative" }}>
              <button onClick={() => setOpen(o => !o)} style={{ background: "none", border: "none", fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.18)", cursor: "pointer", display: "flex", alignItems: "center", gap: "4px", padding: 0 }}>
                {t.common.nav.courses} <span style={{ fontSize: "8px", opacity: 0.5 }}>{open ? "▲" : "▼"}</span>
              </button>
              {open && (
                <div style={{ position: "absolute", bottom: "100%", left: 0, marginBottom: "8px", background: "#1a1a22", border: `1px solid ${BORDER}`, padding: "8px 0", minWidth: "160px", zIndex: 50 }}>
                  <Link href="/photo" style={{ display: "block", fontFamily: it, fontSize: "13px", color: "#5aa0dc", textDecoration: "none", padding: "8px 16px" }}>{t.common.coursesDropdown.aiPhoto}</Link>
                  <Link href="/video" style={{ display: "block", fontFamily: it, fontSize: "13px", color: "#5ac878", textDecoration: "none", padding: "8px 16px" }}>{t.common.coursesDropdown.aiCreator}</Link>
                </div>
              )}
            </div>
            )
}

            // ── Back to top ───────────────────────────────────────────────────────────────
            function BackToTop() {
  const [visible, setVisible] = useState(false)
  useEffect(() => {
              function onScroll() { setVisible(window.scrollY > 600) }
    window.addEventListener("scroll", onScroll, {passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])
            return (
            <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Наверх"
              style={{ position: "fixed", bottom: "32px", right: "32px", width: "48px", height: "48px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", backdropFilter: "blur(12px)", borderRadius: "50%", color: "rgba(255,255,255,0.7)", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, opacity: visible ? 1 : 0, pointerEvents: visible ? "auto" : "none", transform: visible ? "translateY(0)" : "translateY(12px)", transition: "opacity 0.3s, transform 0.3s" }}
            >↑</button>
            )
}

            // ── Main Page ─────────────────────────────────────────────────────────────────
            export default function CorporatePage() {
  const isMobile = useIsMobile()
            const [openFaq, setOpenFaq] = useState<number | null>(null)
            const [activeT, setActiveT] = useState(0)

            return (
            <main style={{ overflowX: "hidden", fontFamily: it, background: BG }}>

              <BackToTop />

              {/* NAV */}
              <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, display: "flex", alignItems: "center", justifyContent: "space-between", padding: isMobile ? "0 16px" : "0 56px", height: isMobile ? "56px" : "68px", background: "rgba(10,10,20,0.85)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
                <Link href="/" style={{ fontFamily: os, fontSize: isMobile ? "13px" : "16px", letterSpacing: "0.22em", color: "white", textTransform: "uppercase" as const, fontWeight: 700, textDecoration: "none" }}>{t.common.nav.logo}</Link>
                <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
                  <NavCoursesDropdown isMobile={isMobile} />
                  {[
                    { label: t.common.nav.trainings, href: "/corporate" },
                    { label: t.common.nav.production, href: "/production" },
                    { label: t.common.nav.contact, href: TG_URL, external: true },
                  ].map((item, i) => (
                    <a key={item.label} href={item.href} target={item.external ? "_blank" : undefined} rel={item.external ? "noopener noreferrer" : undefined}
                      style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: i === 2 ? "#111" : "rgba(255,255,255,0.6)", textDecoration: "none", padding: isMobile ? "6px 10px" : "8px 18px", borderRadius: "3px", background: i === 2 ? "white" : "transparent", letterSpacing: "0.03em", display: isMobile && i < 2 ? "none" : "block" }}
                    >{item.label}</a>
                  ))}
                </div>
              </nav>

              {/* ══ HERO ══ */}
              <section style={{ position: "relative", minHeight: isMobile ? "auto" : "100vh", overflow: "hidden", paddingTop: isMobile ? "56px" : "68px", background: BG2 }}>
                <BgNeuralCanvas opacity={0.08} nodeCount={28} />
                <div style={{ maxWidth: "1200px", margin: "0 auto", padding: isMobile ? "40px 20px 48px" : "80px 56px", display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr auto", gap: isMobile ? "32px" : "80px", alignItems: "center", position: "relative", zIndex: 1 }}>
                  <div>
                    <div style={{ display: "inline-block", fontFamily: it, fontSize: "12px", color: ACCENT, border: `0.5px solid ${ACCENT}55`, padding: "3px 10px", borderRadius: "2px", marginBottom: isMobile ? "16px" : "24px" }}>{t.corporate.hero.badge}</div>
                    <h1
                      style={{ fontFamily: os, fontSize: isMobile ? "42px" : "80px", color: "white", textTransform: "uppercase" as const, lineHeight: 0.88, marginBottom: isMobile ? "16px" : "24px", fontWeight: 700 }}
                      dangerouslySetInnerHTML={{ __html: t.corporate.hero.title }}
                    />
                    <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "18px", color: "rgba(255,255,255,0.5)", maxWidth: "420px", marginBottom: isMobile ? "28px" : "44px", lineHeight: 1.65 }}>
                      {t.corporate.hero.subtitle}
                    </p>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "1px", background: BORDER, marginBottom: isMobile ? "28px" : "40px" }}>
                      {t.corporate.stats.map((s, i) => (
                        <div key={i} style={{ background: BG, padding: isMobile ? "16px 12px" : "20px 24px", textAlign: "center" as const }}>
                          <div style={{ fontFamily: os, fontSize: isMobile ? "24px" : "36px", color: "white", fontWeight: 700 }}>{s.n}</div>
                          <div style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.28)", marginTop: "4px" }}>{s.l}</div>
                        </div>
                      ))}
                    </div>
                    <div style={{ display: "flex", gap: "12px", flexWrap: "wrap" as const, flexDirection: isMobile ? "column" : "row", width: isMobile ? "100%" : "auto" }}>
                      <a href={TG_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: ACCENT, color: "white", padding: isMobile ? "16px 28px" : "17px 40px", fontFamily: os, fontSize: isMobile ? "14px" : "15px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const, textAlign: "center" as const, minHeight: isMobile ? "48px" : "auto" }}>{t.corporate.hero.ctaPrimary}</a>
                      <a href="#programs" style={{ display: "inline-block", background: "transparent", border: `1px solid rgba(255,255,255,0.2)`, color: "white", padding: isMobile ? "16px 28px" : "17px 40px", fontFamily: os, fontSize: isMobile ? "14px" : "15px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const, textAlign: "center" as const, minHeight: isMobile ? "48px" : "auto" }}>{t.corporate.hero.ctaSecondary}</a>
                    </div>
                  </div>
                  {!isMobile && <HeroVideo />}
                </div>
              </section>

              {/* ══ LOGOS MARQUEE ══ */}
              <section style={{ background: BG, padding: "32px 0", borderTop: `1px solid ${BORDER}`, overflow: "hidden" }}>
                <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "0 56px", marginBottom: "16px" }}>
                  <div style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.15em", textTransform: "uppercase" as const, textAlign: "center" as const }}>{t.corporate.logosLabel}</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  <LogoMarquee logos={LOGOS_ROW1} />
                  <LogoMarquee logos={LOGOS_ROW2} reverse />
                </div>
              </section>

              {/* ══ ДЛЯ КОГО ══ */}
              <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
                <BgNeuralCanvas opacity={0.08} nodeCount={26} />
                <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
                  <h2
                    style={{ fontFamily: os, fontSize: isMobile ? "38px" : "80px", color: "white", lineHeight: 0.9, marginBottom: isMobile ? "12px" : "20px", textTransform: "uppercase" as const, fontWeight: 700 }}
                    dangerouslySetInnerHTML={{ __html: t.corporate.forWho.heading }}
                  />
                  <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "17px", color: "rgba(255,255,255,0.35)", marginBottom: isMobile ? "32px" : "64px" }}>{t.corporate.forWho.subtitle}</p>
                  <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(3,1fr)", gap: "1px", background: BORDER }}>
                    {forWho.map((item, i) => (
                      <div key={i} style={{ background: BG, padding: isMobile ? "28px 20px" : "40px 36px", position: "relative" as const }}>
                        <div style={{ position: "absolute", top: 0, left: 0, width: "40px", height: "2px", background: ACCENT }} />
                        <h3 style={{ fontFamily: os, fontSize: isMobile ? "17px" : "20px", color: "white", marginBottom: "14px", fontWeight: 700 }}>{item.title}</h3>
                        <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "15px", color: "rgba(255,255,255,0.38)", lineHeight: 1.7 }}>{item.text}</p>
                      </div>
                    ))}
                  </div>
                  <div style={{ marginTop: isMobile ? "28px" : "40px", background: `${ACCENT}10`, border: `1px solid ${ACCENT}30`, padding: isMobile ? "24px 20px" : "32px 40px", display: "flex", flexDirection: isMobile ? "column" : "row", alignItems: isMobile ? "flex-start" : "center", justifyContent: "space-between", gap: "20px" }}>
                    <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "17px", color: "white" }}>{t.corporate.forWho.consultationBanner}</p>
                    <a href={TG_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: ACCENT, color: "white", padding: isMobile ? "12px 24px" : "14px 32px", fontFamily: os, fontSize: "13px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const, flexShrink: 0 }}>{t.common.cta.write}</a>
                  </div>
                </div>
              </section>

              {/* ══ TEAM ══ */}
              <TeamCarousel />

              {/* ══ PROGRAMS ══ */}
              <div id="programs"><ProgramsTabs /></div>

              {/* ══ КАК ПРОХОДИТ ══ */}
              <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
                <BgNeuralCanvas opacity={0.07} nodeCount={24} />
                <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
                  <h2
                    style={{ fontFamily: os, fontSize: isMobile ? "38px" : "80px", color: "white", lineHeight: 0.9, marginBottom: isMobile ? "12px" : "20px", textTransform: "uppercase" as const, fontWeight: 700 }}
                    dangerouslySetInnerHTML={{ __html: t.corporate.howItWorks.heading }}
                  />
                  <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "17px", color: "rgba(255,255,255,0.35)", marginBottom: isMobile ? "32px" : "64px" }}>{t.corporate.howItWorks.subtitle}</p>

                  {isMobile ? (
                    <div style={{ marginBottom: "40px" }}>
                      <div style={{ position: "relative", width: "42vw", maxWidth: "175px", float: "right", marginLeft: "16px", marginBottom: "8px", aspectRatio: "9/16", borderRadius: "16px", overflow: "hidden", background: "#050508", border: "1px solid rgba(255,255,255,0.08)" }}>
                        <WistiaPlayer mediaId="b2zxvp358k" />
                      </div>
                      {howItWorksFormats.map((f, i) => (
                        <div key={i} style={{ border: `1px solid ${BORDER}`, borderLeft: `3px solid ${ACCENT}`, borderRadius: "8px", padding: "16px", marginBottom: "10px", background: BG }}>
                          <div style={{ fontSize: "20px", marginBottom: "6px" }}>{f.icon}</div>
                          <h3 style={{ fontFamily: os, fontSize: "16px", color: "white", marginBottom: "6px", fontWeight: 700 }}>{f.title}</h3>
                          <p style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.38)", lineHeight: 1.6 }}>{f.text}</p>
                        </div>
                      ))}
                      <div style={{ clear: "both" }} />
                    </div>
                  ) : (
                    <div style={{ display: "flex", gap: "24px", marginBottom: "48px", alignItems: "stretch" }}>
                      <div style={{ position: "relative", flexShrink: 0, width: "clamp(180px, 22vw, 260px)", aspectRatio: "9/16", borderRadius: "16px", overflow: "hidden", background: "#050508", border: "1px solid rgba(255,255,255,0.08)" }}>
                        <WistiaPlayer mediaId="b2zxvp358k" />
                      </div>
                      <div style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1px", background: BORDER }}>
                        {howItWorksFormats.map((f, i) => (
                          <div key={i} style={{ background: BG, padding: "36px 28px", position: "relative" as const }}>
                            <div style={{ position: "absolute", top: 0, left: 0, width: "40px", height: "2px", background: ACCENT }} />
                            <div style={{ fontSize: "26px", marginBottom: "14px" }}>{f.icon}</div>
                            <h3 style={{ fontFamily: os, fontSize: "18px", color: "white", marginBottom: "10px", fontWeight: 700 }}>{f.title}</h3>
                            <p style={{ fontFamily: it, fontSize: "15px", color: "rgba(255,255,255,0.38)", lineHeight: 1.7 }}>{f.text}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr 1fr" : "repeat(4,1fr)", gap: "1px", background: BORDER }}>
                    {t.corporate.howItWorks.params.map(([icon, val], i) => (
                      <div key={i} style={{ background: BG2, padding: isMobile ? "16px 12px" : "24px 28px", display: "flex", alignItems: "center", gap: "12px" }}>
                        <span style={{ fontSize: "17px" }}>{icon}</span>
                        <span style={{ fontFamily: it, fontSize: isMobile ? "13px" : "14px", color: "rgba(255,255,255,0.5)" }}>{val}</span>
                      </div>
                    ))}
                  </div>

                  <div style={{ marginTop: "32px", display: "flex", gap: "16px", flexWrap: "wrap" as const }}>
                    <a href={TG_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: ACCENT, color: "white", padding: isMobile ? "14px 28px" : "17px 40px", fontFamily: os, fontSize: isMobile ? "13px" : "15px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const }}>{t.corporate.hero.ctaPrimary}</a>
                    <span style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.25)", display: "flex", alignItems: "center" }}>{t.corporate.howItWorks.ctaHint}</span>
                  </div>
                </div>
              </section>

              {/* ══ РЕЗУЛЬТАТЫ ══ */}
              <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
                <BgNeuralCanvas opacity={0.08} nodeCount={28} />
                <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
                  <h2
                    style={{ fontFamily: os, fontSize: isMobile ? "36px" : "72px", color: "white", lineHeight: 0.92, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "12px" }}
                    dangerouslySetInnerHTML={{ __html: t.corporate.results.heading }}
                  />
                  <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "17px", color: "rgba(255,255,255,0.35)", marginBottom: isMobile ? "40px" : "56px", maxWidth: "520px", lineHeight: 1.7 }}>{t.corporate.results.subtitle}</p>

                  <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "300px 1fr", gap: "1px", background: BORDER }}>
                    {!isMobile && (
                      <div style={{ position: "relative", overflow: "hidden", background: "#050508", gridRow: `1 / span ${results.length}` }}>
                        <WistiaPlayer mediaId="6kjwg4p3y2" />
                      </div>
                    )}
                    <div style={{ display: "flex", flexDirection: "column" as const }}>
                      {results.map((item, i) => (
                        <div key={i} style={{ background: i % 2 === 0 ? BG2 : BG, padding: isMobile ? "24px 0" : "28px 32px", display: "flex", gap: "20px", alignItems: "flex-start", borderBottom: `1px solid ${BORDER}`, flex: 1 }}>
                          <div style={{ width: "40px", height: "40px", borderRadius: "50%", background: `${ACCENT}15`, border: `1px solid ${ACCENT}50`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: "2px" }}>
                            <span style={{ fontFamily: os, fontSize: "13px", fontWeight: 700, color: ACCENT }}>{item.n}</span>
                          </div>
                          <div style={{ flex: 1 }}>
                            <h3 style={{ fontFamily: os, fontSize: isMobile ? "16px" : "19px", color: "white", marginBottom: "8px", fontWeight: 700 }}>{item.title}</h3>
                            <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", color: "rgba(255,255,255,0.4)", lineHeight: 1.7 }}>{item.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </section>

              {/* ══ ФОРМАТЫ УЧАСТИЯ ══ */}
              <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
                <BgNeuralCanvas opacity={0.07} nodeCount={24} />
                <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
                  <h2
                    style={{ fontFamily: os, fontSize: isMobile ? "36px" : "80px", color: "white", lineHeight: 0.9, marginBottom: isMobile ? "12px" : "20px", textTransform: "uppercase" as const, fontWeight: 700 }}
                    dangerouslySetInnerHTML={{ __html: t.corporate.pricing.heading }}
                  />
                  <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "17px", color: "rgba(255,255,255,0.35)", marginBottom: isMobile ? "32px" : "64px" }}>{t.corporate.pricing.subtitle}</p>
                  <div style={{ background: BG2, padding: isMobile ? "32px 20px" : "56px 48px", position: "relative" as const, display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: isMobile ? "32px" : "64px", alignItems: "center" }}>
                    <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "3px", background: ACCENT }} />
                    <div>
                      <div style={{ fontFamily: it, fontSize: "11px", color: ACCENT, letterSpacing: "0.12em", marginBottom: "20px", textTransform: "uppercase" as const }}>{t.corporate.pricing.team.label}</div>
                      <h3 style={{ fontFamily: os, fontSize: isMobile ? "30px" : "48px", color: "white", fontWeight: 700, lineHeight: 0.95, marginBottom: "16px", textTransform: "uppercase" as const }}>{t.corporate.pricing.team.priceLabel}</h3>
                      <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "16px", color: "rgba(255,255,255,0.4)", lineHeight: 1.7, marginBottom: "32px" }}>{t.corporate.pricing.team.desc}</p>
                      <a href={TG_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: ACCENT, color: "white", padding: isMobile ? "13px 28px" : "16px 40px", fontFamily: os, fontSize: "14px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const }}>{t.corporate.pricing.team.cta}</a>
                    </div>
                    <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
                      {t.corporate.pricing.team.features.map((f, j) => (
                        <li key={j} style={{ fontFamily: it, fontSize: isMobile ? "14px" : "15px", color: "rgba(255,255,255,0.45)", padding: "12px 0", borderBottom: `1px solid ${BORDER}`, display: "flex", gap: "12px", alignItems: "flex-start" }}>
                          <span style={{ color: ACCENT, flexShrink: 0, marginTop: "1px" }}>✓</span>{f}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </section>

              {/* ══ ОТЗЫВЫ ══ */}
              <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
                <BgNeuralCanvas opacity={0.07} nodeCount={22} />
                <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
                  <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "flex-end", marginBottom: isMobile ? "32px" : "64px", gap: isMobile ? "20px" : "0" }}>
                    <h2
                      style={{ fontFamily: os, fontSize: isMobile ? "36px" : "80px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}
                      dangerouslySetInnerHTML={{ __html: t.corporate.testimonials.heading }}
                    />
                    <div style={{ display: "flex", gap: "12px" }}>
                      <button onClick={() => setActiveT(i => (i - 1 + testimonials.length) % testimonials.length)} style={{ width: "52px", height: "52px", border: `1px solid ${BORDER}`, borderRadius: "50%", background: "none", color: "white", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
                      <button onClick={() => setActiveT(i => (i + 1) % testimonials.length)} style={{ width: "52px", height: "52px", border: `1px solid ${BORDER}`, borderRadius: "50%", background: "none", color: "white", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>→</button>
                    </div>
                  </div>
                  <div style={{ background: BG2, padding: isMobile ? "32px 20px" : "56px 56px", marginBottom: "1px" }}>
                    <div style={{ fontFamily: os, fontSize: isMobile ? "64px" : "120px", color: "rgba(255,255,255,0.04)", lineHeight: 0.75, marginBottom: "28px", fontWeight: 700 }}>"</div>
                    <p style={{ fontFamily: os, fontSize: isMobile ? "22px" : "32px", color: "white", lineHeight: 1.3, marginBottom: "28px", maxWidth: "800px", fontWeight: 400 }}>«{testimonials[activeT].text}»</p>
                    <p style={{ fontFamily: it, fontSize: "15px", color: ACCENT, letterSpacing: "0.06em" }}>— {testimonials[activeT].author}</p>
                  </div>
                  <div style={{ display: isMobile ? "none" : "grid", gridTemplateColumns: `repeat(${testimonials.length},1fr)`, gap: "1px", background: BORDER }}>
                    {testimonials.map((item, i) => (
                      <div key={i} onClick={() => setActiveT(i)} style={{ background: i === activeT ? "#1a1a22" : BG2, padding: "20px 24px", cursor: "pointer", borderTop: i === activeT ? `2px solid ${ACCENT}` : "2px solid transparent", transition: "all 0.2s" }}>
                        <p style={{ fontFamily: it, fontSize: "13px", color: i === activeT ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.2)", lineHeight: 1.5, marginBottom: "8px" }}>{item.text.slice(0, 50)}…</p>
                        <p style={{ fontFamily: it, fontSize: "12px", color: i === activeT ? ACCENT : "rgba(255,255,255,0.15)" }}>— {item.author}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* ══ FAQ ══ */}
              <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
                <BgNeuralCanvas opacity={0.07} nodeCount={24} />
                <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1, display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: isMobile ? "32px" : "120px" }}>
                  <div style={{ position: isMobile ? "static" : "sticky", top: "96px", alignSelf: "start" }}>
                    <h2
                      style={{ fontFamily: os, fontSize: isMobile ? "36px" : "80px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "20px" }}
                      dangerouslySetInnerHTML={{ __html: t.corporate.faq.heading }}
                    />
                    <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "16px", color: "rgba(255,255,255,0.25)", lineHeight: 1.7 }}>{t.corporate.faq.moreQuestionsLabel}</p>
                    <a href={TG_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-flex", alignItems: "center", gap: "8px", marginTop: "24px", fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.4)", textDecoration: "none", borderBottom: "1px solid rgba(255,255,255,0.12)", paddingBottom: "2px" }}>{t.common.cta.writeTelegram}</a>
                  </div>
                  <div>
                    {faq.map((item, i) => (
                      <div key={i} style={{ borderBottom: `1px solid ${BORDER}` }}>
                        <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "24px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const }}>
                          <span style={{ fontFamily: os, fontSize: isMobile ? "15px" : "18px", color: "white", maxWidth: "85%" }}>{item.q}</span>
                          <span style={{ fontFamily: os, fontSize: "26px", color: "rgba(255,255,255,0.2)", flexShrink: 0, marginLeft: "16px" }}>{openFaq === i ? "−" : "+"}</span>
                        </button>
                        {openFaq === i && <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "15px", color: "rgba(255,255,255,0.38)", lineHeight: 1.75, paddingBottom: "24px", maxWidth: "540px" }}>{item.a}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* ══ FINAL CTA ══ */}
              <section style={{ background: BG, padding: isMobile ? "80px 20px" : "160px 56px", borderTop: `1px solid ${BORDER}`, textAlign: "center" as const, position: "relative", overflow: "hidden" }}>
                <BgNeuralCanvas opacity={0.09} nodeCount={30} />
                <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", width: "600px", height: "600px", background: `radial-gradient(circle, ${ACCENT}08 0%, transparent 70%)`, pointerEvents: "none" }} />
                <div style={{ position: "relative", maxWidth: "800px", margin: "0 auto", zIndex: 1 }}>
                  <h2
                    style={{ fontFamily: os, fontSize: isMobile ? "36px" : "72px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "24px" }}
                    dangerouslySetInnerHTML={{ __html: t.corporate.finalCta.heading }}
                  />
                  <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "18px", color: "rgba(255,255,255,0.4)", lineHeight: 1.75, marginBottom: "40px", maxWidth: "560px", margin: "0 auto 40px" }}>
                    {t.corporate.finalCta.body}
                  </p>
                  <a href={TG_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: "white", color: "#111", padding: isMobile ? "16px 36px" : "20px 56px", fontFamily: os, fontSize: isMobile ? "14px" : "16px", letterSpacing: "0.14em", textDecoration: "none", textTransform: "uppercase" as const }}>{t.corporate.finalCta.button}</a>
                  <p style={{ fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.2)", marginTop: "20px" }}>{t.corporate.finalCta.hint}</p>
                </div>
              </section>

              {/* ══ FOOTER ══ */}
              <footer style={{ background: BG, padding: isMobile ? "28px 20px" : "36px 56px", borderTop: `1px solid ${BORDER}` }}>
                <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: "center", gap: isMobile ? "20px" : "0" }}>
                  <Link href="/" style={{ fontFamily: os, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.15)", letterSpacing: "0.2em", textTransform: "uppercase" as const, textDecoration: "none" }}>{t.common.nav.logo}</Link>
                  <div style={{ display: "flex", gap: isMobile ? "16px" : "32px", flexWrap: "wrap" as const, justifyContent: "center", alignItems: "center" }}>
                    <CoursesDropdown isMobile={isMobile} />
                    {[{ label: t.common.nav.trainings, href: "/corporate" }, { label: t.common.nav.production, href: "/production" }].map(item => (
                      <Link key={item.label} href={item.href} style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.18)", textDecoration: "none" }}>{item.label}</Link>
                    ))}
                    <a href={TG_URL} target="_blank" rel="noopener noreferrer" style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.18)", textDecoration: "none" }}>{t.common.footer.telegram}</a>
                  </div>
                  <span style={{ fontFamily: it, fontSize: isMobile ? "10px" : "12px", color: "rgba(255,255,255,0.1)" }}>{t.common.footer.copyrightFull}</span>
                </div>
                <div style={{ display: "flex", justifyContent: "center", gap: "24px", marginTop: "20px", paddingTop: "16px", borderTop: `1px solid ${BORDER}` }}>
                  <Link href="/terms" style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", textDecoration: "none" }}>Условия использования</Link>
                  <Link href="/privacy" style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", textDecoration: "none" }}>Политика конфиденциальности</Link>
                </div>
              </footer>

              <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&family=Inter:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        @keyframes marqueeLeft { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        @keyframes marqueeRight { from { transform: translateX(-50%); } to { transform: translateX(0); } }
      `}</style>
            </main>
            )
}