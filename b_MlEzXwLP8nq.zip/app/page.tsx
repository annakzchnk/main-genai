"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { useIsMobile } from "@/hooks/use-mobile"

const BG = "#0d0d12"
const BG2 = "#111118"
const BORDER = "rgba(255,255,255,0.06)"
const os = "'Oswald', sans-serif"
const it = "'Inter', sans-serif"

const PANELS = [
  { tag: "B2C · AI Фото", title: "КУРС ПО AI ФОТО", description: "Забудьте о дорогих студиях и фотографах. Нейрофотосессия в любом стиле прямо в телефоне, за пару кликов.", link: "Узнать подробнее", accent: "#5aa0dc", href: "/photo" },
  { tag: "B2C · AI Видео", title: "КУРС AI CREATOR", description: "То, что раньше снимала целая команда, теперь делает один человек за минуты. Без камер и света — только вы и смартфон.", link: "Узнать подробнее", accent: "#5ac878", href: "/video" },
  { tag: "B2B · Тренинги", title: "КОРПОРАТИВНОЕ ОБУЧЕНИЕ", description: "Внедряем AI в ДНК вашего бизнеса. Сотрудники начинают использовать AI-инструменты уже в первую неделю.", link: "Запросить программу", accent: "#b478dc", href: "/corporate" },
  { tag: "B2B · Продакшн", title: "AI ПРОДАКШН", description: "Нужен качественный видеоконтент? Создадим AI-видео для вашего бренда: быстрее, гибче и дешевле классического продакшна.", link: "Обсудить проект", accent: "#dc785a", href: "/production" },
]

const PRODUCTS = [
  {
    num: "01", tag: "B2C · AI Фото", title: "Курс по AI фото",
    desc: "Забудьте о дорогих студиях и фотографах. Создавайте идеальные портреты со своим лицом, карточки товаров и контент для соцсетей прямо в телефоне. Нейрофотосессия в любом стиле за пару кликов.",
    for: "Контент-мейкеры, SMM, владельцы бизнеса и все, кто хочет выглядеть дорого в сети.",
    link: "Узнать подробнее", accent: "#5aa0dc", href: "/photo",
    img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/module01-girl-door-k3YMTGjMonuXhZs3rvCGZ7p4iro8Jr.jpg",
    video: null,
  },
  {
    num: "02", tag: "B2C · AI Видео", title: "Курс AI Creator",
    desc: "То, что раньше снимала целая команда, теперь делает один человек за минуты. Генерация, монтаж и системный видео-продакшн без камер и света - только вы и ваш смартфон.",
    for: "Блогеры, маркетологи и те, кто планирует монетизировать самый востребованный навык 2026 года.",
    link: "Узнать подробнее", accent: "#5ac878", href: "/video",
    img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-39-fjNeDMeZyabNir85zxwXVTu85VSQxe.jpg",
    video: "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5272.MOV",
  },
  {
    num: "03", tag: "B2B · Тренинги", title: "Корпоративное обучение",
    desc: "Внедряем AI в ДНК вашего бизнеса. Разрабатываем программу под ваши задачи и отрасль. Сотрудники начинают использовать AI-инструменты уже в первую неделю, экономя время и бюджет компании.",
    for: "Руководители, HR, команды маркетинга и продукта, разработчики, сотрудники компаний, топ-менеджмент.",
    link: "Запросить программу", accent: "#b478dc", href: "/corporate",
    img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-02-54-QTKhkclUu1EM10vpFBKxC2LND6qwb5.jpg",
    video: null,
  },
  {
    num: "04", tag: "B2B · Продакшн", title: "AI Продакшн",
    desc: "Нужен качественный видеоконтент, но нет времени на организацию съёмок? Мы создадим AI-видео для вашего бренда: быстрее, гибче и дешевле классического продакшна.",
    for: "Бренды, рекламные агентства и компании с потребностью в регулярном контенте.",
    link: "Обсудить проект", accent: "#dc785a", href: "/production",
    img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-18-ZpR5sooExQFtU3GaThc2F9oJUwXBko.jpg",
    video: "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5889.MOV",
  },
]

const principles = [
  { num: "01", title: "Выбираем направление", text: "Расскажите о своих задачах, и мы поможем подобрать идеальный формат: от быстрого старта в нейрофото до комплексного обучения команды. Мы анализируем ваши цели заранее, чтобы обучение или продакшн дали максимальный эффект именно в вашей нише." },
  { num: "02", title: "Учимся и работаем в удобном темпе", text: "Проходите курсы в Telegram-боте в своём ритме или заказывайте корпоративный интенсив под график компании. Мы убрали лишний стресс и дедлайны, чтобы вы могли сфокусироваться на главном, а в случае продакшна забрать готовый проект уже через 5–7 дней." },
  { num: "03", title: "Внедряем технологии сразу", text: "Вы получаете не теорию, а готовые навыки и контент, созданный прямо в процессе обучения. Мы даём только актуальные инструменты и рабочие связки нейросетей, которые с первого дня экономят ваше время и выводят качество продукта на новый уровень." },
]

const testimonials = [
  { quote: "Самый полезный курс из всех похожих, которые я посещала. По-настоящему интересно, практично, отлично!", author: "Екатерина Касинская" },
  { quote: "Один из самых практичных тренингов, на которых я был, максимум инструментов для решения реальных задач.", author: "Кузин" },
  { quote: "Антон — один из моих любимых преподавателей, которому я по-настоящему доверяю. Огромный опыт, бесчисленные примеры, знания далеко за пределами курса.", author: "Владимир Ляшинский" },
  { quote: "Невероятно вовлекающий тренинг с отличной подачей, интересными активностями и советами по применению знаний на практике.", author: "Татьяна Чумакина" },
  { quote: "Самый полезный тренинг в моей жизни — можно применять на работе сразу.", author: "Елена" },
]

const faq = [
  { q: "Нужен ли технический опыт или знание AI?", a: "Нет. Курсы и тренинги разработаны так, чтобы начать с нуля. Нужны только телефон и желание разобраться." },
  { q: "Чем ваше обучение отличается от других курсов по AI?", a: "Мы не объясняем, что такое AI. Мы сразу показываем, как применять конкретные инструменты к конкретным задачам и вы работаете с результатом уже в процессе обучения." },
  { q: "Как проходят корпоративные тренинги?", a: "Онлайн или офлайн: как удобно вашей команде. Формат, длительность и программа согласовываются под ваш запрос. От одного интенсивного дня до шести месяцев с практикой между модулями." },
  { q: "Можно ли адаптировать программу под нашу отрасль?", a: "Да. Для корпоративного обучения мы изучаем специфику вашего бизнеса до начала. Банки, ритейл, маркетинговые агентства, продуктовые команды, где каждый получает программу под свои задачи." },
  { q: "Что происходит после обучения?", a: "Отвечаем на вопросы и помогаем с внедрением. Для корпоративных клиентов - возможность доработки и follow-up сессий." },
  { q: "Как начать?", a: "Напишите нам - обсудим задачу и подберём формат." },
]

const NAV_QUESTIONS = [
  {
    q: "Какую основную цель вы преследуете?",
    opts: [
      { label: "Хочу научиться создавать крутой контент для себя или блога.", result: 0 },
      { label: "Хочу внедрить AI в рабочие процессы моей компании / команды.", result: 2 },
      { label: "Мне нужен готовый результат «под ключ», учиться некогда.", result: 3 },
    ],
  },
  {
    q: "Какой тип контента для вас сейчас в приоритете?",
    opts: [
      { label: "Визуальный стиль: фотосессии, карточки товаров, портреты.", result: 0 },
      { label: "Динамика: ролики, Reels, анимация, говорящие головы.", result: 1 },
      { label: "Автоматизация: хочу, чтобы ИИ взял на себя рутину и тексты.", result: 2 },
    ],
  },
  {
    q: "Сколько времени вы готовы выделить на внедрение AI?",
    opts: [
      { label: "У меня есть пара часов в неделю, хочу учиться в своём темпе.", result: 0 },
      { label: "Нужен быстрый и мощный интенсив для всей команды.", result: 2 },
      { label: "Вообще нет времени — хочу делегировать задачу профессионалам.", result: 3 },
    ],
  },
]

const ANCHOR_POSITIONS = [
  { px: 0.12, py: 0.35 },
  { px: 0.18, py: 0.72 },
  { px: 0.82, py: 0.30 },
  { px: 0.88, py: 0.68 },
]

const DECO_NODES = [
  { px: 0.06, py: 0.18, r: 14, color: [80, 120, 220] },
  { px: 0.22, py: 0.55, r: 7, color: [90, 200, 120] },
  { px: 0.08, py: 0.82, r: 5, color: [180, 120, 220] },
  { px: 0.35, py: 0.88, r: 10, color: [220, 120, 80] },
  { px: 0.55, py: 0.92, r: 6, color: [90, 160, 220] },
  { px: 0.75, py: 0.85, r: 12, color: [80, 120, 220] },
  { px: 0.92, py: 0.50, r: 5, color: [90, 200, 120] },
  { px: 0.78, py: 0.12, r: 9, color: [220, 120, 80] },
  { px: 0.50, py: 0.08, r: 6, color: [180, 120, 220] },
  { px: 0.25, py: 0.10, r: 4, color: [90, 160, 220] },
  { px: 0.94, py: 0.18, r: 8, color: [90, 200, 120] },
  { px: 0.05, py: 0.55, r: 4, color: [220, 120, 80] },
  { px: 0.15, py: 0.90, r: 6, color: [80, 120, 220] },
  { px: 0.65, py: 0.06, r: 3, color: [180, 120, 220] },
  { px: 0.95, py: 0.85, r: 5, color: [90, 160, 220] },
  { px: 0.40, py: 0.35, r: 4, color: [80, 120, 220] },
  { px: 0.60, py: 0.65, r: 5, color: [180, 120, 220] },
  { px: 0.50, py: 0.50, r: 3, color: [90, 200, 120] },
  { px: 0.35, py: 0.60, r: 6, color: [220, 120, 80] },
  { px: 0.65, py: 0.40, r: 4, color: [90, 160, 220] },
]

const TEXT_ZONE = { x0: 0.28, x1: 0.72, y0: 0.22, y1: 0.78 }
function inTextZone(px: number, py: number) {
  return px > TEXT_ZONE.x0 && px < TEXT_ZONE.x1 && py > TEXT_ZONE.y0 && py < TEXT_ZONE.y1
}

const CLIENTS = [
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA1-iAubu0XBmCBD5j2W3oapG4JBTdpg3W.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA6-pLrgCEqlTQEWOGwhmtWzzooHaVshau.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA9-Q3tJu3cdGAAN293JjA9AN6qfnao0HC.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA7-OymXxFGIE8e13DlwOwomi4WxW58R2N.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA10-sHxhiaxtztGHcfK3lUF56jrHTkZJ7C.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA2-tOc02q6bUE24rSjkks0ytttzvh5yl6.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA5-nZQat5ZYaOAlZlh2zMTmz3hLoGnAtQ.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA4-nwPIiSrS3BHYfR9Aqco15g2ogGYcPm.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA23-5iRmnyuNqIwWlKQPjKDNB0B9Zgfofy.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A0%D0%B8%D1%81%D1%83%D0%BD%D0%BE%D0%BA31-Pq3kOrtiiHxxxXPM7BU0EzYrYaLA9y.png",
]

interface Node {
  x: number; y: number; vx: number; vy: number
  radius: number; isAnchor: boolean; anchorIdx: number
  baseX: number; baseY: number
  isDeco: boolean; decoColor: [number, number, number] | null
}

// ── BgNeuralCanvas — работает в любой секции с position:relative ──────────────
function BgNeuralCanvas({ opacity = 0.10, nodeCount = 28 }: { opacity?: number; nodeCount?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rafRef = useRef<number>()
  const nodesRef = useRef<{ x: number; y: number; vx: number; vy: number; r: number }[]>([])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")!
    let W = 0, H = 0

    function resize() {
      const parent = canvas.parentElement
      W = parent ? parent.offsetWidth : window.innerWidth
      H = parent ? parent.offsetHeight : window.innerHeight
      canvas.width = W
      canvas.height = H
      nodesRef.current = Array.from({ length: nodeCount }, () => ({
        x: Math.random() * W, y: Math.random() * H,
        vx: (Math.random() - 0.5) * 0.28, vy: (Math.random() - 0.5) * 0.28,
        r: Math.random() * 2 + 0.8,
      }))
    }

    function draw() {
      ctx.clearRect(0, 0, W, H)
      const nodes = nodesRef.current
      nodes.forEach(n => {
        n.x += n.vx; n.y += n.vy
        if (n.x < 0 || n.x > W) n.vx *= -1
        if (n.y < 0 || n.y > H) n.vy *= -1
      })
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < 175) {
            ctx.beginPath()
            ctx.moveTo(nodes[i].x, nodes[i].y)
            ctx.lineTo(nodes[j].x, nodes[j].y)
            ctx.strokeStyle = `rgba(100,120,255,${(1 - dist / 175) * 0.13})`
            ctx.lineWidth = 0.6
            ctx.stroke()
          }
        }
      }
      nodes.forEach(n => {
        ctx.beginPath()
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(100,130,255,0.13)`
        ctx.fill()
      })
      rafRef.current = requestAnimationFrame(draw)
    }

    resize()
    const ro = new ResizeObserver(resize)
    if (canvas.parentElement) ro.observe(canvas.parentElement)
    rafRef.current = requestAnimationFrame(draw)
    return () => {
      ro.disconnect()
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [nodeCount])

  return (
    <canvas
      ref={canvasRef}
      style={{
        position: "absolute",
        top: 0, left: 0,
        width: "100%", height: "100%",
        opacity,
        pointerEvents: "none",
        zIndex: 0,
      }}
    />
  )
}

// ── Hero NeuralCanvas (интерактивный) ─────────────────────────────────────────
function NeuralCanvas({ onHoverAnchor }: { onHoverAnchor: (idx: number | null, x: number, y: number) => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const nodesRef = useRef<Node[]>([])
  const mouseRef = useRef({ x: -999, y: -999 })
  const rafRef = useRef<number>()
  const hoveredRef = useRef<number | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")!
    let W = 0, H = 0

    function resize() {
      W = canvas.offsetWidth; H = canvas.offsetHeight
      canvas.width = W; canvas.height = H
      initNodes()
    }

    function initNodes() {
      const nodes: Node[] = []
      ANCHOR_POSITIONS.forEach((pos, i) => {
        nodes.push({ x: pos.px * W, y: pos.py * H, baseX: pos.px * W, baseY: pos.py * H, vx: 0, vy: 0, radius: 8, isAnchor: true, anchorIdx: i, isDeco: false, decoColor: null })
      })
      DECO_NODES.forEach(dn => {
        nodes.push({ x: dn.px * W, y: dn.py * H, baseX: dn.px * W, baseY: dn.py * H, vx: 0, vy: 0, radius: dn.r, isAnchor: false, anchorIdx: -1, isDeco: true, decoColor: dn.color as [number, number, number] })
      })
      for (let i = 0; i < 45; i++) {
        nodes.push({ x: Math.random() * W, y: Math.random() * H, baseX: 0, baseY: 0, vx: (Math.random() - 0.5) * 0.4, vy: (Math.random() - 0.5) * 0.4, radius: Math.random() * 2 + 1, isAnchor: false, anchorIdx: -1, isDeco: false, decoColor: null })
      }
      nodesRef.current = nodes
    }

    function draw() {
      ctx.clearRect(0, 0, W, H)
      const nodes = nodesRef.current
      const mx = mouseRef.current.x, my = mouseRef.current.y

      nodes.forEach((n, ni) => {
        if (n.isAnchor) { n.x += Math.sin(Date.now() * 0.0008 + n.anchorIdx * 2) * 0.3; n.y += Math.cos(Date.now() * 0.0006 + n.anchorIdx * 1.5) * 0.2; return }
        if (n.isDeco) { n.x = n.baseX + Math.sin(Date.now() * 0.0005 + ni * 1.3) * 6; n.y = n.baseY + Math.cos(Date.now() * 0.0004 + ni * 1.7) * 5; return }
        const dx = n.x - mx, dy = n.y - my
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist < 120) { n.vx += (dx / dist) * 0.15; n.vy += (dy / dist) * 0.15 }
        n.vx *= 0.98; n.vy *= 0.98; n.x += n.vx; n.y += n.vy
        if (n.x < 0) { n.x = 0; n.vx *= -1 } if (n.x > W) { n.x = W; n.vx *= -1 }
        if (n.y < 0) { n.y = 0; n.vy *= -1 } if (n.y > H) { n.y = H; n.vy *= -1 }
        const px = n.x / W, py = n.y / H
        if (inTextZone(px, py)) { const cx = (TEXT_ZONE.x0 + TEXT_ZONE.x1) / 2; const cy = (TEXT_ZONE.y0 + TEXT_ZONE.y1) / 2; n.vx += (px - cx) * 0.5; n.vy += (py - cy) * 0.5 }
      })

      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const a = nodes[i], b = nodes[j]
          const dx = a.x - b.x, dy = a.y - b.y
          const dist = Math.sqrt(dx * dx + dy * dy)
          const maxDist = (a.isAnchor || b.isAnchor || a.isDeco || b.isDeco) ? 220 : 130
          if (dist < maxDist) {
            const isSpecial = a.isAnchor || b.isAnchor || a.isDeco || b.isDeco
            const alpha = (1 - dist / maxDist) * (isSpecial ? 0.5 : 0.12)
            let color = "rgba(255,255,255,"
            const specialNode = (a.isAnchor || a.isDeco) ? a : (b.isAnchor || b.isDeco) ? b : null
            if (specialNode) {
              let r: number, g: number, bl: number
              if (specialNode.isAnchor) { const acc = PANELS[specialNode.anchorIdx].accent; r = parseInt(acc.slice(1, 3), 16); g = parseInt(acc.slice(3, 5), 16); bl = parseInt(acc.slice(5, 7), 16) }
              else { ;[r, g, bl] = specialNode.decoColor! }
              color = `rgba(${r},${g},${bl},`
            }
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y)
            ctx.strokeStyle = color + alpha + ")"; ctx.lineWidth = isSpecial ? 1 : 0.5; ctx.stroke()
          }
        }
      }

      nodes.forEach(n => {
        if (n.isAnchor || n.isDeco) {
          let r: number, g: number, bl: number, isHov: boolean, nodeR: number, glowR: number, ringR: number
          if (n.isAnchor) {
            const panel = PANELS[n.anchorIdx]; isHov = hoveredRef.current === n.anchorIdx
            r = parseInt(panel.accent.slice(1, 3), 16); g = parseInt(panel.accent.slice(3, 5), 16); bl = parseInt(panel.accent.slice(5, 7), 16)
            glowR = isHov ? 50 : 32; ringR = isHov ? 16 : 12; nodeR = isHov ? 8 : 6
            const pulse = (Math.sin(Date.now() * 0.003 + n.anchorIdx * 1.5) + 1) / 2
            ctx.beginPath(); ctx.arc(n.x, n.y, ringR + pulse * 18, 0, Math.PI * 2)
            ctx.strokeStyle = `rgba(${r},${g},${bl},${(1 - pulse) * 0.5})`; ctx.lineWidth = 1; ctx.stroke()
            const pulse2 = (Math.sin(Date.now() * 0.003 + n.anchorIdx * 1.5 + Math.PI) + 1) / 2
            ctx.beginPath(); ctx.arc(n.x, n.y, ringR + pulse2 * 28, 0, Math.PI * 2)
            ctx.strokeStyle = `rgba(${r},${g},${bl},${(1 - pulse2) * 0.25})`; ctx.lineWidth = 0.5; ctx.stroke()
          } else {
            ;[r, g, bl] = n.decoColor!; isHov = false; glowR = n.radius * 2.4; ringR = n.radius; nodeR = n.radius * 0.55
          }
          const grd = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, glowR)
          grd.addColorStop(0, `rgba(${r},${g},${bl},${n.isAnchor ? (isHov ? 0.75 : 0.5) : 0.25})`); grd.addColorStop(1, "rgba(0,0,0,0)")
          ctx.beginPath(); ctx.arc(n.x, n.y, glowR, 0, Math.PI * 2); ctx.fillStyle = grd; ctx.fill()
          ctx.beginPath(); ctx.arc(n.x, n.y, ringR, 0, Math.PI * 2); ctx.strokeStyle = `rgba(${r},${g},${bl},${isHov ? 0.9 : 0.5})`; ctx.lineWidth = 1.5; ctx.stroke()
          ctx.beginPath(); ctx.arc(n.x, n.y, nodeR, 0, Math.PI * 2); ctx.fillStyle = `rgba(${r},${g},${bl},${isHov ? 1 : 0.8})`; ctx.fill()
          ctx.beginPath(); ctx.arc(n.x - nodeR * 0.4, n.y - nodeR * 0.4, nodeR * 0.45, 0, Math.PI * 2); ctx.fillStyle = "rgba(255,255,255,0.7)"; ctx.fill()
        } else {
          const distMouse = Math.sqrt((n.x - mx) ** 2 + (n.y - my) ** 2)
          ctx.beginPath(); ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(255,255,255,${distMouse < 100 ? 0.6 : 0.15})`; ctx.fill()
        }
      })

      let found: number | null = null; let fx = 0, fy = 0
      nodes.forEach(n => {
        if (!n.isAnchor) return
        const d = Math.sqrt((n.x - mx) ** 2 + (n.y - my) ** 2)
        if (d < 20) { found = n.anchorIdx; fx = n.x; fy = n.y }
      })
      if (found !== hoveredRef.current) { hoveredRef.current = found; onHoverAnchor(found, fx, fy) }
      rafRef.current = requestAnimationFrame(draw)
    }

    resize()
    window.addEventListener("resize", resize)
    rafRef.current = requestAnimationFrame(draw)
    return () => { window.removeEventListener("resize", resize); if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [onHoverAnchor])

  return (
    <canvas
      ref={canvasRef}
      onMouseMove={e => { const r = canvasRef.current!.getBoundingClientRect(); mouseRef.current = { x: e.clientX - r.left, y: e.clientY - r.top } }}
      onMouseLeave={() => { mouseRef.current = { x: -999, y: -999 } }}
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", cursor: "crosshair" }}
    />
  )
}

// ── Navigator Section ─────────────────────────────────────────────────────────
function Navigator() {
  const isMobile = useIsMobile()
  const [started, setStarted] = useState(false)
  const [step, setStep] = useState(0)
  const [answers, setAnswers] = useState<number[]>([])
  const [isResult, setIsResult] = useState(false)
  const questions = [
    { q: "Чем вы планируете заниматься?", opts: ["Продвигать личный бренд", "Создавать контент для бизнеса", "Осваивать новую профессию"] },
    { q: "Какой формат контента вас интересует?", opts: ["Фото и изображения", "Видео и анимация", "Пока не определился"] },
    { q: "Что для вас важнее?", opts: ["Научиться самому", "Заказать готовый результат", "И то, и другое"] },
  ]
  const currentQ = questions[step]
  const handleAnswer = (idx: number) => {
    const newAnswers = [...answers, idx]
    setAnswers(newAnswers)
    if (step < 2) setStep(step + 1)
    else setIsResult(true)
  }
  const getResult = () => {
    const [a1, a2, a3] = answers
    if (a3 === 1) return { title: "AI-продакшн", desc: "Закажите готовый визуальный контент — мы сделаем всё за вас.", href: "/production", accent: ACCENT }
    if (a2 === 1) return { title: "Курс по AI-видео", desc: "Научитесь создавать видеоролики и анимацию с помощью нейросетей.", href: "/video", accent: "#D4A574" }
    return { title: "Курс по AI-фото", desc: "Освойте генерацию изображений для личного бренда или бизнеса.", href: "/photo", accent: "#7B9E89" }
  }
  const result = getResult()
  const resetQuiz = () => { setStarted(false); setStep(0); setAnswers([]); setIsResult(false) }

  return (
    <section style={{ padding: isMobile ? "0 16px 80px" : "0 40px 140px", maxWidth: "1400px", margin: "0 auto" }}>
      <div style={{ border: `1px solid ${BORDER}` }}>
        {!started && (
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1.4fr 1fr", gap: "0", background: BORDER }}>
            <div style={{ background: BG2, padding: isMobile ? "40px 28px" : "72px 64px" }}>
              <div style={{ fontFamily: it, fontSize: "10px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "20px" }}>Навигатор</div>
              <h2 style={{ fontFamily: os, fontSize: isMobile ? "36px" : "64px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "20px" }}>Не знаете,<br />с чего<br />начать?</h2>
              <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "16px", color: "rgba(255,255,255,0.4)", lineHeight: 1.75, marginBottom: isMobile ? "32px" : "0" }}>Ответьте на 3 вопроса — и мы подберём идеальный продукт под вашу задачу. Займёт меньше минуты.</p>
              <div style={{ marginTop: isMobile ? "0" : "40px" }}>
                <button onClick={() => setStarted(true)} style={{ display: "inline-flex", alignItems: "center", gap: "10px", background: "white", color: "#111", padding: isMobile ? "13px 28px" : "16px 40px", fontFamily: os, fontSize: isMobile ? "13px" : "14px", letterSpacing: "0.14em", textTransform: "uppercase" as const, border: "none", cursor: "pointer" }}>Пройти опрос →</button>
              </div>
            </div>
            <div style={{ background: BG, padding: isMobile ? "32px 28px" : "64px 56px", display: "flex", flexDirection: "column" as const, justifyContent: "center", alignItems: "flex-start", gap: "24px" }}>
              <div style={{ fontFamily: os, fontSize: isMobile ? "80px" : "120px", color: "rgba(255,255,255,0.03)", lineHeight: 1, fontWeight: 700 }}>3<br />вопроса</div>
              <div style={{ display: "flex", gap: "8px" }}>{[0, 1, 2].map(i => (<div key={i} style={{ height: "2px", width: "48px", background: "rgba(255,255,255,0.07)" }} />))}</div>
              <p style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.18)", lineHeight: 1.7 }}>Займёт меньше минуты.<br />Результат сразу после последнего ответа.</p>
            </div>
          </div>
        )}
        {started && !isResult && (
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1px 1.6fr", gap: "0", background: BORDER }}>
            <div style={{ background: BG2, padding: isMobile ? "32px 24px" : "64px 56px" }}>
              <div style={{ fontFamily: it, fontSize: "10px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "20px" }}>Вопрос {step + 1} из 3</div>
              <h2 style={{ fontFamily: os, fontSize: isMobile ? "28px" : "52px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "32px" }}>Не знаете,<br />с чего<br />начать?</h2>
              <div style={{ display: "flex", gap: "6px", marginBottom: "8px" }}>{[0, 1, 2].map(i => (<div key={i} style={{ height: "2px", flex: 1, background: i < step ? "rgba(255,255,255,0.55)" : i === step ? "rgba(255,255,255,0.25)" : "rgba(255,255,255,0.07)", transition: "background 0.3s" }} />))}</div>
              <div style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.18)" }}>{step + 1} / 3</div>
            </div>
            <div style={{ background: BORDER }} />
            <div style={{ background: BG, padding: isMobile ? "32px 24px" : "64px 56px" }}>
              <div style={{ fontFamily: os, fontSize: isMobile ? "16px" : "20px", color: "white", marginBottom: "28px", letterSpacing: "0.02em", lineHeight: 1.3 }}>{currentQ.q}</div>
              <div style={{ display: "flex", flexDirection: "column" as const, gap: "8px" }}>
                {currentQ.opts.map((opt, oi) => {
                  const accent = PRODUCTS[opt.result]?.accent ?? "rgba(255,255,255,0.3)"
                  return (
                    <button key={oi} onClick={() => pick(opt.result)}
                      style={{ padding: isMobile ? "14px 18px" : "18px 24px", border: `1px solid ${BORDER}`, background: "rgba(255,255,255,0.01)", fontFamily: it, fontSize: isMobile ? "14px" : "15px", color: "rgba(255,255,255,0.55)", cursor: "pointer", textAlign: "left" as const, width: "100%", transition: "all 0.15s", borderLeft: "3px solid transparent", display: "flex", alignItems: "center", gap: "14px" }}
                      onMouseEnter={e => { e.currentTarget.style.borderLeftColor = accent; e.currentTarget.style.color = "rgba(255,255,255,0.9)"; e.currentTarget.style.background = "rgba(255,255,255,0.03)" }}
                      onMouseLeave={e => { e.currentTarget.style.borderLeftColor = "transparent"; e.currentTarget.style.color = "rgba(255,255,255,0.55)"; e.currentTarget.style.background = "rgba(255,255,255,0.01)" }}
                    >
                      <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: accent, flexShrink: 0, opacity: 0.7 }} />{opt.label}
                    </button>
                  )
                })}
              </div>
              {step > 0 && <button onClick={back} style={{ marginTop: "20px", background: "none", border: "none", fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.2)", cursor: "pointer", padding: 0 }}>← Назад</button>}
            </div>
          </div>
        )}
        {isResult && p && (
          <div style={{ position: "relative" as const, animation: "fadeUp 0.4s ease" }}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(to right, transparent, ${p.accent}, transparent)` }} />
            <div style={{ background: BG2, padding: isMobile ? "48px 28px" : "80px 72px" }}>
              <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", gap: isMobile ? "40px" : "80px", alignItems: isMobile ? "flex-start" : "center" }}>
                <div style={{ flexShrink: 0 }}>
                  <div style={{ fontFamily: it, fontSize: "10px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "16px" }}>Результат</div>
                  <h2 style={{ fontFamily: os, fontSize: isMobile ? "40px" : "76px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "28px" }}>Мы подобрали<br />вариант<br />для вас</h2>
                  <div style={{ display: "flex", gap: "6px", marginBottom: "8px" }}>{[0, 1, 2].map(i => (<div key={i} style={{ height: "2px", width: "40px", background: "rgba(255,255,255,0.55)" }} />))}</div>
                  <div style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.18)" }}>3 / 3</div>
                </div>
                <div style={{ flex: 1, borderLeft: isMobile ? "none" : `1px solid ${BORDER}`, paddingLeft: isMobile ? "0" : "72px" }}>
                  <div style={{ fontFamily: it, fontSize: "10px", color: p.accent, letterSpacing: "0.18em", textTransform: "uppercase" as const, marginBottom: "12px" }}>Наш выбор для вас</div>
                  <div style={{ fontFamily: os, fontSize: isMobile ? "28px" : "52px", color: "white", fontWeight: 700, textTransform: "uppercase" as const, lineHeight: 0.92, marginBottom: "20px" }}>{p.title}</div>
                  <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "17px", color: "rgba(255,255,255,0.4)", lineHeight: 1.75, marginBottom: "36px", maxWidth: "520px" }}>{p.desc}</p>
                  <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", gap: "14px", alignItems: isMobile ? "stretch" : "center" }}>
                    <a href={p.href} style={{ display: "inline-block", background: "white", color: "#111", padding: isMobile ? "14px 28px" : "16px 40px", fontFamily: os, fontSize: "14px", letterSpacing: "0.14em", textDecoration: "none", textTransform: "uppercase" as const, textAlign: "center" as const }}>{p.link} →</a>
                    <button onClick={reset} style={{ background: "none", border: "none", fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.22)", cursor: "pointer", textAlign: "left" as const }}>Начать заново</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section >
  )
}

// ── CoursesDropdown ───────────────────────────────────────────────────────────
function CoursesDropdown({ isMobile, inNav = false }: { isMobile: boolean; inNav?: boolean }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    function handle(e: MouseEvent) { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener("mousedown", handle)
    return () => document.removeEventListener("mousedown", handle)
  }, [])
  const dropdownStyle: React.CSSProperties = inNav
    ? { position: "absolute", top: "100%", left: 0, marginTop: "4px", background: "#1a1a22", border: `1px solid ${BORDER}`, padding: "8px 0", minWidth: "160px", zIndex: 60 }
    : { position: "absolute", bottom: "100%", left: 0, marginBottom: "8px", background: "#1a1a22", border: `1px solid ${BORDER}`, padding: "8px 0", minWidth: "160px", zIndex: 50 }
  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button onClick={() => setOpen(o => !o)} style={{ background: "none", border: "none", fontFamily: it, fontSize: inNav ? (isMobile ? "11px" : "13px") : (isMobile ? "11px" : "12px"), color: inNav ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.18)", cursor: "pointer", display: "flex", alignItems: "center", gap: "4px", padding: inNav ? (isMobile ? "6px 10px" : "8px 18px") : "0", letterSpacing: "0.03em" }}>
        Курсы <span style={{ fontSize: "8px", opacity: 0.5 }}>{open ? "▲" : "▼"}</span>
      </button>
      {open && (
        <div style={dropdownStyle}>
          <a href="/photo" style={{ display: "block", fontFamily: it, fontSize: "13px", color: "#5aa0dc", textDecoration: "none", padding: "8px 16px" }}>AI Фото</a>
          <a href="/video" style={{ display: "block", fontFamily: it, fontSize: "13px", color: "#5ac878", textDecoration: "none", padding: "8px 16px" }}>AI Creator</a>
        </div>
      )}
    </div>
  )
}

// ── BackToTop ─────────────────────────────────────────────────────────────────
function BackToTop() {
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    function onScroll() { setVisible(window.scrollY > 600) }
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])
  return (
    <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Наверх"
      style={{ position: "fixed", bottom: "32px", right: "32px", width: "48px", height: "48px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", backdropFilter: "blur(12px)", borderRadius: "50%", color: "rgba(255,255,255,0.7)", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, opacity: visible ? 1 : 0, pointerEvents: visible ? "auto" : "none", transform: visible ? "translateY(0)" : "translateY(12px)", transition: "opacity 0.3s, transform 0.3s" }}
      onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.12)" }}
      onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.06)" }}
    >↑</button>
  )
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function Home() {
  const isMobile = useIsMobile()
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const [activeT, setActiveT] = useState(0)
  const [hoveredAnchor, setHoveredAnchor] = useState<number | null>(null)
  const [anchorPos, setAnchorPos] = useState({ x: 0, y: 0 })
  const cardHoveredRef = useRef(false)
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const prevT = () => setActiveT(i => (i - 1 + testimonials.length) % testimonials.length)
  const nextT = () => setActiveT(i => (i + 1) % testimonials.length)

  const handleHoverAnchor = useCallback((idx: number | null, x: number, y: number) => {
    if (idx !== null) {
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current)
      setHoveredAnchor(idx); setAnchorPos({ x, y })
    } else {
      hideTimerRef.current = setTimeout(() => { if (!cardHoveredRef.current) setHoveredAnchor(null) }, 200)
    }
  }, [])

  function onCardEnter() { cardHoveredRef.current = true; if (hideTimerRef.current) clearTimeout(hideTimerRef.current) }
  function onCardLeave() { cardHoveredRef.current = false; setHoveredAnchor(null) }

  return (
    <main style={{ overflowX: "hidden", fontFamily: it, background: BG }}>
      <BackToTop />

      {/* ══ HERO ══ */}
      <section id="top" style={{ position: "relative", height: "100vh", minHeight: isMobile ? "600px" : "700px", background: "#06060f", overflow: "hidden" }}>
        <nav style={{ position: "absolute", top: 0, left: 0, right: 0, zIndex: 30, display: "flex", alignItems: "center", justifyContent: "space-between", padding: isMobile ? "0 16px" : "0 56px", height: isMobile ? "56px" : "68px", background: "rgba(6,6,15,0.85)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
          <a href="/" style={{ fontFamily: os, fontSize: isMobile ? "13px" : "16px", letterSpacing: "0.22em", color: "white", textTransform: "uppercase" as const, fontWeight: 700, textDecoration: "none" }}>AI STUDIO</a>
          <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
            <CoursesDropdown isMobile={isMobile} inNav />
            {[{ label: "Тренинги", href: "/corporate" }, { label: "Продакшн", href: "/production" }, { label: "Контакт", href: "mailto:hello@aistudio.com" }].map((item, i) => (
              <a key={item.label} href={item.href} style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: i === 2 ? "#111" : "rgba(255,255,255,0.6)", textDecoration: "none", padding: isMobile ? "6px 10px" : "8px 18px", borderRadius: "3px", background: i === 2 ? "white" : "transparent", letterSpacing: "0.03em" }}>{item.label}</a>
            ))}
          </div>
        </nav>
        <NeuralCanvas onHoverAnchor={handleHoverAnchor} />
        {hoveredAnchor !== null && (() => {
          const panel = PANELS[hoveredAnchor]
          const cardW = 260
          const fromRight = anchorPos.x > window.innerWidth * 0.6
          const left = fromRight ? anchorPos.x - cardW - 24 : anchorPos.x + 24
          const top = Math.max(80, anchorPos.y - 110)
          return (
            <div onMouseEnter={onCardEnter} onMouseLeave={onCardLeave}
              style={{ position: "absolute", left, top, width: cardW, background: "rgba(8,8,18,0.97)", border: `1px solid ${panel.accent}55`, borderRadius: "10px", padding: "24px", backdropFilter: "blur(24px)", boxShadow: `0 24px 48px rgba(0,0,0,0.85), 0 0 40px ${panel.accent}18`, zIndex: 20, animation: "fadeUp 0.15s ease", pointerEvents: "auto" }}>
              <div style={{ position: "absolute", top: 0, left: "20px", right: "20px", height: "1px", background: `linear-gradient(to right, transparent, ${panel.accent}, transparent)` }} />
              <div style={{ fontFamily: it, fontSize: "10px", color: panel.accent, letterSpacing: "0.14em", textTransform: "uppercase" as const, marginBottom: "10px" }}>{panel.tag}</div>
              <div style={{ fontFamily: os, fontSize: "20px", color: "white", fontWeight: 700, lineHeight: 1.05, marginBottom: "12px" }}>{panel.title}</div>
              <div style={{ fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.45)", lineHeight: 1.65, marginBottom: "20px" }}>{panel.description}</div>
              <a href={panel.href} style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "6px", fontFamily: os, fontSize: "12px", color: "white", textDecoration: "none", background: panel.accent, padding: "11px 18px", borderRadius: "3px", letterSpacing: "0.08em" }}>{panel.link} →</a>
            </div>
          )
        })()}
        <div style={{ position: "absolute", top: "50%", left: "50%", transform: "translate(-50%, -50%)", textAlign: "center" as const, zIndex: 5, pointerEvents: "none", width: isMobile ? "90%" : "600px", padding: isMobile ? "0 16px" : "0" }}>
          <div style={{ fontFamily: it, fontSize: isMobile ? "12px" : "11px", color: "rgba(255,255,255,0.25)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: isMobile ? "12px" : "18px" }}>Generation AI Studio</div>
          <h1 style={{ fontFamily: os, fontSize: isMobile ? "42px" : "80px", color: "white", textTransform: "uppercase" as const, lineHeight: 0.88, fontWeight: 700, textShadow: "0 0 60px rgba(100,120,255,0.2)" }}>Технологии,<br />которые станут<br />вашим<br />преимуществом</h1>
          <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "17px", color: "rgba(255,255,255,0.35)", lineHeight: 1.65, maxWidth: isMobile ? "100%" : "400px", margin: isMobile ? "16px auto 0" : "20px auto 0" }}>Практические курсы и AI-решения для тех, кто не хочет тратить время на рутину.</p>
        </div>
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: "50px", background: "rgba(0,0,0,0.6)", overflow: "hidden", display: "flex", alignItems: "center", zIndex: 10 }}>
          <div className="ticker-track" style={{ display: "flex", alignItems: "center", gap: "56px", willChange: "transform" }}>
            {[...CLIENTS, ...CLIENTS].map((src, i) => (
              <img key={i} src={src} alt="" style={{ height: "22px", width: "auto", opacity: 0.5, filter: "grayscale(100%) brightness(1.5)", flexShrink: 0, display: "block" }} />
            ))}
          </div>
        </div>
      </section>

      {/* ══ STATS ══ */}
      <section style={{ background: BG2, padding: isMobile ? "48px 20px" : "88px 56px", borderBottom: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
        <BgNeuralCanvas opacity={0.09} nodeCount={22} />
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "grid", gridTemplateColumns: isMobile ? "repeat(2,1fr)" : "repeat(3,1fr)", gap: isMobile ? "32px 16px" : "0", position: "relative", zIndex: 1 }}>
          {[{ n: "2 000+", l: "выпускников по всему миру" }, { n: "50+", l: "мировых брендов доверили нам обучение команд" }, { n: "7+", l: "стран присутствия" }].map((s, i) => (
            <div key={i} style={{ padding: isMobile ? "0" : "0 0 0 40px", borderLeft: !isMobile && i > 0 ? `1px solid ${BORDER}` : "none", textAlign: isMobile ? "center" : "left" as const }}>
              <div style={{ fontFamily: os, fontSize: isMobile ? "40px" : "68px", color: "white", lineHeight: 1, fontWeight: 700 }}>{s.n}</div>
              <div style={{ fontFamily: it, fontSize: isMobile ? "12px" : "15px", color: "rgba(255,255,255,0.28)", marginTop: "10px" }}>{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ══ PRODUCTS ══ */}
      <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
        <BgNeuralCanvas opacity={0.09} nodeCount={28} />
        <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
          <div style={{ fontFamily: it, fontSize: isMobile ? "12px" : "12px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "16px" }}>Наши продукты</div>
          <h2 style={{ fontFamily: os, fontSize: isMobile ? "38px" : "80px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: isMobile ? "40px" : "72px" }}>Что мы делаем</h2>
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: "1px", background: BORDER }}>
            {PRODUCTS.map((p, i) => {
              const imgLeft = !isMobile && i % 2 === 0
              return (
                <div key={i} style={{ background: BG, position: "relative" as const, overflow: "hidden", display: "flex", flexDirection: "row", minHeight: "280px", transition: "background 0.25s" }}
                  onMouseEnter={e => (e.currentTarget.style.background = "#16161e")}
                  onMouseLeave={e => (e.currentTarget.style.background = BG)}
                >
                  <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(to right, transparent, ${p.accent}60, transparent)`, zIndex: 1 }} />
                  <div style={{ flexShrink: 0, width: isMobile ? "120px" : "220px", height: "auto", position: "relative", overflow: "hidden" }}>
                    {p.video ? (
                      <video src={p.video} autoPlay loop muted playsInline style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
                    ) : (
                      <img src={p.img} alt={p.title} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top", display: "block" }} />
                    )}
                    <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to right, transparent 50%, rgba(13,13,18,0.8))" }} />
                  </div>
                  <div style={{ padding: isMobile ? "20px 16px" : "28px 32px", flex: 1, display: "flex", flexDirection: "column" as const, justifyContent: "center" }}>
                    <div style={{ fontFamily: os, fontSize: isMobile ? "40px" : "56px", color: "rgba(255,255,255,0.03)", lineHeight: 1, fontWeight: 700, marginBottom: "4px" }}>{p.num}</div>
                    <div style={{ fontFamily: it, fontSize: "11px", color: p.accent, letterSpacing: "0.18em", textTransform: "uppercase" as const, marginBottom: "10px" }}>{p.tag}</div>
                    <h3 style={{ fontFamily: os, fontSize: isMobile ? "20px" : "26px", fontWeight: 700, textTransform: "uppercase" as const, lineHeight: 1.1, marginBottom: "14px", color: "white" }}>{p.title}</h3>
                    <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", color: "rgba(255,255,255,0.42)", lineHeight: 1.8, marginBottom: "10px" }}>{p.desc}</p>
                    <p style={{ fontFamily: it, fontSize: isMobile ? "11px" : "12px", color: "rgba(255,255,255,0.22)", lineHeight: 1.7, marginBottom: "24px" }}><span style={{ color: "rgba(255,255,255,0.35)" }}>Для кого: </span>{p.for}</p>
                    <a href={p.href} style={{ fontFamily: it, fontSize: "13px", color: p.accent, display: "inline-flex", alignItems: "center", gap: "6px", textDecoration: "none", letterSpacing: "0.04em", borderBottom: `1px solid ${p.accent}40`, paddingBottom: "2px", alignSelf: "flex-start", marginTop: "auto" }}>{p.link} →</a>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* ══ NAVIGATOR ══ */}
      <Navigator />

      {/* ══ HOW WE WORK ══ */}
      <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
        <BgNeuralCanvas opacity={0.09} nodeCount={24} />
        <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
          <h2 style={{ fontFamily: os, fontSize: isMobile ? "36px" : "80px", color: "white", lineHeight: 0.9, maxWidth: "800px", marginBottom: isMobile ? "40px" : "80px", textTransform: "uppercase" as const, fontWeight: 700 }}>От первого вопроса<br />до результата</h2>
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(3,1fr)", gap: "1px", background: BORDER }}>
            {[
              { ...principles[0], img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_16-28-01-NT3CLuOhqb0Xu63tPCaWC3y5VeEN47.jpg" },
              { ...principles[1], img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/learning-roses-new-ratN52A1vhwNJPAuzA7RJs0V14OtW8.png" },
              { ...principles[2], img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-35-7Fcnkv6w1iyTAZSn7AruubwDdjcBNo.jpg" },
            ].map((pr, i) => (
              <div key={i} style={{ background: BG, display: "flex", flexDirection: "column" as const, position: "relative" as const }}>
                <div style={{ width: "100%", height: isMobile ? "160px" : "200px", overflow: "hidden", flexShrink: 0, position: "relative" }}>
                  <img src={pr.img} alt={pr.title} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top" }} />
                  <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, transparent 50%, rgba(13,13,18,0.6))" }} />
                </div>
                <div style={{ padding: isMobile ? "24px 20px 28px" : "32px 32px 40px" }}>
                  <div style={{ fontFamily: os, fontSize: isMobile ? "32px" : "48px", color: "rgba(255,255,255,0.05)", lineHeight: 1, marginBottom: "14px", fontWeight: 700 }}>{pr.num}</div>
                  <h3 style={{ fontFamily: os, fontSize: isMobile ? "15px" : "18px", color: "white", textTransform: "uppercase" as const, marginBottom: "12px", letterSpacing: "0.05em" }}>{pr.title}</h3>
                  <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "15px", color: "rgba(255,255,255,0.38)", lineHeight: 1.8 }}>{pr.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ TESTIMONIALS ══ */}
      <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
        <BgNeuralCanvas opacity={0.08} nodeCount={20} />
        <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
          <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "flex-end", marginBottom: isMobile ? "32px" : "64px", gap: isMobile ? "24px" : "0" }}>
            <h2 style={{ fontFamily: os, fontSize: isMobile ? "36px" : "80px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}>Что говорят<br />те, кто уже прошёл</h2>
            <div style={{ display: "flex", gap: "12px" }}>
              <button onClick={prevT} style={{ width: isMobile ? "44px" : "52px", height: isMobile ? "44px" : "52px", border: "1px solid rgba(255,255,255,0.15)", borderRadius: "50%", background: "none", color: "white", fontSize: isMobile ? "16px" : "20px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
              <button onClick={nextT} style={{ width: isMobile ? "44px" : "52px", height: isMobile ? "44px" : "52px", border: "1px solid rgba(255,255,255,0.15)", borderRadius: "50%", background: "none", color: "white", fontSize: isMobile ? "16px" : "20px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>→</button>
            </div>
          </div>
          <div style={{ background: BG, padding: isMobile ? "32px 20px" : "64px 56px", marginBottom: "1px" }}>
            <div style={{ fontFamily: os, fontSize: isMobile ? "64px" : "120px", color: "rgba(255,255,255,0.04)", lineHeight: 0.75, marginBottom: isMobile ? "20px" : "32px", fontWeight: 700 }}>"</div>
            <p style={{ fontFamily: os, fontSize: isMobile ? "22px" : "36px", color: "white", lineHeight: 1.3, marginBottom: isMobile ? "24px" : "36px", maxWidth: "800px", fontWeight: 400 }}>{testimonials[activeT].quote}</p>
            <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", color: "rgba(255,255,255,0.35)", letterSpacing: "0.06em" }}>— {testimonials[activeT].author}</p>
          </div>
          <div style={{ display: isMobile ? "none" : "grid", gridTemplateColumns: `repeat(${testimonials.length}, 1fr)`, gap: "1px", background: BORDER }}>
            {testimonials.map((t, i) => (
              <div key={i} onClick={() => setActiveT(i)} style={{ background: i === activeT ? "#1a1a22" : BG2, padding: "20px 24px", cursor: "pointer", borderTop: i === activeT ? "2px solid rgba(255,255,255,0.3)" : "2px solid transparent", transition: "all 0.2s" }}>
                <p style={{ fontFamily: it, fontSize: "13px", color: i === activeT ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.2)", lineHeight: 1.5, marginBottom: "8px" }}>{t.quote.slice(0, 50)}…</p>
                <p style={{ fontFamily: it, fontSize: "12px", color: i === activeT ? "rgba(255,255,255,0.35)" : "rgba(255,255,255,0.12)" }}>— {t.author}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ FAQ ══ */}
      <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
        <BgNeuralCanvas opacity={0.09} nodeCount={26} />
        <div style={{ maxWidth: "1200px", margin: "0 auto", position: "relative", zIndex: 1 }}>
          {isMobile ? (
            <>
              <h2 style={{ fontFamily: os, fontSize: "36px", color: "white", lineHeight: 0.9, marginBottom: "36px", textTransform: "uppercase" as const, fontWeight: 700 }}>Частые<br />вопросы</h2>
              {faq.map((item, i) => (
                <div key={i} style={{ borderTop: `1px solid ${BORDER}` }}>
                  <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const }}>
                    <span style={{ fontFamily: os, fontSize: "15px", color: "white", maxWidth: "85%" }}>{item.q}</span>
                    <span style={{ fontFamily: os, fontSize: "24px", color: "rgba(255,255,255,0.2)", flexShrink: 0, marginLeft: "12px", lineHeight: 1 }}>{openFaq === i ? "−" : "+"}</span>
                  </button>
                  {openFaq === i && <p style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85, paddingBottom: "20px" }}>{item.a}</p>}
                </div>
              ))}
              <div style={{ borderTop: `1px solid ${BORDER}` }} />
            </>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: "80px", alignItems: "start" }}>
              <div style={{ position: "sticky", top: "100px" }}>
                <div style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "24px" }}>FAQ</div>
                <h2 style={{ fontFamily: os, fontSize: "80px", color: "white", lineHeight: 0.88, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "32px" }}>Частые<br />вопросы</h2>
                <p style={{ fontFamily: it, fontSize: "16px", color: "rgba(255,255,255,0.25)", lineHeight: 1.7 }}>Не нашли ответ?<br />Напишите нам.</p>
                <a href="mailto:hello@aistudio.com" style={{ display: "inline-flex", alignItems: "center", gap: "8px", marginTop: "28px", fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.4)", textDecoration: "none", borderBottom: "1px solid rgba(255,255,255,0.12)", paddingBottom: "2px" }}>Написать нам →</a>
              </div>
              <div>
                {faq.map((item, i) => (
                  <div key={i} style={{ borderTop: `1px solid ${BORDER}` }}>
                    <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "28px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const }}>
                      <span style={{ fontFamily: os, fontSize: "20px", color: "white", maxWidth: "85%" }}>{item.q}</span>
                      <span style={{ fontFamily: os, fontSize: "30px", color: "rgba(255,255,255,0.2)", flexShrink: 0, marginLeft: "20px", lineHeight: 1 }}>{openFaq === i ? "−" : "+"}</span>
                    </button>
                    {openFaq === i && <p style={{ fontFamily: it, fontSize: "16px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85, paddingBottom: "28px", maxWidth: "560px" }}>{item.a}</p>}
                  </div>
                ))}
                <div style={{ borderTop: `1px solid ${BORDER}` }} />
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ══ CTA ══ */}
      <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "160px 56px 140px", borderTop: `1px solid ${BORDER}`, position: "relative", overflow: "hidden" }}>
        <BgNeuralCanvas opacity={0.11} nodeCount={30} />
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: isMobile ? "32px" : "80px", alignItems: "center", position: "relative", zIndex: 1 }}>
          <h2 style={{ fontFamily: os, fontSize: isMobile ? "48px" : "96px", color: "white", lineHeight: 0.88, textTransform: "uppercase" as const, fontWeight: 700 }}>Готовы<br />начать?</h2>
          <div>
            <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "18px", color: "rgba(255,255,255,0.4)", lineHeight: 1.75, marginBottom: isMobile ? "28px" : "40px" }}>Напишите нам - расскажем, какой продукт подойдёт под вашу задачу, и ответим на любые вопросы.</p>
            <a href="mailto:hello@aistudio.com" style={{ display: "inline-block", background: "white", color: "#111110", padding: isMobile ? "14px 32px" : "18px 44px", fontFamily: os, fontSize: isMobile ? "13px" : "15px", letterSpacing: "0.14em", textDecoration: "none", textTransform: "uppercase" as const }}>Написать нам →</a>
            <p style={{ fontFamily: it, fontSize: isMobile ? "12px" : "14px", color: "rgba(255,255,255,0.2)", marginTop: isMobile ? "16px" : "20px" }}>Отвечаем в течение нескольких часов.</p>
          </div>
        </div>
      </section>

      {/* ══ FOOTER ══ */}
      <footer style={{ background: BG, padding: isMobile ? "28px 20px" : "36px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: "center", gap: isMobile ? "20px" : "0" }}>
          <a href="/" style={{ fontFamily: os, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.15)", letterSpacing: "0.2em", textTransform: "uppercase" as const, textDecoration: "none" }}>AI STUDIO</a>
          <div style={{ display: "flex", gap: isMobile ? "20px" : "32px", flexWrap: "wrap" as const, justifyContent: "center", alignItems: "center" }}>
            <CoursesDropdown isMobile={isMobile} />
            {[{ label: "Тренинги", href: "/corporate" }, { label: "Продакшн", href: "/production" }, { label: "Контакт", href: "mailto:hello@aistudio.com" }].map(item => (
              <a key={item.label} href={item.href} style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.18)", textDecoration: "none" }}>{item.label}</a>
            ))}
          </div>
          <span style={{ fontFamily: it, fontSize: isMobile ? "10px" : "12px", color: "rgba(255,255,255,0.1)" }}>© 2026</span>
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: "24px", marginTop: "20px", paddingTop: "16px", borderTop: `1px solid ${BORDER}` }}>
          <a href="/terms" style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", textDecoration: "none" }}>Условия использования</a>
          <a href="/privacy" style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", textDecoration: "none" }}>Политика конфиденциальности</a>
        </div>
      </footer>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&family=Inter:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        .ticker-track { animation: ticker 18s linear infinite; }
        .ticker-track:hover { animation-play-state: paused; }
        @keyframes ticker { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </main>
  )
}
