"use client"

import Link from "next/link"
import { useIsMobile } from "@/hooks/use-mobile"

const BG = "#0d0d12"
const BORDER = "rgba(255,255,255,0.06)"
const os = "'Oswald', sans-serif"
const it = "'Inter', sans-serif"
const ACCENT = "#5ac878"

export default function TermsPage() {
  const isMobile = useIsMobile()

  return (
    <div style={{ background: BG, minHeight: "100vh", color: "white" }}>
      {/* Nav */}
      <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, background: "rgba(13,13,18,0.92)", backdropFilter: "blur(12px)", borderBottom: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1400px", margin: "0 auto", padding: isMobile ? "16px 20px" : "18px 40px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Link href="/" style={{ fontFamily: os, fontSize: isMobile ? "18px" : "22px", fontWeight: 700, color: "white", textDecoration: "none", letterSpacing: "0.08em" }}>
            GENERATION<span style={{ color: ACCENT }}>AI</span>
          </Link>
          <div style={{ display: "flex", gap: isMobile ? "12px" : "24px", alignItems: "center" }}>
            <Link href="/photo" style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>AI Фото</Link>
            <Link href="/video" style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>AI Creator</Link>
            <Link href="/production" style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Продакшн</Link>
          </div>
        </div>
      </nav>

      {/* Content */}
      <main style={{ maxWidth: "800px", margin: "0 auto", padding: isMobile ? "100px 20px 80px" : "140px 40px 120px" }}>
        <h1 style={{ fontFamily: os, fontSize: isMobile ? "32px" : "48px", fontWeight: 700, textTransform: "uppercase", marginBottom: "16px", letterSpacing: "0.04em" }}>
          Условия использования
        </h1>
        <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "14px", color: "rgba(255,255,255,0.4)", marginBottom: "48px" }}>
          Последнее обновление: 3 апреля 2026
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: "40px" }}>
          <Section num="1" title="Введение">
            <p>Это Соглашение об условиях использования («Соглашение») регулирует использование вами образовательных продуктов и услуг Generation AI («Сервис»). Получая доступ к Сервису или используя его, вы соглашаетесь соблюдать настоящее Соглашение. Если вы не согласны с этими условиями, пожалуйста, не используйте Сервис.</p>
          </Section>

          <Section num="2" title="Описание сервиса">
            <p>Сервис предоставляет доступ к онлайн-курсам, корпоративным тренингам и образовательным материалам в области искусственного интеллекта. Для доступа к отдельным материалам может потребоваться регистрация или вход через учётную запись сторонней платформы, такой как Google или Facebook («Сторонняя платформа»).</p>
          </Section>

          <Section num="3" title="Изменения в сервисе">
            <p>Мы оставляем за собой право изменять, приостанавливать или прекращать работу любой части Сервиса в любое время без предварительного уведомления, в том числе обновлять содержание курсов и форматы обучения.</p>
          </Section>

          <Section num="4" title="Учётные записи пользователей">
            <p>Для доступа к отдельным курсам и материалам вам может потребоваться создать учётную запись. Вы несёте ответственность за сохранность своих учётных данных и за все действия, совершённые под вашей учётной записью. Доступ к курсам предоставляется лично вам и не может передаваться третьим лицам. При оплате корпоративного тренинга условия доступа для команды согласовываются отдельно.</p>
          </Section>

          <Section num="5" title="Интеллектуальная собственность">
            <p>Все материалы Сервиса — видеоуроки, презентации, рабочие тетради, тексты, методики и иные учебные материалы — являются собственностью Generation AI и защищены законодательством об интеллектуальной собственности. Вы получаете ограниченную личную лицензию на просмотр и использование материалов исключительно в учебных целях. Копирование, распространение, публичная демонстрация или перепродажа материалов без письменного согласия Generation AI запрещены.</p>
          </Section>

          <Section num="6" title="Поведение пользователя">
            <p>Вы соглашаетесь не:</p>
            <ul style={{ marginTop: "12px", paddingLeft: "20px", display: "flex", flexDirection: "column", gap: "8px" }}>
              <li>использовать Сервис для любых незаконных целей или в нарушение применимых законов;</li>
              <li>выдавать себя за другое лицо или организацию;</li>
              <li>распространять учебные материалы Сервиса без письменного разрешения;</li>
              <li>вмешиваться в работу Сервиса или нарушать её;</li>
              <li>нарушать применимые законы об экспортном контроле или иные нормативные акты.</li>
            </ul>
          </Section>

          <Section num="7" title="Отказ от гарантий">
            <p>Сервис предоставляется «как есть» без каких-либо гарантий, явных или подразумеваемых, включая, но не ограничиваясь гарантиями товарной пригодности, пригодности для определённой цели и ненарушения прав. Мы не гарантируем конкретных результатов обучения, поскольку они зависят от индивидуальных усилий и обстоятельств каждого участника.</p>
          </Section>

          <Section num="8" title="Ограничение ответственности">
            <p>Ни при каких обстоятельствах Generation AI и его аффилированные лица не несут ответственности за косвенные, случайные, специальные, последующие или штрафные убытки, включая убытки за потерю прибыли, репутации, данных или иных нематериальных ценностей, возникающих в связи с использованием или невозможностью использования Сервиса.</p>
          </Section>

          <Section num="9" title="Возмещение ущерба">
            <p>Вы соглашаетесь возместить ущерб и освободить Generation AI от любых претензий, обязательств, убытков и расходов, возникающих в связи с использованием вами Сервиса или нарушением настоящего Соглашения.</p>
          </Section>

          <Section num="10" title="Применимое право">
            <p>Настоящее Соглашение регулируется и толкуется в соответствии с законодательством Европейского Союза.</p>
          </Section>

          <Section num="11" title="Изменения">
            <p>Мы оставляем за собой право изменять настоящее Соглашение в любое время. Изменения вступают в силу с момента публикации на сайте Сервиса.</p>
          </Section>

          <Section num="12" title="Контактная информация">
            <p>Если у вас есть вопросы об этом Соглашении, свяжитесь с нами:</p>
            <p style={{ marginTop: "12px" }}>
              <strong>Generation AI</strong><br />
              <a href="mailto:info@newgeneraition.ai" style={{ color: ACCENT, textDecoration: "none" }}>info@newgeneraition.ai</a>
            </p>
          </Section>

          <div style={{ marginTop: "24px", padding: "24px", background: "rgba(90,200,120,0.06)", border: `1px solid ${ACCENT}30`, borderRadius: "4px" }}>
            <p style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.7)", lineHeight: 1.8 }}>
              Используя Сервис, вы подтверждаете, что ознакомились с настоящим Соглашением и принимаете его условия.
            </p>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer style={{ borderTop: `1px solid ${BORDER}`, padding: isMobile ? "40px 20px" : "60px 40px" }}>
        <div style={{ maxWidth: "1400px", margin: "0 auto", display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "center" : "flex-start", gap: "24px" }}>
          <div style={{ textAlign: isMobile ? "center" : "left" }}>
            <div style={{ fontFamily: os, fontSize: "18px", fontWeight: 700, color: "white", letterSpacing: "0.08em", marginBottom: "8px" }}>
              GENERATION<span style={{ color: ACCENT }}>AI</span>
            </div>
            <p style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.35)" }}>
              © 2026 Generation AI. Все права защищены.
            </p>
          </div>
          <div style={{ display: "flex", gap: "24px", flexWrap: "wrap", justifyContent: "center" }}>
            <Link href="/terms" style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.5)", textDecoration: "none" }}>Условия использования</Link>
            <Link href="/privacy" style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.5)", textDecoration: "none" }}>Политика конфиденциальности</Link>
            <a href="mailto:info@newgeneraition.ai" style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.5)", textDecoration: "none" }}>Контакты</a>
          </div>
        </div>
      </footer>
    </div>
  )
}

function Section({ num, title, children }: { num: string; title: string; children: React.ReactNode }) {
  const it = "'Inter', sans-serif"
  const os = "'Oswald', sans-serif"
  return (
    <div>
      <h2 style={{ fontFamily: os, fontSize: "20px", fontWeight: 600, textTransform: "uppercase", marginBottom: "16px", letterSpacing: "0.04em", display: "flex", alignItems: "center", gap: "12px" }}>
        <span style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.3)", fontWeight: 400 }}>{num}.</span>
        {title}
      </h2>
      <div style={{ fontFamily: it, fontSize: "15px", color: "rgba(255,255,255,0.65)", lineHeight: 1.85 }}>
        {children}
      </div>
    </div>
  )
}
