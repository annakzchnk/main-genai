"use client"

import Link from "next/link"
import { useIsMobile } from "@/hooks/use-mobile"

const BG = "#0d0d12"
const BORDER = "rgba(255,255,255,0.06)"
const os = "'Oswald', sans-serif"
const it = "'Inter', sans-serif"
const ACCENT = "#5ac878"

export default function PrivacyPage() {
  const isMobile = useIsMobile()

  return (
    <div style={{ background: BG, minHeight: "100vh", color: "white" }}>
      {/* Nav */}
      <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, background: "rgba(13,13,18,0.92)", backdropFilter: "blur(12px)", borderBottom: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1400px", margin: "0 auto", padding: isMobile ? "16px 20px" : "18px 40px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <Link href="/" style={{ fontFamily: os, fontSize: isMobile ? "18px" : "22px", fontWeight: 700, color: "white", textDecoration: "none", letterSpacing: "0.08em" }}>
            GENERATION<span style={{ color: ACCENT }}>AI</span>
          </Link>
          <div style={{ display: "flex", gap: isMobile ? "12px" : "24px", alignItems: "center" }}>
            <Link href="/photo" style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>AI Фото</Link>
            <Link href="/video" style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>AI Creator</Link>
            <Link href="/production" style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.6)", textDecoration: "none" }}>Продакшн</Link>
          </div>
        </div>
      </nav>

      {/* Content */}
      <main style={{ maxWidth: "800px", margin: "0 auto", padding: isMobile ? "100px 20px 80px" : "140px 40px 120px" }}>
        <h1 style={{ fontFamily: os, fontSize: isMobile ? "32px" : "48px", fontWeight: 700, textTransform: "uppercase", marginBottom: "16px", letterSpacing: "0.04em" }}>
          Политика конфиденциальности
        </h1>
        <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "14px", color: "rgba(255,255,255,0.4)", marginBottom: "48px" }}>
          Последнее обновление: 3 апреля 2026 года
        </p>

        <div style={{ display: "flex", flexDirection: "column", gap: "40px" }}>
          <Section num="1" title="Введение">
            <p>Эта Политика конфиденциальности описывает, как Generation AI собирает, использует, раскрывает и защищает вашу личную информацию. Используя наш веб-сайт, вы соглашаетесь с практиками, описанными в этой политике.</p>
          </Section>

          <Section num="2" title="Сбор информации">
            <p>Когда вы регистрируетесь для использования наших услуг или посещаете наш веб-сайт, мы можем собирать следующие типы личной информации:</p>
            <ul style={{ marginTop: "12px", paddingLeft: "20px", display: "flex", flexDirection: "column", gap: "8px" }}>
              <li><strong>Информация, которую вы предоставляете</strong> — имя, адрес электронной почты и другие данные, которыми вы делитесь с нами.</li>
              <li><strong>Информация от сторонних платформ</strong> — если вы входите через Google, Facebook или другие сервисы, мы можем получать ваше имя, фото профиля, адрес электронной почты и иные публично доступные данные.</li>
            </ul>
          </Section>

          <Section num="3" title="Как мы используем вашу информацию">
            <p>Мы используем собранные данные для следующих целей:</p>
            <ul style={{ marginTop: "12px", paddingLeft: "20px", display: "flex", flexDirection: "column", gap: "8px" }}>
              <li>предоставление наших услуг и продуктов;</li>
              <li>коммуникация с вами о наших услугах и продуктах;</li>
              <li>персонализация вашего опыта на платформе;</li>
              <li>анализ и улучшение качества услуг;</li>
              <li>соблюдение требований законодательства.</li>
            </ul>
          </Section>

          <Section num="4" title="Передача вашей информации">
            <p>Мы можем передавать вашу информацию третьим сторонам в следующих случаях:</p>
            <ul style={{ marginTop: "12px", paddingLeft: "20px", display: "flex", flexDirection: "column", gap: "8px" }}>
              <li><strong>Сторонние поставщики услуг.</strong> Мы не передаём вашу личную информацию третьим сторонам в коммерческих целях. Отдельные обезличенные данные могут передаваться смежным системам для обеспечения работы платформы.</li>
              <li><strong>Юридические требования.</strong> Мы можем раскрыть информацию для соблюдения законодательных обязательств или защиты наших прав.</li>
              <li><strong>С вашего согласия.</strong> В иных случаях передача данных осуществляется только с вашего явного согласия.</li>
            </ul>
          </Section>

          <Section num="5" title="Сторонние платформы">
            <p>Мы можем интегрироваться со сторонними платформами (Google, Facebook и др.), чтобы обеспечить вход на наш сайт через ваши учётные данные. Ознакомьтесь с политиками конфиденциальности этих платформ, чтобы узнать, как они обрабатывают ваши данные.</p>
          </Section>

          <Section num="6" title="Защита данных">
            <p>Мы принимаем разумные технические и организационные меры для защиты вашей личной информации от несанкционированного доступа, изменения, раскрытия или уничтожения. Вместе с тем ни один способ передачи данных через интернет не является абсолютно защищённым, и мы не можем гарантировать полную безопасность.</p>
          </Section>

          <Section num="7" title="Изменения в политике">
            <p>Мы можем периодически обновлять эту Политику конфиденциальности. О существенных изменениях мы уведомим вас через сайт или напрямую.</p>
          </Section>

          <Section num="8" title="Контакты">
            <p>Если у вас есть вопросы об этой Политике конфиденциальности или наших практиках обработки данных, свяжитесь с нами:</p>
            <p style={{ marginTop: "12px" }}>
              <strong>Generation AI</strong><br />
              <a href="mailto:info@newgeneraition.ai" style={{ color: ACCENT, textDecoration: "none" }}>info@newgeneraition.ai</a>
            </p>
          </Section>
        </div>
      </main>

      {/* Footer */}
      <footer style={{ borderTop: `1px solid ${BORDER}`, padding: isMobile ? "40px 20px" : "60px 40px" }}>
        <div style={{ maxWidth: "1400px", margin: "0 auto", display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "center" : "flex-start", gap: "24px" }}>
          <div style={{ textAlign: isMobile ? "center" : "left" }}>
            <div style={{ fontFamily: os, fontSize: "18px", fontWeight: 700, color: "white", letterSpacing: "0.08em", marginBottom: "8px" }}>
              GENERATION<span style={{ color: ACCENT }}>AI</span>
            </div>
            <p style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.35)" }}>
              © 2026 Generation AI. Все права защищены.
            </p>
          </div>
          <div style={{ display: "flex", gap: "24px", flexWrap: "wrap", justifyContent: "center" }}>
            <Link href="/terms" style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.5)", textDecoration: "none" }}>Условия использования</Link>
            <Link href="/privacy" style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.5)", textDecoration: "none" }}>Политика конфиденциальности</Link>
            <a href="mailto:info@newgeneraition.ai" style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.5)", textDecoration: "none" }}>Контакты</a>
          </div>
        </div>
      </footer>
    </div>
  )
}

function Section({ num, title, children }: { num: string; title: string; children: React.ReactNode }) {
  const it = "'Inter', sans-serif"
  const os = "'Oswald', sans-serif"
  return (
    <div>
      <h2 style={{ fontFamily: os, fontSize: "20px", fontWeight: 600, textTransform: "uppercase", marginBottom: "16px", letterSpacing: "0.04em", display: "flex", alignItems: "center", gap: "12px" }}>
        <span style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.3)", fontWeight: 400 }}>{num}.</span>
        {title}
      </h2>
      <div style={{ fontFamily: it, fontSize: "15px", color: "rgba(255,255,255,0.65)", lineHeight: 1.85 }}>
        {children}
      </div>
    </div>
  )
}
