"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { useIsMobile } from "@/hooks/use-mobile"
import { t } from "@/lib/i18n"

const BG = "#0d0d12"
const BG2 = "#111118"
const BORDER = "rgba(255,255,255,0.06)"
const os = "'Oswald', sans-serif"
const it = "'Inter', sans-serif"
const ACCENT = "#5ac878"

const HERO_IMAGES: (string | null)[] = [
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-25-ZXEt56RIUAlWBX6VTtxcygBR6KakBB.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-39-fjNeDMeZyabNir85zxwXVTu85VSQxe.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/faf55a1512f825299cca85a99bd5bf65_1b94cdc8-62c3-4ad8-ae0c-c42600da9686_500-fmBscVC3wzkdvuaKjPRCdvIhcF3VmJ.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/5819528581d9a87474678eb1a25a4288_8ab449d3-35fb-4065-bf74-e31a2eb8dc32_500-eyuG1dLpj1kEfV1KroEacl9GaI6tkW.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/aacf8e59e063502b2e96ae8752ca446b_5ce0cb02-700e-48fe-a0ff-6e859cec741e_500-5m9iVtyAR7e4AdCzRIxd0RXAqQvUA8.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-07-udS6ZMd3VjDeeK2u5IW1s5QhV1usHL.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a406d598a9304a998087b7cb83182b27_0571a753-842a-424b-aff5-6e7cc3cc13d3_500-8MTrpDb9Drfd4kKoC4VdnxL00TDRXh.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-54-MQLVcyUdOU5MaDsaFOyqNBvdGYx9Rc.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-10-y1DCtwpvUgWEjinjR4jwSw4SFCEiMR.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/c89bf9b11abf18f14923b6f0c4fe61fa_56c7e923-dc23-43e0-b4f5-f81872eb5285-6kUeK3Rm2nx1h2w9dEk5mOsYGIJy5b.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-48-jhpG1MwTtwGNKtygSELP5yxC1CIUxJ.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-34-6TtbYERG7TR4DnMnIgDJDFASOUVVSR.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/b02d1e18c2cdd003ce2e037558b8caa8_41544712-e6bd-417f-bbbe-d8a6b5eb477b-DnhvbqF0i2joaUwqO8OhviSVaaMsSF.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-08-5AqyCvpUkKvIAqhoAX1oIz8Ru9X3nQ.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-25-VeHaXpcIU9EDu1Owp4qjz5Bak9QiHe.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/download%20%281%29-QXcFaJGR0ok6FVNGhIDVX10BWSyhl2.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-15-UIuu0x5VzDRjpxN3Y3io9n0RaZyj9M.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/faaa4e29d43645c0ee0a828e15f57818_8b204cf1-782d-4df1-9e73-9b341e7b7f46_500-tEmCtDvq4uMfMJm47FOKAnPG2VwUEZ.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/66f6191f4cfe01ad9c31b559a6da8dca_c4087953-5b80-4c5b-8568-43a6bbe5f49c_500-GkVteajy79OtjBRosbPl3FScyvBBXk.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4c0bd87a2cb89c0844f425cdff931c9d_e8a4add0-760a-40ce-9a15-3de95f731ee8_500-8a7JBmGiFhhimyh8GFlOUwLiPLQyxV.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/download-l1YmlTWHt9NHnWxvvfbHl1PZkeDCDx.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-18-ZpR5sooExQFtU3GaThc2F9oJUwXBko.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-48-8XInInwo1SwrsPJfyfhPVj0xkqIMWw.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-38-DjSXRojzJDDY8kB0sGh3Qw3DxUfvVf.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-36-NKQ3X0zpONfY3gxyfCXQDSGT5CjwrM.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-45-eEoEybE7fQSmuB3dcZ4Cb4FFGITaYR.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-56-eSgSnHVtPccmEgrSvq28em7C8QmhSy.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-43-dAkv6ySBTd1Hp1YpFvi2ciGTHzDLEs.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-17-KRfmrwUd9dh0QWzUkFuJfeVOBzt8cr.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-52-R8rE6XPIFOFcPxNviCpWSmsDZ0Kjb5.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-11-kNSAocGVeyPYrCYWNTjMZIUhArY64F.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-14-Ir0nElCB75rTaZbh3x68oQVkyqh7Bg.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-28-r9hz1zkXIxwhOZxVlqZhr90Jwyudi8.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-05-FhNyhCc9OdCSXyyj14cnM2yGNbCzKr.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-10-WnZcPgfx2JbMVshzrMgouTmdSDOVCi.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-41-mWiC9vOJQrwoaHVYfSto85ncDV3vcQ.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-21-qYLCmGSmpbxq6MbRXMtsHG6ExknJ5v.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-31-Yj7rbZcNt909OT0p2A0wdaUknGZ7e7.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-25-1iAsLjRVqBf5SS3GS3Q2B6Y0KwFQcR.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/A_real_candid_202603302256.png-yAuJV4hX7FFM6or6w5oiRtzbxnfiYg.jpeg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/f4a6ab589add49be4b71000086fb02a2_58646b62-01ec-4d8d-9903-f5ff05acd8f0_500-nJs8VEsI1U2Dq5WVV110kVlJcyiC00.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-00-hLBeOweVkY7xpAPBGixylnI2q6swP5.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-29-zU2PgXonoKeiSV3hlsyWG6CfeJiFV7.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-51-DEuOINhot0LfHRgf7KG8zLkwK1c9Ma.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bf12d6887c8767d9c04958166ef3f0d9_6abf98a4-4a35-411b-a884-959773afcaae_500-5yakmymSKqTxLoPD8pQO7CKwqIssRR.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-35-ycICaZxYMKzxFbKKG3KZUAcz1QkbHW.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-32-EiVAjbOGjbL97Eor3fp6toxix9bfoA.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-22-SPfPTEG3UEtENUaxYylj3Q5VxkZInu.jpg",
]

const COLORS = [
  "#1e3a5f", "#2a1a4a", "#1a3a2a", "#4a2a1a", "#1a2a4a",
  "#3a1a3a", "#2a3a1a", "#4a1a2a", "#1a4a3a", "#3a2a1a",
  "#253550", "#1f2d45", "#2d1f45", "#1f452d", "#452d1f",
  "#1a2535", "#251a35", "#351a25", "#253525", "#352525",
  "#0f2040", "#200f40", "#0f4020", "#40200f", "#200f20",
  "#162030", "#201630", "#301620", "#163020", "#302020",
]
const ROWS = [
  { speed: 90, cardW: 180, cardH: 240, gap: 6, startX: 0 },
  { speed: 110, cardW: 180, cardH: 240, gap: 6, startX: -90 },
  { speed: 80, cardW: 180, cardH: 240, gap: 6, startX: -45 },
]
const CARDS_PER_ROW = 16

function buildCards(rowIdx: number) {
  return Array.from({ length: CARDS_PER_ROW * 2 }, (_, i) => {
    const globalIdx = rowIdx * CARDS_PER_ROW + (i % CARDS_PER_ROW)
    const hasImage = globalIdx < HERO_IMAGES.length
    return { color: COLORS[(rowIdx * 7 + i) % COLORS.length], image: hasImage ? HERO_IMAGES[globalIdx] : null }
  })
}

const PHOTO_COLORS = [
  "#1a2535", "#251a35", "#1a3525", "#352515", "#151a35",
  "#2a1535", "#1a352a", "#35251a", "#1a2535", "#251535",
  "#0f1a2a", "#200f2a", "#0f2a1a", "#2a1a0f", "#1a200f",
]
function photoColor(i: number) { return PHOTO_COLORS[i % PHOTO_COLORS.length] }

const moduleImages = {
  mod1: [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/module01-girl-door-k3YMTGjMonuXhZs3rvCGZ7p4iro8Jr.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/module01-girl-boat-y1wvik328iWRbbjFbBGuHvwk7kRhaQ.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/module01-girl-car-PDFeDmo4OQ6onZ6IUdN0yAyrITxjsM.jpg",
  ],
  mod2: [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/module02-freckle-profile-yJWzLHXQXpR0hnsHVeDvcChyYf3a6h.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-43-vM40HPCeS5iuYSjBgm7gUDgjkgSc3s.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-15-ruJunjRzdNewMo5IGpUqUPW3wzQASg.jpg",
  ],
  mod3: [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-00-8ocWuHIO188FGuHLfDtHGoVY4uCADb.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-38-12hmCvKN9cq4ygVUckIgr9mmTPjPO5.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-25-VeHaXpcIU9EDu1Owp4qjz5Bak9QiHe.jpg",
  ],
  mod4: [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_16-28-04-zOlHd3xWTdjQfP81ZCZnr8NDddQZ8m.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_16-27-57-wDAeObqK9hwXGHUGnVKrPxnnFWHmng.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_16-28-01-6kqsQW6FWKx8YASuJZKrbOzjPnhaSR.jpg",
  ],
  mod5: [
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/d654fc361f25867449ef00ed7674c3e3_8d46bddf-c1cc-4d37-ae91-669a517cca6e_500-mO1cdbWrFMqpWe4ecV4hugYIkF5cub.jpg",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/463976e4-f3e4-4008-bbc9-2899a604c38d-L54fY6HsQKDsM83RUzyu55nX3XaS4Y.png",
    "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/18e34138-5270-4688-b7f7-1e3a7ac372e3-tZASBK5e07Vi1WkSEBhg5eYpMB5rD5.png",
  ],
}

const modules = t.photo.program.modules.map((m, i) => ({
  ...m,
  photoIdx: i,
  images: [moduleImages.mod1, moduleImages.mod2, moduleImages.mod3, moduleImages.mod4, moduleImages.mod5][i],
}))

const forWhoImages = {
  smm: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/card-instagram-objTBnCm2OjPLu61NRf2IQ3qYVm0NE.jpg",
  experts: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/card-blue-suit-WxJzrFJ65OR9RQCuk4zetQkynYV8kz.jpg",
  marketing: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/card-marketing-4SD71lZi0iGJ5ZZd635tipEKzrS81m.jpg",
  entrepreneurs: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-59-25-eBQ6RMolgzcoOTMcgvgV5KWRLiBf3m.jpg",
}
const forWhoAccents = ["#5ac878", "#5aa0dc", "#dc785a", "#dcb45a"]
const forWho = t.photo.forWho.items.map((item, i) => ({
  ...item,
  accent: forWhoAccents[i],
  image: [forWhoImages.smm, forWhoImages.experts, forWhoImages.marketing, forWhoImages.entrepreneurs][i],
}))

const planAccents = ["#5aa0dc", "#5ac878", "#dc785a"]
const plans = t.photo.plans.items.map((item, i) => ({
  ...item,
  accent: planAccents[i],
}))

// Results images — media assets, not translatable
const resultsImages = [
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-57-pspUSKsKscutKGOtiotce8SB4v6T9G.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/result-chatgpt-ad-new-46O4poAIMeulma58Mg2DNqm1Z3cVj2.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/result-genai-website.jpg-5BkLEIkC6eXQZbyZO2f4lQ7x5wuk6q.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/result-pink-kitchen-BaFug3MCR00W44vBremukMB9u4oRHH.jpg",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/result-business-card-1YVkp0A8WEdZK6KTtG4kbBhhWzAjVr.jpg",
]

const portfolioImages = {
  p1_1: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-40-37-owTLiCZy3E79p2ByDoLbd1CuRJgwvg.jpg",
  p1_2: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-40-48-THzp4qJsF7YdpTQMiEkOnNJrocxLZG.jpg",
  p1_3: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-02-54-QTKhkclUu1EM10vpFBKxC2LND6qwb5.jpg",
  p1_4: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-25-19-0svjkR3laVYi3OjxFdlJCnCuT6TfiU.jpg",
  p1_5: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-40-06-bhCvQMOWJ3jjorubr0U8RSCSVAPaIO.jpg",
  p1_6: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-56-45-mTCQwGFiuFDZjQP4P6VzcOgZLUPDrs.jpg",
  p1_7: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/d49dd39eaa0d41551290c1c45e2786c3_7ba32ccf-d42f-483f-93dd-3d63bb3bed01_500-DxnXk1shrSLoi9mKMiFUlWqr2dIJv5.jpg",
  p1_8: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-40-33-SgvYVibI1m92GCaRZHtHOZatfzdei1.jpg",
  p2_1: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Whisk_018664fc04a0eaca11441006bfdf8926dr%20%281%29-7hTi1y7591dsIA70WToWFrXH4sPBJx.jpeg",
  p2_2: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-02-45-mbYI7DJEsDs1w0v43RJBpss9eRcWvl.jpg",
  p2_3: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-40-44-F89ngvCmf21vEqAAt5QOwcEbf6QwsW.jpg",
  p2_4: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Whisk_0b209410fb013fc83914ba8ffd0d8a79dr-jmfAwimxFBHozWtcQphEETcIVbl5Jk.jpeg",
  p2_5: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-16-26-WrpfiUuEaBRwQFfMsE7sgke6fOXlUg.jpg",
  p2_6: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-03-01-VWZhbsYfqo6j3x6Z1qxaj5KBkuWNDA.jpg",
  p2_7: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_21-57-14-LnpDbgtrwYoFZuqCSDjJVELloCbPMZ.jpg",
  p2_8: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-40-30-mcH87MZtrGXMgATS06fdt9MQb9bDBP.jpg",
  p3_1: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Whisk_1525e73d58cb704ac2b4eac89d535cfcdr-fbdQZKQnkrXx4FsW4NEYNAx1grcqXn.jpeg",
  p3_2: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-03-10-eLL4sbQ2Cib19OcJX4iyBBYFmzX1CL.jpg",
  p3_3: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-08-28-eyGM1UkorIL3hGxylpihcH31n25R97.jpg",
  p3_4: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-03-04-XOgcSCa9tGNegLUGdf4apukwG4084h.jpg",
  p4_1: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bab1f583e74a8ebf796b8b597b8e2105_e8a1410d-6208-4018-a5ec-c1cfc1859df1-cDFSfdAxtBLgITBzxz4bR2hSUcCcl7.png",
  p4_2: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_19-43-17-MtNedaU946ETkLeqDmO2GJjuaUSVXY.jpg",
  p4_3: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/de1f3c22-1f53-43f4-abc1-2b4132bad073-wIrhEhJbanKYJdYy38wk1jn4HcCh3S.png",
  p4_4: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/4d50c92a5fa769fb614fac86c9df1100_2aa85c10-47b7-4127-8000-bbe32253cc48-fZUJDwxZw57j3xJGVcc5evA70iefkl.png",
  p4_5: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/e93a3593-a2a1-4cc1-94d8-30816d8c321a-KDxn419cqrV9yj1OFtzzHbvX7rlKdt.png",
  p4_6: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-57-34-dMO4AafKnLs1brynDPzmWmw8DGioHP.jpg",
  p4_7: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a73fe1cc-183b-43c5-ba13-2bdca4c586be-pK89jmB7n7C1f0MrQW8d0b8xrNZRSY.png",
  p4_8: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-08-AEABj4wP5iaiktZAui40hVEqCRtZy2.jpg",
  p5_1: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/60e0e2c929b6362f1793754e069638e9_a2345bc9-6332-4ec1-aee3-effb8a0edc9c-iMhru3w2Xl2eQYXnV5kg5Sev0EZFfD.png",
  p5_2: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/b6aacb4f089126e9ce07749ec6b83475_e8145c2b-6987-485b-ac2a-710cfb3e7a10-UHhWapMn1ehi4S2N3HtNlRHJ2iKsw9.png",
  p5_3: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-04-20_15-58-54-3rORpwkYCQhXQGhAFbbY2IErGQmUke.jpg",
  p5_4: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/fc4a86f37f283f0933c10e35a95c56f9_82e928a7-04d9-44c4-85e3-37c5b2beff3a-tVUmENjBxxWDlL0VMOZjQaRtEJA8am.png",
  p5_5: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3cfd0e3d16af924303cb9263881f5fef_5d6f2452-ca5b-4c20-8400-fe78103b94ee-WxYtEWMrRP9kkl3niIDTare64GehYm.png",
  p5_6: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/68caeb0c8bf26c55350a75f90f700bd3_5555f589-a560-4f51-9e92-6a871f03849d-J4VuicVnGEqybwLVldJWCtdvsHbd1t.png",
}

const PORTFOLIO_PAGES = [
  [
    { h: 340, col: 1, image: portfolioImages.p1_1 },
    { h: 280, col: 1, image: portfolioImages.p1_2 },
    { h: 200, col: 2, image: portfolioImages.p1_3 },
    { h: 340, col: 2, image: portfolioImages.p1_4 },
    { h: 280, col: 3, image: portfolioImages.p1_5 },
    { h: 260, col: 3, image: portfolioImages.p1_6 },
    { h: 180, col: 4, image: portfolioImages.p1_7 },
    { h: 360, col: 4, image: portfolioImages.p1_8 },
  ],
  [
    { h: 300, col: 1, image: portfolioImages.p2_1 },
    { h: 240, col: 1, image: portfolioImages.p2_2 },
    { h: 320, col: 2, image: portfolioImages.p2_3 },
    { h: 220, col: 2, image: portfolioImages.p2_4 },
    { h: 260, col: 3, image: portfolioImages.p2_5 },
    { h: 280, col: 3, image: portfolioImages.p2_6 },
    { h: 340, col: 4, image: portfolioImages.p2_7 },
    { h: 200, col: 4, image: portfolioImages.p2_8 },
  ],
  [
    { h: 340, col: 1, image: portfolioImages.p3_1 },
    { h: 280, col: 1, image: portfolioImages.p3_2 },
    { h: 260, col: 2, image: portfolioImages.p3_3 },
    { h: 380, col: 2, image: portfolioImages.p3_4 },
    { h: 280, col: 3, image: portfolioImages.p4_1 },
    { h: 260, col: 3, image: portfolioImages.p4_2 },
    { h: 340, col: 4, image: portfolioImages.p4_3 },
    { h: 200, col: 4, image: portfolioImages.p4_4 },
  ],
  [
    { h: 300, col: 1, image: portfolioImages.p4_5 },
    { h: 260, col: 1, image: portfolioImages.p4_6 },
    { h: 340, col: 2, image: portfolioImages.p4_7 },
    { h: 200, col: 2, image: portfolioImages.p4_8 },
    { h: 280, col: 3, image: portfolioImages.p5_1 },
    { h: 260, col: 3, image: portfolioImages.p5_2 },
    { h: 340, col: 4, image: portfolioImages.p5_3 },
    { h: 200, col: 4, image: portfolioImages.p5_4 },
  ],
  [
    { h: 340, col: 1, image: portfolioImages.p5_5 },
    { h: 280, col: 1, image: portfolioImages.p5_6 },
    { h: 300, col: 2, image: portfolioImages.p2_1 },
    { h: 240, col: 2, image: portfolioImages.p2_2 },
    { h: 260, col: 3, image: portfolioImages.p1_1 },
    { h: 280, col: 3, image: portfolioImages.p1_2 },
    { h: 320, col: 4, image: portfolioImages.p1_5 },
    { h: 220, col: 4, image: portfolioImages.p1_6 },
  ],
]

function PortfolioMobile({ items }: { items: typeof PORTFOLIO_PAGES[0] }) {
  return (
    <div style={{ display: "flex", gap: "6px", overflowX: "auto", WebkitOverflowScrolling: "touch", scrollSnapType: "x mandatory", paddingBottom: "8px" }}>
      {items.map((item, idx) => (
        <div key={idx} style={{ flexShrink: 0, width: "220px", height: "300px", borderRadius: "4px", overflow: "hidden", scrollSnapAlign: "start" }}>
          <img src={item.image} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
        </div>
      ))}
    </div>
  )
}

function PortfolioGrid({ items }: { items: typeof PORTFOLIO_PAGES[0] }) {
  const cols: Record<number, typeof items> = { 1: [], 2: [], 3: [], 4: [] }
  items.forEach(item => cols[item.col].push(item))
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: "8px" }}>
      {[1, 2, 3, 4].map(c => (
        <div key={c} style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          {cols[c].map((item, idx) => (
            <div key={idx} style={{ position: "relative", height: item.h, borderRadius: "4px", overflow: "hidden" }}>
              <img src={item.image} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            </div>
          ))}
        </div>
      ))}
    </div>
  )
}

function CoursesDropdown({ isMobile, inNav = false }: { isMobile: boolean; inNav?: boolean }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    function handle(e: MouseEvent) { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener("mousedown", handle)
    return () => document.removeEventListener("mousedown", handle)
  }, [])
  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button onClick={() => setOpen(o => !o)} style={{ background: "none", border: "none", fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: inNav ? "rgba(255,255,255,0.6)" : "rgba(255,255,255,0.18)", cursor: "pointer", display: "flex", alignItems: "center", gap: "4px", padding: inNav ? (isMobile ? "6px 10px" : "8px 18px") : "0" }}>
        {t.common.nav.courses} <span style={{ fontSize: "8px", opacity: 0.5 }}>{open ? "▲" : "▼"}</span>
      </button>
      {open && (
        <div style={{ position: "absolute", ...(inNav ? { top: "100%", marginTop: "4px" } : { bottom: "100%", marginBottom: "8px" }), left: 0, background: "#1a1a22", border: `1px solid ${BORDER}`, padding: "8px 0", minWidth: "160px", zIndex: 60 }}>
          <Link href="/photo" style={{ display: "block", fontFamily: it, fontSize: "12px", color: "#5aa0dc", textDecoration: "none", padding: "8px 16px" }}>{t.common.coursesDropdown.aiPhoto}</Link>
          <Link href="/video" style={{ display: "block", fontFamily: it, fontSize: "12px", color: "#5ac878", textDecoration: "none", padding: "8px 16px" }}>{t.common.coursesDropdown.aiCreator}</Link>
        </div>
      )}
    </div>
  )
}

export default function PhotoPage() {
  const isMobile = useIsMobile()
  const [openModule, setOpenModule] = useState<number | null>(null)
  const [openProModule, setOpenProModule] = useState<number | null>(null)
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const [portfolioPage, setPortfolioPage] = useState(0)
  const trackRefs = useRef<(HTMLDivElement | null)[]>([])
  const posRef = useRef<number[]>(ROWS.map(r => r.startX))
  const rafRef = useRef<number>()
  const lastRef = useRef<number>(0)

  useEffect(() => {
    function tick(ts: number) {
      const dt = lastRef.current ? Math.min((ts - lastRef.current) / 1000, 0.05) : 0
      lastRef.current = ts
      ROWS.forEach((row, i) => {
        const el = trackRefs.current[i]
        if (!el) return
        posRef.current[i] -= row.speed * dt
        const halfWidth = CARDS_PER_ROW * (row.cardW + row.gap)
        if (posRef.current[i] <= -halfWidth) posRef.current[i] += halfWidth
        el.style.transform = `translateX(${posRef.current[i]}px)`
      })
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [])

  return (
    <main style={{ overflowX: "hidden", fontFamily: it, background: BG }}>

      {/* NAV */}
      <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, display: "flex", alignItems: "center", justifyContent: "space-between", padding: isMobile ? "0 16px" : "0 56px", height: isMobile ? "56px" : "68px", background: "rgba(10,10,20,0.85)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
        <Link href="/" style={{ fontFamily: os, fontSize: isMobile ? "13px" : "15px", letterSpacing: "0.22em", color: "white", textTransform: "uppercase" as const, fontWeight: 700, textDecoration: "none" }}>{t.common.nav.logo}</Link>
        <div style={{ display: "flex", gap: "4px" }}>
          <CoursesDropdown isMobile={isMobile} inNav />
          {[
            { label: t.common.nav.trainings, href: "/corporate" },
            { label: t.common.nav.production, href: "/production" },
            { label: t.common.nav.contact, href: "mailto:hello@aistudio.com" },
          ].map((item, i) => (
            <Link key={item.label} href={item.href} style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: i === 2 ? "#111" : "rgba(255,255,255,0.6)", textDecoration: "none", padding: isMobile ? "6px 10px" : "8px 18px", borderRadius: "3px", background: i === 2 ? "white" : "transparent", letterSpacing: "0.03em", display: isMobile && i < 2 ? "none" : "block" }}>{item.label}</Link>
          ))}
        </div>
      </nav>

      {/* ══ HERO ══ */}
      <section style={{ position: "relative", height: "100vh", minHeight: isMobile ? "600px" : "720px", overflow: "hidden", background: "#08080f" }}>
        <div style={{ position: "absolute", inset: 0, transform: isMobile ? "rotate(-15deg) scale(1.5)" : "rotate(-15deg) scale(1.3)", transformOrigin: "center center", display: "flex", flexDirection: "column", justifyContent: "center", gap: "4px", top: "-20%", left: "-10%", right: "-10%", bottom: "-20%" }}>
          {ROWS.map((row, rowIdx) => (
            <div key={rowIdx} style={{ overflow: "hidden", height: isMobile ? row.cardH * 0.6 : row.cardH, flexShrink: 0 }}>
              <div ref={el => { trackRefs.current[rowIdx] = el }} style={{ display: "flex", gap: `${row.gap}px`, willChange: "transform" }}>
                {buildCards(rowIdx).map((card, ci) => (
                  <div key={ci} style={{ width: isMobile ? row.cardW * 0.6 : row.cardW, height: isMobile ? row.cardH * 0.6 : row.cardH, flexShrink: 0, borderRadius: "6px", background: card.color, position: "relative", overflow: "hidden" }}>
                    {card.image && <img src={card.image} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.85 }} />}
                    <div style={{ position: "absolute", inset: 0, background: card.image ? "linear-gradient(to bottom, rgba(0,0,0,0.1) 0%, rgba(0,0,0,0.3) 100%)" : "none" }} />
                    <div style={{ position: "absolute", top: 0, left: "10%", right: "10%", height: "1px", background: "rgba(255,255,255,0.12)" }} />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div style={{ position: "absolute", inset: 0, background: "rgba(8,8,15,0.62)" }} />
        <div style={{ position: "absolute", inset: 0, background: "radial-gradient(ellipse at center, transparent 20%, rgba(8,8,15,0.7) 100%)" }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to bottom, #08080f 0%, transparent 20%, transparent 78%, #0d0d12 100%)" }} />
        <div style={{ position: "absolute", inset: 0, paddingTop: isMobile ? "56px" : "68px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center" as const, padding: isMobile ? "56px 20px 0" : "68px 40px 0" }}>
          <div style={{ display: "inline-block", fontFamily: it, fontSize: isMobile ? "12px" : "11px", color: ACCENT, border: `0.5px solid rgba(90,200,120,0.35)`, padding: "3px 14px", borderRadius: "2px", marginBottom: isMobile ? "16px" : "24px", letterSpacing: "0.16em" }}>{t.photo.hero.badge}</div>
          <h1 style={{ fontFamily: os, fontSize: isMobile ? "42px" : "82px", color: "white", textTransform: "uppercase" as const, lineHeight: 0.87, marginBottom: isMobile ? "16px" : "24px", fontWeight: 700, maxWidth: isMobile ? "100%" : "900px", textShadow: "0 2px 40px rgba(0,0,0,0.8)" }}
            dangerouslySetInnerHTML={{ __html: t.photo.hero.title }}
          />
          <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "17px", color: "rgba(255,255,255,0.55)", maxWidth: isMobile ? "100%" : "480px", marginBottom: isMobile ? "28px" : "40px", lineHeight: 1.65 }}>
            {t.photo.hero.subtitle}
          </p>
          <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", gap: "12px", width: isMobile ? "100%" : "auto" }}>
            <a href="mailto:hello@aistudio.com" style={{ display: "inline-block", background: "white", color: "#0d0d12", padding: isMobile ? "16px 32px" : "16px 40px", fontFamily: os, fontSize: "14px", letterSpacing: "0.1em", textDecoration: "none", borderRadius: "3px", textAlign: "center" as const, minHeight: isMobile ? "48px" : "auto" }}>{t.photo.hero.ctaPrimary}</a>
            <a href="#program" style={{ display: "inline-block", background: "transparent", border: "1px solid rgba(255,255,255,0.3)", color: "white", padding: isMobile ? "16px 32px" : "16px 40px", fontFamily: os, fontSize: "14px", letterSpacing: "0.1em", textDecoration: "none", borderRadius: "3px", textAlign: "center" as const, minHeight: isMobile ? "48px" : "auto" }}>{t.photo.hero.ctaSecondary}</a>
          </div>
        </div>
      </section>

      {/* ══ ДЛЯ КОГО ══ */}
      <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: isMobile ? "24px" : "80px", marginBottom: isMobile ? "40px" : "80px", alignItems: "end" }}>
            <h2
              style={{ fontFamily: os, fontSize: isMobile ? "38px" : "72px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}
              dangerouslySetInnerHTML={{ __html: t.photo.forWho.heading }}
            />
            <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "16px", color: "rgba(255,255,255,0.32)", lineHeight: 1.75 }}>{t.photo.forWho.subtitle}</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(4,1fr)", gap: "1px", background: BORDER }}>
            {forWho.map((item, i) => (
              <div key={i} style={{ background: BG2, display: "flex", flexDirection: "column", position: "relative" as const }}>
                <div style={{ width: "100%", height: isMobile ? 200 : 240, overflow: "hidden", flexShrink: 0 }}>
                  <img src={item.image} alt={item.title} style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                </div>
                <div style={{ position: "absolute", top: 0, left: 0, width: "48px", height: "3px", background: item.accent }} />
                <div style={{ padding: isMobile ? "20px" : "28px 28px 32px" }}>
                  <h3 style={{ fontFamily: os, fontSize: isMobile ? "16px" : "18px", color: "white", marginBottom: "10px", fontWeight: 700 }}>{item.title}</h3>
                  <p style={{ fontFamily: it, fontSize: isMobile ? "12px" : "13px", color: "rgba(255,255,255,0.38)", lineHeight: 1.7 }}>{item.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ ПРОГРАММА ══ */}
      <section id="program" style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: isMobile ? "24px" : "80px", alignItems: "end", marginBottom: isMobile ? "32px" : "64px" }}>
            <div>
              <div style={{ fontFamily: it, fontSize: isMobile ? "10px" : "11px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: "16px" }}>{t.photo.program.label}</div>
              <h2
                style={{ fontFamily: os, fontSize: isMobile ? "32px" : "72px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}
                dangerouslySetInnerHTML={{ __html: t.photo.program.heading }}
              />
            </div>
            <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", color: "rgba(255,255,255,0.32)", lineHeight: 1.75 }}>{t.photo.program.subtitle}</p>
          </div>

          <div style={{ borderTop: `1px solid ${BORDER}` }}>
            {modules.map((mod, i) => (
              <div key={i} style={{ borderBottom: `1px solid ${BORDER}` }}>
                <button onClick={() => setOpenModule(openModule === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "center", padding: isMobile ? "20px 0" : "28px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const }}>
                  <div style={{ display: "flex", alignItems: isMobile ? "flex-start" : "center", gap: isMobile ? "12px" : "16px", flexWrap: isMobile ? "wrap" : "nowrap" as const }}>
                    <div style={{ width: "8px", height: "8px", borderRadius: "50%", border: `1.5px solid ${openModule === i ? ACCENT : "rgba(255,255,255,0.2)"}`, background: openModule === i ? ACCENT : "transparent", flexShrink: 0, transition: "all 0.2s", marginTop: isMobile ? "4px" : "0" }} />
                    <span style={{ fontFamily: os, fontSize: isMobile ? "14px" : "18px", color: "white" }}>{mod.title}</span>
                  </div>
                  <span style={{ fontFamily: os, fontSize: isMobile ? "20px" : "26px", color: openModule === i ? ACCENT : "rgba(255,255,255,0.2)", flexShrink: 0, marginLeft: isMobile ? "12px" : "20px", lineHeight: 1, transition: "color 0.2s" }}>{openModule === i ? "−" : "+"}</span>
                </button>
                {openModule === i && (
                  <div style={{ paddingBottom: isMobile ? "24px" : "36px", paddingLeft: isMobile ? "0" : "24px" }}>
                    <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr auto", gap: isMobile ? "20px" : "40px" }}>
                      <div>
                        <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", color: "rgba(255,255,255,0.5)", lineHeight: 1.85, marginBottom: mod.proExtra ? "20px" : 0 }}>{mod.content}</p>
                        {mod.proExtra && (
                          <div style={{ padding: isMobile ? "16px" : "20px 24px", background: `${ACCENT}08`, border: `1px solid ${ACCENT}25`, borderLeft: `3px solid ${ACCENT}`, borderRadius: "0 4px 4px 0" }}>
                            <div style={{ fontFamily: it, fontSize: "10px", color: ACCENT, letterSpacing: "0.14em", textTransform: "uppercase" as const, marginBottom: "8px" }}>{t.photo.program.proOnlyLabel}</div>
                            <p style={{ fontFamily: it, fontSize: isMobile ? "12px" : "14px", color: "rgba(255,255,255,0.45)", lineHeight: 1.8 }}>{mod.proExtra}</p>
                          </div>
                        )}
                      </div>
                      <div style={{ display: "flex", gap: "8px", overflowX: isMobile ? "auto" : "visible" as const }}>
                        {mod.images.map((img, imgIdx) => (
                          <div key={imgIdx} style={{ width: isMobile ? 100 : 140, height: isMobile ? 140 : 200, borderRadius: "4px", overflow: "hidden", flexShrink: 0, background: photoColor(mod.photoIdx + imgIdx) }}>
                            <img src={img} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* PRO модули */}
          <div style={{ borderTop: `1px solid ${BORDER}` }}>
            {t.photo.program.proModules.slice(0, -1).map((mod, i) => (
              <div key={i} style={{ borderBottom: `1px solid ${BORDER}` }}>
                <button onClick={() => setOpenProModule(openProModule === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "center", padding: isMobile ? "20px 0" : "28px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const }}>
                  <div style={{ display: "flex", alignItems: isMobile ? "flex-start" : "center", gap: isMobile ? "12px" : "16px", flexWrap: isMobile ? "wrap" : "nowrap" as const }}>
                    <div style={{ width: "8px", height: "8px", borderRadius: "50%", border: `1.5px solid ${openProModule === i ? ACCENT : "rgba(255,255,255,0.2)"}`, background: openProModule === i ? ACCENT : "transparent", flexShrink: 0, transition: "all 0.2s", marginTop: isMobile ? "4px" : "0" }} />
                    <span style={{ fontFamily: os, fontSize: isMobile ? "14px" : "18px", color: "white" }}>{mod.num} / {mod.title}</span>
                    <span style={{ display: "inline-block", fontFamily: it, fontSize: "9px", fontWeight: 600, color: ACCENT, border: `1px solid ${ACCENT}50`, padding: "2px 8px", letterSpacing: "0.1em", flexShrink: 0 }}>{t.photo.program.proOnlyLabel}</span>
                  </div>
                  <span style={{ fontFamily: os, fontSize: isMobile ? "20px" : "26px", color: openProModule === i ? ACCENT : "rgba(255,255,255,0.2)", flexShrink: 0, marginLeft: isMobile ? "12px" : "20px", lineHeight: 1, transition: "color 0.2s" }}>{openProModule === i ? "−" : "+"}</span>
                </button>
                {openProModule === i && (
                  <div style={{ paddingBottom: isMobile ? "24px" : "36px", paddingLeft: isMobile ? "0" : "24px" }}>
                    <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", color: "rgba(255,255,255,0.5)", lineHeight: 1.85 }}>{mod.text}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ РЕЗУЛЬТАТЫ ══ */}
      <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <h2
            style={{ fontFamily: os, fontSize: isMobile ? "32px" : "72px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: isMobile ? "40px" : "72px" }}
            dangerouslySetInnerHTML={{ __html: t.photo.results.heading }}
          />

          {/* Первые 4 карточки — сетка 2×2 */}
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: "16px", marginBottom: "16px" }}>
            {t.photo.results.items.slice(0, 4).map((item, i) => (
              <div key={i} style={{ background: BG2, overflow: "hidden", display: "flex", flexDirection: "column" }}>
                <div style={{ width: "100%", height: isMobile ? "220px" : "300px", overflow: "hidden", flexShrink: 0 }}>
                  <img src={resultsImages[i]} alt={item.title} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
                </div>
                <div style={{ padding: isMobile ? "20px" : "24px 28px 28px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "12px" }}>
                    <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: `${ACCENT}20`, border: `1px solid ${ACCENT}50`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <span style={{ fontFamily: os, fontSize: "11px", fontWeight: 700, color: ACCENT }}>{item.n}</span>
                    </div>
                  </div>
                  <h3 style={{ fontFamily: os, fontSize: isMobile ? "18px" : "21px", color: "white", marginBottom: "8px", fontWeight: 700, lineHeight: 1.15 }}>{item.title}</h3>
                  <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "14px", color: "rgba(255,255,255,0.45)", lineHeight: 1.7, margin: 0 }}>{item.text}</p>
                </div>
              </div>
            ))}
          </div>

          {/* 5-я карточка по центру — один раз */}
          <div style={{ display: "flex", justifyContent: "center" }}>
            <div style={{ background: BG2, overflow: "hidden", display: "flex", flexDirection: "column", width: isMobile ? "100%" : "50%" }}>
              <div style={{ width: "100%", height: isMobile ? "220px" : "300px", overflow: "hidden", flexShrink: 0 }}>
                <img src={resultsImages[4]} alt={t.photo.results.items[4].title} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
              </div>
              <div style={{ padding: isMobile ? "20px" : "24px 28px 28px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: "12px" }}>
                  <div style={{ width: "28px", height: "28px", borderRadius: "50%", background: `${ACCENT}20`, border: `1px solid ${ACCENT}50`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    <span style={{ fontFamily: os, fontSize: "11px", fontWeight: 700, color: ACCENT }}>{t.photo.results.items[4].n}</span>
                  </div>
                </div>
                <h3 style={{ fontFamily: os, fontSize: isMobile ? "18px" : "21px", color: "white", marginBottom: "8px", fontWeight: 700, lineHeight: 1.15 }}>{t.photo.results.items[4].title}</h3>
                <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "14px", color: "rgba(255,255,255,0.45)", lineHeight: 1.7, margin: 0 }}>{t.photo.results.items[4].text}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ══ КАК ПРОХОДИТ ОБУЧЕНИЕ ══ */}
      <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 2fr", gap: isMobile ? "32px" : "80px", alignItems: "start" }}>
            <div>
              <h2
                style={{ fontFamily: os, fontSize: isMobile ? "32px" : "64px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "24px" }}
                dangerouslySetInnerHTML={{ __html: t.photo.howItWorks.heading }}
              />
              <div style={{ marginTop: isMobile ? "24px" : "32px", borderRadius: "16px", overflow: "hidden", position: "relative" as const, display: isMobile ? "none" : "block" }}>
                <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/learning-roses-new-ratN52A1vhwNJPAuzA7RJs0V14OtW8.png" alt="" style={{ width: "100%", height: 360, objectFit: "cover", borderRadius: "16px" }} />
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: "1px", background: BORDER }}>
              {t.photo.howItWorks.items.map((item, i) => {
                const accents = ["#5aa0dc", ACCENT, "#dc785a", "#b478dc"]
                return (
                  <div key={i} style={{ background: BG, padding: isMobile ? "24px 20px" : "36px 28px", position: "relative" as const }}>
                    <div style={{ position: "absolute", top: 0, left: 0, width: "40px", height: "2px", background: accents[i] }} />
                    <div style={{ fontSize: isMobile ? "20px" : "24px", marginBottom: "14px" }}>{item.icon}</div>
                    <h3 style={{ fontFamily: os, fontSize: isMobile ? "14px" : "16px", color: "white", marginBottom: "10px", fontWeight: 700 }}>{item.title}</h3>
                    <p style={{ fontFamily: it, fontSize: isMobile ? "12px" : "13px", color: "rgba(255,255,255,0.38)", lineHeight: 1.7 }}>{item.text}</p>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ══ ПОРТФОЛИО ══ */}
      <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "flex-end", marginBottom: isMobile ? "32px" : "48px", gap: isMobile ? "24px" : "0" }}>
            <div>
              <h2
                style={{ fontFamily: os, fontSize: isMobile ? "32px" : "72px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}
                dangerouslySetInnerHTML={{ __html: t.photo.portfolio.heading }}
              />
              <p style={{ fontFamily: it, fontSize: isMobile ? "12px" : "13px", color: "rgba(255,255,255,0.25)", marginTop: "16px", lineHeight: 1.6 }}>{t.photo.portfolio.subtitle}</p>
            </div>
            {!isMobile && (
              <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
                <span style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.2)", marginRight: "8px" }}>{String(portfolioPage + 1).padStart(2, "0")} / {String(PORTFOLIO_PAGES.length).padStart(2, "0")}</span>
                <button onClick={() => setPortfolioPage(p => (p - 1 + PORTFOLIO_PAGES.length) % PORTFOLIO_PAGES.length)} style={{ width: "52px", height: "52px", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "50%", background: "none", color: "white", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>←</button>
                <button onClick={() => setPortfolioPage(p => (p + 1) % PORTFOLIO_PAGES.length)} style={{ width: "52px", height: "52px", border: "1px solid rgba(255,255,255,0.12)", borderRadius: "50%", background: "none", color: "white", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>→</button>
              </div>
            )}
          </div>
          {isMobile ? <PortfolioMobile items={PORTFOLIO_PAGES[portfolioPage]} /> : <PortfolioGrid items={PORTFOLIO_PAGES[portfolioPage]} />}
          <div style={{ display: "flex", justifyContent: "center", gap: "8px", marginTop: "32px" }}>
            {PORTFOLIO_PAGES.map((_, i) => (
              <button key={i} onClick={() => setPortfolioPage(i)} style={{ width: i === portfolioPage ? "28px" : "8px", height: "2px", background: i === portfolioPage ? ACCENT : "rgba(255,255,255,0.12)", border: "none", cursor: "pointer", padding: 0, transition: "all 0.3s", borderRadius: "1px" }} />
            ))}
          </div>
        </div>
      </section>

      {/* ══ ТАРИФЫ ══ */}
      <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "flex-end", marginBottom: isMobile ? "32px" : "56px", gap: isMobile ? "16px" : "0" }}>
            <h2
              style={{ fontFamily: os, fontSize: isMobile ? "32px" : "72px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}
              dangerouslySetInnerHTML={{ __html: t.photo.plans.heading }}
            />
            <p style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.2)", maxWidth: "240px", textAlign: isMobile ? "left" : "right" as const, lineHeight: 1.65 }}>{t.photo.plans.hint}</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(3,1fr)", gap: "1px", background: BORDER }}>
            {plans.map((plan, i) => (
              <div key={i} style={{ background: i === 1 ? "rgba(90,200,120,0.04)" : BG, position: "relative" as const, display: "flex", flexDirection: "column" as const }}>
                <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: i === 1 ? plan.accent : "transparent" }} />
                <div style={{ padding: "40px 36px 44px", flex: 1, display: "flex", flexDirection: "column" as const }}>
                  {plan.badge && (
                    <div style={{ display: "inline-block", fontFamily: it, fontSize: "9px", color: plan.accent, border: `0.5px solid ${plan.accent}`, padding: "3px 8px", borderRadius: "2px", marginBottom: "20px", alignSelf: "flex-start", letterSpacing: "0.12em", textTransform: "uppercase" as const }}>{plan.badge}</div>
                  )}
                  <div style={{ width: "10px", height: "10px", borderRadius: "50%", background: plan.accent, boxShadow: `0 0 12px ${plan.accent}80`, marginBottom: "16px" }} />
                  <h3 style={{ fontFamily: os, fontSize: "36px", color: "white", fontWeight: 700, marginBottom: "6px" }}>{plan.name}</h3>
                  <p style={{ fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.3)", marginBottom: "28px", lineHeight: 1.5 }}>{plan.subtitle}</p>
                  <ul style={{ listStyle: "none", padding: 0, margin: "0 0 32px 0", flex: 1 }}>
                    {plan.features.map((f, j) => (
                      <li key={j} style={{ fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.45)", padding: "8px 0", borderBottom: `1px solid ${BORDER}`, display: "flex", gap: "10px", alignItems: "center" }}>
                        <span style={{ width: "5px", height: "5px", borderRadius: "50%", background: plan.accent, flexShrink: 0 }} />{f}
                      </li>
                    ))}
                  </ul>
                  <div style={{ fontFamily: os, fontSize: "48px", color: i === 1 ? plan.accent : "white", fontWeight: 700, marginBottom: "20px" }}>{plan.price}</div>
                  <a href="mailto:hello@aistudio.com" style={{ display: "block", textAlign: "center" as const, background: i === 1 ? plan.accent : "transparent", border: i === 1 ? "none" : `1px solid rgba(255,255,255,0.15)`, color: i === 1 ? "#0a1a0a" : "white", padding: "15px 24px", fontFamily: os, fontSize: "13px", letterSpacing: "0.1em", textDecoration: "none", borderRadius: "3px", fontWeight: i === 1 ? 700 : 400 }}>{plan.cta}</a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ══ FAQ ══ */}
      <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: isMobile ? "40px" : "80px" }}>
          <div>
            <h2
              style={{ fontFamily: os, fontSize: isMobile ? "32px" : "64px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: isMobile ? "24px" : "40px" }}
              dangerouslySetInnerHTML={{ __html: t.photo.faq.heading }}
            />
            <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: BORDER }}>
              {t.photo.faq.stats.map((s, i) => (
                <div key={i} style={{ background: BG2, padding: "20px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ fontFamily: os, fontSize: "24px", color: ACCENT, fontWeight: 700 }}>{s.n}</div>
                  <div style={{ fontFamily: it, fontSize: "12px", color: "rgba(255,255,255,0.3)" }}>{s.l}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{ paddingTop: "8px" }}>
            {t.photo.faq.items.map((item, i) => (
              <div key={i} style={{ borderTop: `1px solid ${BORDER}` }}>
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "22px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const, gap: "20px" }}>
                  <span style={{ fontFamily: os, fontSize: "16px", color: "white" }}>{item.q}</span>
                  <span style={{ fontFamily: os, fontSize: "22px", color: openFaq === i ? ACCENT : "rgba(255,255,255,0.2)", flexShrink: 0, lineHeight: 1, transition: "color 0.2s" }}>{openFaq === i ? "−" : "+"}</span>
                </button>
                {openFaq === i && <p style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85, paddingBottom: "22px", maxWidth: "480px" }}>{item.a}</p>}
              </div>
            ))}
            <div style={{ borderTop: `1px solid ${BORDER}` }} />
          </div>
        </div>
      </section>

      {/* ══ ФИНАЛЬНЫЙ CTA ══ */}
      <section style={{ background: BG2, padding: "0", borderTop: `1px solid ${BORDER}`, overflow: "hidden" }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr" }}>
          <div style={{ position: "relative", height: isMobile ? 240 : 500, overflow: "hidden" }}>
            <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2026-02-18_22-13-35-f3fkVvdLJJsxVrREXeDor4AOwOjkMI.jpg" alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
          </div>
          <div style={{ padding: isMobile ? "40px 20px" : "80px 64px", display: "flex", flexDirection: "column" as const, justifyContent: "center" }}>
            <h2 style={{ fontFamily: os, fontSize: isMobile ? "28px" : "64px", color: "white", lineHeight: 0.88, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: isMobile ? "16px" : "24px" }}>
              {t.photo.finalCta.heading}<span style={{ color: ACCENT }}>{t.photo.finalCta.headingAccent}</span>
            </h2>
            <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "15px", color: "rgba(255,255,255,0.38)", lineHeight: 1.75, marginBottom: isMobile ? "24px" : "36px" }}>{t.photo.finalCta.body}</p>
            <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", gap: "12px", flexWrap: "wrap" as const }}>
              <a href="mailto:hello@aistudio.com" style={{ display: "inline-block", background: ACCENT, color: "#0a1a0a", padding: isMobile ? "14px 28px" : "16px 36px", fontFamily: os, fontSize: isMobile ? "12px" : "13px", letterSpacing: "0.1em", textDecoration: "none", borderRadius: "3px", fontWeight: 700, textAlign: "center" as const }}>{t.photo.finalCta.ctaPrimary}</a>
              <a href="#program" style={{ display: "inline-block", background: "transparent", border: "1px solid rgba(255,255,255,0.15)", color: "white", padding: isMobile ? "14px 28px" : "16px 36px", fontFamily: os, fontSize: isMobile ? "12px" : "13px", letterSpacing: "0.1em", textDecoration: "none", borderRadius: "3px", textAlign: "center" as const }}>{t.photo.finalCta.ctaSecondary}</a>
            </div>
            <p style={{ fontFamily: it, fontSize: isMobile ? "11px" : "12px", color: "rgba(255,255,255,0.18)", marginTop: isMobile ? "16px" : "20px" }}>{t.photo.finalCta.hint}</p>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ background: BG, padding: isMobile ? "28px 20px" : "36px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: "center", gap: isMobile ? "20px" : "0" }}>
          <Link href="/" style={{ fontFamily: os, fontSize: isMobile ? "11px" : "12px", color: "rgba(255,255,255,0.15)", letterSpacing: "0.2em", textTransform: "uppercase" as const, textDecoration: "none" }}>{t.common.nav.logo}</Link>
          <div style={{ display: "flex", gap: isMobile ? "20px" : "32px", flexWrap: "wrap" as const, justifyContent: "center", alignItems: "center" }}>
            <CoursesDropdown isMobile={isMobile} />
            {[
              { label: t.common.nav.trainings, href: "/corporate" },
              { label: t.common.nav.production, href: "/production" },
              { label: t.common.nav.contact, href: "mailto:hello@aistudio.com" },
            ].map(item => (
              <Link key={item.label} href={item.href} style={{ fontFamily: it, fontSize: isMobile ? "11px" : "12px", color: "rgba(255,255,255,0.18)", textDecoration: "none" }}>{item.label}</Link>
            ))}
          </div>
          <span style={{ fontFamily: it, fontSize: isMobile ? "10px" : "12px", color: "rgba(255,255,255,0.1)" }}>{t.common.footer.copyright}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: "24px", marginTop: "20px", paddingTop: "16px", borderTop: `1px solid ${BORDER}` }}>
          <Link href="/terms" style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", textDecoration: "none" }}>Условия использования</Link>
          <Link href="/privacy" style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", textDecoration: "none" }}>Политика конфиденциальности</Link>
        </div>
      </footer>
    </main>
  )
}