"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { t } from "@/lib/i18n"

function useIsMobile(breakpoint = 768) {
  const [isMobile, setIsMobile] = useState(false)
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < breakpoint)
    check()
    window.addEventListener("resize", check)
    return () => window.removeEventListener("resize", check)
  }, [breakpoint])
  return isMobile
}

const BG = "#0d0d12"
const BG2 = "#111118"
const BORDER = "rgba(255,255,255,0.06)"
const os = "'Oswald', sans-serif"
const it = "'Inter', sans-serif"
const ACCENT = "#dc785a"

const CTA_URL =
  "https://t.me/generationai_support?text=%D0%97%D0%B4%D1%80%D0%B0%D0%B2%D1%81%D1%82%D0%B2%D1%83%D0%B9%D1%82%D0%B5%2C%20%D0%B8%D0%BD%D1%82%D0%B5%D1%80%D0%B5%D1%81%D1%83%D0%B5%D1%82%20AI%20%D0%B2%D0%B8%D0%B4%D0%B5%D0%BE%2C%20%D0%BF%D0%BE%D0%B4%D1%81%D0%BA%D0%B0%D0%B6%D0%B8%D1%82%D0%B5%20%D0%BA%D0%B0%D0%BA%D0%B0%D1%8F%20%D1%86%D0%B5%D0%BD%D0%B0%20%D1%80%D0%BE%D0%BB%D0%B8%D0%BA%D0%B0%3F"

const HERO_VIDEO = "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5272.MOV"

// ── Video sources (not translatable — media assets) ───────────────────────────
const directionVideos = [
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_2702.MP4",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5272.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5889.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5083.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_4080.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_3909.MOV",
]
const directionColors = ["#5aa0dc", "#dc785a", "#dcb478", "#dc78b4", "#78dcb4", "#b478dc"]

const whyAIVideos = [
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_2666.MP4",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5259.MP4",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/1230201_1758316064.mp4",
]

const deliverableVideos = [
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5272.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_2702.MP4",
  null,
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5502.MP4",
]

const digitalAssetsImages = [
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bab1f583e74a8ebf796b8b597b8e2105_e8a1410d-6208-4018-a5ec-c1cfc1859df1-cDFSfdAxtBLgITBzxz4bR2hSUcCcl7.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/60e0e2c929b6362f1793754e069638e9_a2345bc9-6332-4ec1-aee3-effb8a0edc9c-iMhru3w2Xl2eQYXnV5kg5Sev0EZFfD.png",
  "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/b6aacb4f089126e9ce07749ec6b83475_e8145c2b-6987-485b-ac2a-710cfb3e7a10-UHhWapMn1ehi4S2N3HtNlRHJ2iKsw9.png",
]

const portfolioVideos = [
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_3909.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5083.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_4808.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_4809.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_4968.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_Nike.mp4",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5576.MP4",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_4080.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_4939.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5272.MOV",
  "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5889.MOV",
]
const portfolioQualities = ["4K", "4K", "HD", "HD", "HD", "HD", "HD", "HD", "HD", "4K", "4K"]

const heroBgCards = [
  { bg: "linear-gradient(160deg, #2a1a10 0%, #1a0d08 100%)", video: "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5272.MOV" },
  { bg: "linear-gradient(160deg, #281408 0%, #180c04 100%)", video: "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5083.MOV" },
  { bg: "linear-gradient(160deg, #2e1a0c 0%, #1c1008 100%)", video: "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_2702.MP4" },
  { bg: "linear-gradient(160deg, #261208 0%, #160a04 100%)", video: "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_5889.MOV" },
  { bg: "linear-gradient(160deg, #2a1810 0%, #1a0e08 100%)", video: "https://gaiprod-videos.s3.eu-north-1.amazonaws.com/IMG_4080.MOV" },
]

// ── VideoCard ─────────────────────────────────────────────────────────────────
function VideoCard({ src, style = {}, category = "", quality = "" }: { src: string; style?: React.CSSProperties; category?: string; quality?: string }) {
  const [playing, setPlaying] = useState(false)
  const ref = useRef<HTMLVideoElement>(null)
  const toggle = () => {
    if (!ref.current) return
    if (playing) { ref.current.pause(); setPlaying(false) }
    else { ref.current.play().catch(() => { }); setPlaying(true) }
  }
  return (
    <div style={{ position: "relative", overflow: "hidden", background: "#000", cursor: "pointer", ...style }} onClick={toggle}>
      <video ref={ref} src={src} loop muted playsInline preload="metadata" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
      {!playing && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(0,0,0,0.3)" }}>
          <div style={{ width: "52px", height: "52px", border: "1px solid rgba(255,255,255,0.35)", display: "flex", alignItems: "center", justifyContent: "center", background: "rgba(255,255,255,0.08)" }}>
            <div style={{ width: 0, height: 0, borderTop: "7px solid transparent", borderBottom: "7px solid transparent", borderLeft: "12px solid rgba(255,255,255,0.85)", marginLeft: "3px" }} />
          </div>
        </div>
      )}
      {category && <div style={{ position: "absolute", top: "10px", left: "10px", fontFamily: it, fontSize: "10px", fontWeight: 600, color: "rgba(255,255,255,0.7)", padding: "3px 8px", letterSpacing: "0.1em", textTransform: "uppercase" as const, background: "rgba(0,0,0,0.55)", border: `1px solid ${BORDER}`, zIndex: 2 }}>{category}</div>}
      {quality && <div style={{ position: "absolute", top: "10px", right: "10px", fontFamily: it, fontSize: "10px", fontWeight: 600, color: ACCENT, padding: "3px 8px", letterSpacing: "0.1em", background: "rgba(0,0,0,0.55)", border: `1px solid ${ACCENT}40`, zIndex: 2 }}>{quality}</div>}
    </div>
  )
}

function SectionLabel({ text, isMobile = false }: { text: string; isMobile?: boolean }) {
  return <div style={{ fontFamily: it, fontSize: isMobile ? "10px" : "12px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: isMobile ? "12px" : "16px" }}>{text}</div>
}

// ── Digital Assets Carousel ───────────────────────────────────────────────────
function DigitalAssetsCarousel({ images, style = {} }: { images: string[]; style?: React.CSSProperties }) {
  const [currentIndex, setCurrentIndex] = useState(0)
  useEffect(() => {
    const interval = setInterval(() => setCurrentIndex(prev => (prev + 1) % images.length), 1800)
    return () => clearInterval(interval)
  }, [images.length])
  return (
    <div style={{ position: "relative", overflow: "hidden", background: "#000", ...style, display: "flex", alignItems: "center", justifyContent: "center" }}>
      {images.map((img, i) => {
        const total = images.length
        const offset = ((i - currentIndex) % total + total) % total
        const isFront = offset === 0
        const isRight = offset === 1
        const isLeft = offset === total - 1
        const translateX = isFront ? 0 : isRight ? 55 : isLeft ? -55 : 0
        const scale = isFront ? 1 : 0.72
        const opacity = isFront ? 1 : (isRight || isLeft) ? 0.55 : 0
        const zIndex = isFront ? 3 : (isRight || isLeft) ? 2 : 0
        const rotateY = isFront ? 0 : isRight ? -18 : 18
        return (
          <div key={i} style={{ position: "absolute", width: "58%", height: "82%", borderRadius: "10px", overflow: "hidden", transform: `translateX(${translateX}%) scale(${scale}) perspective(600px) rotateY(${rotateY}deg)`, opacity, zIndex, transition: "all 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94)", boxShadow: isFront ? "0 20px 60px rgba(0,0,0,0.8)" : "0 8px 24px rgba(0,0,0,0.5)" }}>
            <img src={img} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
          </div>
        )
      })}
    </div>
  )
}

// ── Nav courses dropdown ──────────────────────────────────────────────────────
function NavCoursesDropdown({ isMobile }: { isMobile: boolean }) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    function handle(e: MouseEvent) { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false) }
    document.addEventListener("mousedown", handle)
    return () => document.removeEventListener("mousedown", handle)
  }, [])
  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button onClick={() => setOpen(o => !o)} style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.6)", padding: isMobile ? "6px 10px" : "8px 18px", background: "transparent", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: "5px", letterSpacing: "0.03em" }}>
        {t.common.nav.courses}
        <span style={{ fontSize: "8px", opacity: 0.45, display: "inline-block", transition: "transform 0.2s", transform: open ? "rotate(180deg)" : "rotate(0deg)" }}>▼</span>
      </button>
      {open && (
        <div style={{ position: "absolute", top: "calc(100% + 6px)", left: 0, background: "#15151f", border: `1px solid ${BORDER}`, borderRadius: "4px", padding: "6px 0", minWidth: "200px", zIndex: 60, boxShadow: "0 16px 40px rgba(0,0,0,0.7)" }}>
          <div style={{ fontFamily: it, fontSize: "9px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.2em", textTransform: "uppercase" as const, padding: "4px 16px 6px" }}>{t.common.nav.courses}</div>
          <Link href="/photo" onClick={() => setOpen(false)} style={{ display: "flex", alignItems: "center", gap: "12px", fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.75)", textDecoration: "none", padding: "10px 16px" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(90,160,220,0.08)"; (e.currentTarget as HTMLElement).style.color = "#5aa0dc" }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.75)" }}
          >
            <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#5aa0dc", flexShrink: 0 }} />
            {t.common.coursesDropdown.aiPhoto}
          </Link>
          <Link href="/video" onClick={() => setOpen(false)} style={{ display: "flex", alignItems: "center", gap: "12px", fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.75)", textDecoration: "none", padding: "10px 16px" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "rgba(90,200,120,0.08)"; (e.currentTarget as HTMLElement).style.color = "#5ac878" }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = "rgba(255,255,255,0.75)" }}
          >
            <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#5ac878", flexShrink: 0 }} />
            {t.common.coursesDropdown.aiCreator}
          </Link>
        </div>
      )}
    </div>
  )
}

// ── Hero bg card ──────────────────────────────────────────────────────────────
function HeroBgCard({ card }: { card: { bg: string; video: string } }) {
  const [hovered, setHovered] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  useEffect(() => { if (videoRef.current) videoRef.current.play().catch(() => { }) }, [])
  return (
    <div onMouseEnter={() => setHovered(true)} onMouseLeave={() => setHovered(false)}
      style={{ flex: 1, background: card.bg, transform: `skewX(-8deg) ${hovered ? "scaleY(1.04) translateY(-8px)" : ""}`, transformOrigin: "bottom center", margin: "0 4px", position: "relative", overflow: "hidden", cursor: "pointer", transition: "transform 0.35s cubic-bezier(0.25,0.46,0.45,0.94)", boxShadow: hovered ? "0 0 0 1px rgba(255,255,255,0.1), 0 32px 60px rgba(0,0,0,0.6)" : "0 0 0 1px rgba(255,255,255,0.03)" }}
    >
      <div style={{ position: "absolute", inset: 0, transform: "skewX(8deg) scaleX(1.1)", overflow: "hidden" }}>
        <video ref={videoRef} src={card.video} loop muted playsInline autoPlay style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", opacity: hovered ? 0.8 : 0.5, transition: "opacity 0.4s ease" }} />
      </div>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "1px", background: "rgba(220,120,90,0.3)" }} />
      <div style={{ position: "absolute", inset: "16px", border: "1px solid rgba(220,120,90,0.07)" }} />
    </div>
  )
}

// ── Directions Carousel ───────────────────────────────────────────────────────
function DirectionsCarousel() {
  const isMobile = useIsMobile()
  const [active, setActive] = useState(0)
  const [busy, setBusy] = useState(false)
  const items = t.production.directions.items
  const total = items.length
  const nav = (dir: "prev" | "next") => {
    if (busy) return
    setBusy(true)
    setActive(i => dir === "next" ? (i + 1) % total : (i - 1 + total) % total)
    setTimeout(() => setBusy(false), 300)
  }
  const d = items[active]
  const color = directionColors[active]
  const video = directionVideos[active]
  return (
    <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "flex-end", marginBottom: isMobile ? "32px" : "64px", gap: isMobile ? "20px" : "0" }}>
          <div>
            <SectionLabel text={t.production.directions.label} isMobile={isMobile} />
            <h2 style={{ fontFamily: os, fontSize: isMobile ? "38px" : "88px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}>{t.production.directions.heading}</h2>
          </div>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <span style={{ fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.2)", marginRight: "8px" }}>{String(active + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}</span>
            {(["prev", "next"] as const).map((dir, idx) => (
              <button key={dir} onClick={() => nav(dir)} style={{ width: isMobile ? "44px" : "52px", height: isMobile ? "44px" : "52px", border: `1px solid ${BORDER}`, background: "none", color: "white", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "border-color .2s" }} onMouseEnter={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.3)")} onMouseLeave={e => (e.currentTarget.style.borderColor = BORDER)}>{idx === 0 ? "←" : "→"}</button>
            ))}
          </div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: "1px", background: BORDER }}>
          <VideoCard src={video} style={{ minHeight: isMobile ? "280px" : "480px", height: isMobile ? "280px" : "480px" }} />
          <div style={{ background: BG2, padding: isMobile ? "28px 20px" : "60px 52px", display: "flex", flexDirection: "column", justifyContent: "space-between" }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "12px", marginBottom: isMobile ? "20px" : "28px" }}>
                <div style={{ width: "32px", height: "1px", background: color }} />
                <span style={{ fontFamily: it, fontSize: "11px", color, letterSpacing: "0.18em", textTransform: "uppercase" as const }}>{d.tag}</span>
              </div>
              <h3 style={{ fontFamily: os, fontSize: isMobile ? "26px" : "52px", color: "white", textTransform: "uppercase" as const, fontWeight: 700, lineHeight: 0.95, marginBottom: isMobile ? "16px" : "28px" }}>{d.title}</h3>
              <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "17px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85 }}>{d.text}</p>
            </div>
            <div style={{ marginTop: isMobile ? "24px" : "0" }}>
              <div style={{ display: "flex", gap: "6px", marginBottom: isMobile ? "20px" : "32px" }}>
                {items.map((_, i) => (<button key={i} onClick={() => setActive(i)} style={{ width: i === active ? "28px" : "6px", height: "1px", background: i === active ? color : "rgba(255,255,255,0.12)", border: "none", cursor: "pointer", padding: 0, transition: "all 0.3s" }} />))}
              </div>
              <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ fontFamily: it, fontSize: "13px", color, textDecoration: "none", display: "inline-flex", alignItems: "center", gap: "6px", borderBottom: `1px solid ${color}40`, paddingBottom: "2px", letterSpacing: "0.04em" }}>{t.production.directions.cta}</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ── WhyAI ─────────────────────────────────────────────────────────────────────
function WhyAI() {
  const isMobile = useIsMobile()
  const items = t.production.whyAI.items
  return (
    <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <SectionLabel text={t.production.whyAI.label} isMobile={isMobile} />
        <h2
          style={{ fontFamily: os, fontSize: isMobile ? "38px" : "88px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: isMobile ? "36px" : "80px" }}
          dangerouslySetInnerHTML={{ __html: t.production.whyAI.heading }}
        />
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(3,1fr)", gap: "1px", background: BORDER }}>
          {items.map((item, i) => (
            <div key={i} style={{ background: BG, position: "relative" as const, overflow: "hidden" }}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(to right, transparent, ${ACCENT}60, transparent)` }} />
              <VideoCard src={whyAIVideos[i]} style={{ height: isMobile ? "160px" : "180px", width: "100%" }} />
              <div style={{ padding: isMobile ? "20px" : "28px 32px 36px" }}>
                <h3 style={{ fontFamily: os, fontSize: isMobile ? "16px" : "20px", color: "white", textTransform: "uppercase" as const, marginBottom: "12px", letterSpacing: "0.04em" }}>{item.title}</h3>
                <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "16px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85 }}>{item.text}</p>
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: "1px", background: BG, padding: isMobile ? "28px 20px" : "40px 36px", display: "flex", flexDirection: isMobile ? "column" : "row", alignItems: isMobile ? "flex-start" : "center", justifyContent: "space-between", gap: isMobile ? "20px" : "40px" }}>
          <p style={{ fontFamily: os, fontSize: isMobile ? "18px" : "24px", color: "white", maxWidth: "640px", lineHeight: 1.35 }}>{t.production.whyAI.summary}</p>
          <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ flexShrink: 0, display: "inline-block", border: "1px solid rgba(255,255,255,0.2)", color: "white", padding: isMobile ? "12px 24px" : "16px 40px", fontFamily: os, fontSize: isMobile ? "12px" : "14px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const }}>{t.production.whyAI.cta}</a>
        </div>
      </div>
    </section>
  )
}

// ── Pricing ───────────────────────────────────────────────────────────────────
function Pricing() {
  const isMobile = useIsMobile()
  const items = t.production.pricing.items
  return (
    <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <SectionLabel text={t.production.pricing.label} isMobile={isMobile} />
        <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "flex-end", marginBottom: isMobile ? "36px" : "80px", gap: isMobile ? "16px" : "0" }}>
          <h2
            style={{ fontFamily: os, fontSize: isMobile ? "36px" : "88px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}
            dangerouslySetInnerHTML={{ __html: t.production.pricing.heading }}
          />
          <p style={{ fontFamily: it, fontSize: isMobile ? "14px" : "16px", color: "rgba(255,255,255,0.28)", maxWidth: "300px", lineHeight: 1.75, textAlign: isMobile ? "left" : "right" as const }}>{t.production.pricing.hint}</p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(2,1fr)", gap: "1px", background: BORDER }}>
          {items.map((item, i) => (
            <div key={i} style={{ background: BG2, padding: isMobile ? "24px 20px" : "40px 40px", position: "relative" as const, transition: "background 0.2s" }} onMouseEnter={e => (e.currentTarget.style.background = "#16161e")} onMouseLeave={e => (e.currentTarget.style.background = BG2)}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(to right, transparent, ${ACCENT}50, transparent)` }} />
              <div style={{ fontFamily: os, fontSize: isMobile ? "40px" : "64px", color: "rgba(255,255,255,0.04)", lineHeight: 1, marginBottom: isMobile ? "12px" : "20px", fontWeight: 700 }}>0{i + 1}</div>
              <h3 style={{ fontFamily: os, fontSize: isMobile ? "16px" : "20px", color: "white", textTransform: "uppercase" as const, marginBottom: "12px", letterSpacing: "0.04em" }}>{item.title}</h3>
              <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "16px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85 }}>{item.text}</p>
            </div>
          ))}
          <div style={{ background: BG2, padding: isMobile ? "24px 20px" : "40px 40px", display: "flex", flexDirection: "column" as const, justifyContent: "flex-end" }}>
            <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "16px", color: "rgba(255,255,255,0.28)", lineHeight: 1.75, marginBottom: isMobile ? "20px" : "28px" }}>{t.production.pricing.costHint}</p>
            <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: ACCENT, color: "white", padding: isMobile ? "14px 28px" : "16px 32px", fontFamily: os, fontSize: isMobile ? "12px" : "14px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const, textAlign: "center" as const }}>{t.production.pricing.cta}</a>
          </div>
        </div>
      </div>
    </section>
  )
}

// ── Roadmap ───────────────────────────────────────────────────────────────────
function Roadmap() {
  const isMobile = useIsMobile()
  const steps = t.production.roadmap.steps
  if (isMobile) {
    return (
      <section style={{ background: BG2, padding: "60px 20px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
          <SectionLabel text={t.production.roadmap.label} isMobile={true} />
          <h2
            style={{ fontFamily: os, fontSize: "36px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "12px" }}
            dangerouslySetInnerHTML={{ __html: t.production.roadmap.heading }}
          />
          <p style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.28)", lineHeight: 1.75, marginBottom: "32px" }}>{t.production.roadmap.totalLabel} <span style={{ color: "rgba(255,255,255,0.55)" }}>{t.production.roadmap.total}</span></p>
          <div style={{ display: "flex", flexDirection: "column", gap: "1px", background: BORDER }}>
            {steps.map((step) => (
              <div key={step.num} style={{ background: BG, padding: "24px 20px", position: "relative" as const }}>
                <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(to right, ${ACCENT}, transparent)` }} />
                <div style={{ display: "flex", alignItems: "center", gap: "16px", marginBottom: "12px" }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "center", width: "40px", height: "40px", border: `1px solid ${ACCENT}40`, flexShrink: 0 }}><span style={{ fontFamily: os, fontSize: "14px", fontWeight: 700, color: ACCENT }}>{step.num}</span></div>
                  <h3 style={{ fontFamily: os, fontSize: "19px", color: "white", textTransform: "uppercase" as const, letterSpacing: "0.04em" }}>{step.title}</h3>
                </div>
                <p style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85 }}>{step.text}</p>
                <div style={{ marginTop: "16px" }}><span style={{ fontFamily: it, fontSize: "10px", color: ACCENT, padding: "3px 10px", border: `1px solid ${ACCENT}30`, letterSpacing: "0.06em" }}>{step.days}</span></div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: "24px", background: BG, padding: "24px 20px", display: "flex", flexDirection: "column", gap: "20px", borderTop: `1px solid ${BORDER}` }}>
            <p style={{ fontFamily: it, fontSize: "15px", color: "rgba(255,255,255,0.38)", lineHeight: 1.75 }}>{t.production.roadmap.ctaBody}</p>
            <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: ACCENT, color: "white", padding: "14px 28px", fontFamily: os, fontSize: "12px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const, textAlign: "center" as const }}>{t.production.roadmap.cta}</a>
          </div>
        </div>
      </section>
    )
  }
  return (
    <section style={{ background: BG2, padding: "120px 56px", borderTop: `1px solid ${BORDER}` }}>
      <style>{`@keyframes rmShimmer{0%,100%{stroke-dashoffset:0;opacity:.3}50%{stroke-dashoffset:100;opacity:.7}} @keyframes rmPulse{0%,100%{transform:scale(1);opacity:.2}50%{transform:scale(1.5);opacity:.8}} .rm-shimmer{stroke-dasharray:20 10;animation:rmShimmer 4s ease-in-out infinite} .rm-dot{animation:rmPulse 3s ease-in-out infinite} .rm-card{position:absolute;width:44%} .rm-card:hover>div{transform:translateY(-4px)} .rm-card>div{transition:transform .25s ease}`}</style>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <SectionLabel text={t.production.roadmap.label} />
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: "80px" }}>
          <h2
            style={{ fontFamily: os, fontSize: "88px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}
            dangerouslySetInnerHTML={{ __html: t.production.roadmap.heading }}
          />
          <p style={{ fontFamily: it, fontSize: "16px", color: "rgba(255,255,255,0.28)", maxWidth: "320px", lineHeight: 1.75, textAlign: "right" as const }}>{t.production.roadmap.totalLabel} <span style={{ color: "rgba(255,255,255,0.55)" }}>{t.production.roadmap.total}</span></p>
        </div>
        <div style={{ position: "relative", height: "1680px" }}>
          <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }} viewBox="0 0 1000 1680" preserveAspectRatio="none" fill="none">
            <defs>
              <linearGradient id="rmG" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor={ACCENT} /><stop offset="50%" stopColor="rgba(255,255,255,0.15)" /><stop offset="100%" stopColor={ACCENT} /></linearGradient>
              <filter id="rmGlow"><feGaussianBlur in="SourceGraphic" stdDeviation="10" /></filter>
            </defs>
            <path d="M 120,100 Q 500,80 880,300 Q 500,450 120,650 Q 500,850 880,1000 Q 500,1150 120,1350 Q 500,1500 880,1630" stroke="url(#rmG)" strokeWidth="16" filter="url(#rmGlow)" opacity="0.15" strokeLinecap="round" />
            <path d="M 120,100 Q 500,80 880,300 Q 500,450 120,650 Q 500,850 880,1000 Q 500,1150 120,1350 Q 500,1500 880,1630" stroke="rgba(255,255,255,0.08)" strokeWidth="1" strokeLinecap="round" />
            <path className="rm-shimmer" d="M 120,100 Q 500,80 880,300 Q 500,450 120,650 Q 500,850 880,1000 Q 500,1150 120,1350 Q 500,1500 880,1630" stroke={ACCENT} strokeWidth="1.5" strokeLinecap="round" />
            {[[260, 140], [500, 155], [700, 245], [700, 420], [500, 490], [300, 560], [300, 740], [500, 820], [700, 920], [700, 1095], [500, 1175], [300, 1250], [300, 1430], [500, 1520]].map(([cx, cy], idx) => (<circle key={idx} cx={cx} cy={cy} r="3" fill={ACCENT} className="rm-dot" style={{ animationDelay: `${idx * 0.3}s` }} />))}
            {[0, 1, 2].map(i => (<circle key={`p-${i}`} r="2.5" fill={ACCENT} opacity="0.7"><animateMotion dur="14s" repeatCount="indefinite" begin={`${i * 4.5}s`} path="M 120,100 Q 500,80 880,300 Q 500,450 120,650 Q 500,850 880,1000 Q 500,1150 120,1350 Q 500,1500 880,1630" /></circle>))}
          </svg>
          {[{ left: "2%", top: "1%", rotate: -0.5 }, { left: "52%", top: "18%", rotate: 0.5 }, { left: "2%", top: "37%", rotate: 0 }, { left: "52%", top: "56%", rotate: -0.5 }, { left: "2%", top: "75%", rotate: 0.5 }].map((pos, i) => (
            <div key={steps[i].num} className="rm-card" style={{ left: pos.left, top: pos.top, transform: `rotate(${pos.rotate}deg)` }}>
              <div style={{ background: BG, border: `1px solid ${BORDER}`, padding: "32px", position: "relative" as const }}>
                <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(to right, ${ACCENT}, transparent)` }} />
                <div style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: "48px", height: "48px", border: `1px solid ${ACCENT}40`, marginBottom: "20px" }}><span style={{ fontFamily: os, fontSize: "16px", fontWeight: 700, color: ACCENT }}>{steps[i].num}</span></div>
                <h3 style={{ fontFamily: os, fontSize: "24px", color: "white", textTransform: "uppercase" as const, letterSpacing: "0.04em", marginBottom: "12px" }}>{steps[i].title}</h3>
                <p style={{ fontFamily: it, fontSize: "16px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85 }}>{steps[i].text}</p>
                <div style={{ marginTop: "20px" }}><span style={{ fontFamily: it, fontSize: "11px", color: ACCENT, padding: "4px 12px", border: `1px solid ${ACCENT}30`, letterSpacing: "0.06em" }}>{steps[i].days}</span></div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: "40px", background: BG, padding: "40px 48px", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "40px", borderTop: `1px solid ${BORDER}` }}>
          <p style={{ fontFamily: it, fontSize: "17px", color: "rgba(255,255,255,0.38)", lineHeight: 1.75, maxWidth: "560px" }}>{t.production.roadmap.ctaBody}</p>
          <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ flexShrink: 0, display: "inline-block", background: ACCENT, color: "white", padding: "17px 44px", fontFamily: os, fontSize: "15px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const }}>{t.production.roadmap.cta}</a>
        </div>
      </div>
    </section>
  )
}

// ── Deliverables ──────────────────────────────────────────────────────────────
function Deliverables() {
  const isMobile = useIsMobile()
  const items = t.production.deliverables.items
  return (
    <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        <SectionLabel text={t.production.deliverables.label} isMobile={isMobile} />
        <h2
          style={{ fontFamily: os, fontSize: isMobile ? "36px" : "88px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: isMobile ? "32px" : "80px" }}
          dangerouslySetInnerHTML={{ __html: t.production.deliverables.heading }}
        />
        <div style={{ display: "grid", gridTemplateColumns: isMobile ? "1fr" : "repeat(2,1fr)", gap: "1px", background: BORDER }}>
          {items.map((item, i) => (
            <div key={i} style={{ background: BG2, overflow: "hidden", position: "relative" as const, transition: "background 0.2s" }} onMouseEnter={e => (e.currentTarget.style.background = "#16161e")} onMouseLeave={e => (e.currentTarget.style.background = BG2)}>
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "2px", background: `linear-gradient(to right, transparent, ${ACCENT}50, transparent)`, zIndex: 1 }} />
              {deliverableVideos[i] === null ? (
                <DigitalAssetsCarousel images={digitalAssetsImages} style={{ height: isMobile ? "180px" : "220px", width: "100%" }} />
              ) : (
                <VideoCard src={deliverableVideos[i]!} style={{ height: isMobile ? "180px" : "220px", width: "100%" }} />
              )}
              <div style={{ padding: isMobile ? "20px" : "28px 36px 36px" }}>
                <h3 style={{ fontFamily: os, fontSize: isMobile ? "16px" : "20px", color: "white", textTransform: "uppercase" as const, marginBottom: "10px", letterSpacing: "0.04em" }}>{item.title}</h3>
                <p style={{ fontFamily: it, fontSize: isMobile ? "13px" : "16px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85 }}>{item.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ── Portfolio Carousel ────────────────────────────────────────────────────────
function PortfolioCarousel() {
  const isMobile = useIsMobile()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const portfolioItems = t.production.portfolio.items
  const N = portfolioItems.length
  const CARD_W = isMobile ? 200 : 260, GAP = isMobile ? 8 : 12
  const extended = [
    ...portfolioItems.map((it, i) => ({ ...it, _key: `a-${i}`, ri: i, videoUrl: portfolioVideos[i], quality: portfolioQualities[i] })),
    ...portfolioItems.map((it, i) => ({ ...it, _key: `b-${i}`, ri: i, videoUrl: portfolioVideos[i], quality: portfolioQualities[i] })),
    ...portfolioItems.map((it, i) => ({ ...it, _key: `c-${i}`, ri: i, videoUrl: portfolioVideos[i], quality: portfolioQualities[i] })),
  ]
  const realIdx = ((currentIndex % N) + N) % N
  const nav = (dir: "left" | "right") => { if (isTransitioning) return; setIsTransitioning(true); setCurrentIndex(p => dir === "right" ? p + 1 : p - 1) }
  const onEnd = () => { setIsTransitioning(false); setCurrentIndex(p => ((p % N) + N) % N) }
  const tx = -((N + currentIndex) * (CARD_W + GAP))
  return (
    <section style={{ background: BG2, padding: isMobile ? "60px 0" : "120px 0", borderTop: `1px solid ${BORDER}` }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: isMobile ? "0 20px" : "0 56px" }}>
        <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "flex-end", marginBottom: isMobile ? "32px" : "52px", gap: isMobile ? "20px" : "0" }}>
          <div>
            <SectionLabel text={t.production.portfolio.label} isMobile={isMobile} />
            <h2 style={{ fontFamily: os, fontSize: isMobile ? "36px" : "88px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700 }}>{t.production.portfolio.heading}</h2>
          </div>
          <div style={{ display: "flex", gap: "12px", alignItems: "center" }}>
            <span style={{ fontFamily: it, fontSize: "13px", color: "rgba(255,255,255,0.3)", marginRight: "4px" }}>{String(realIdx + 1).padStart(2, "0")} / {String(N).padStart(2, "0")}</span>
            {(["left", "right"] as const).map((dir, idx) => (
              <button key={dir} onClick={() => nav(dir)} style={{ width: isMobile ? "48px" : "56px", height: isMobile ? "48px" : "56px", border: `1px solid rgba(255,255,255,0.25)`, background: "rgba(255,255,255,0.05)", color: "white", fontSize: "20px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all .2s", borderRadius: "2px" }} onMouseEnter={e => { e.currentTarget.style.background = ACCENT; e.currentTarget.style.borderColor = ACCENT }} onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.05)"; e.currentTarget.style.borderColor = "rgba(255,255,255,0.25)" }}>{idx === 0 ? "←" : "→"}</button>
            ))}
          </div>
        </div>
      </div>
      <div style={{ overflow: "hidden" }}>
        <div style={{ display: "flex", gap: `${GAP}px`, transform: `translate3d(calc(50vw - ${CARD_W / 2}px + ${tx}px), 0, 0)`, transition: isTransitioning ? "transform 0.5s cubic-bezier(0.25,0.46,0.45,0.94)" : "none" }} onTransitionEnd={onEnd}>
          {extended.map((item, i) => {
            const isActive = item.ri === realIdx && i >= N && i < N * 2
            return (
              <div key={item._key} style={{ flexShrink: 0, width: `${CARD_W}px`, opacity: isActive ? 1 : 0.4, transform: isActive ? "scaleY(1)" : "scaleY(0.94)", transition: "all 0.4s ease" }}>
                <VideoCard src={item.videoUrl} category={item.category} quality={item.quality} style={{ width: `${CARD_W}px`, height: `${Math.round(CARD_W * 16 / 9)}px`, outline: isActive ? `1px solid ${ACCENT}60` : "none" }} />
                <div style={{ fontFamily: it, fontSize: isMobile ? "9px" : "11px", color: "rgba(255,255,255,0.25)", letterSpacing: "0.06em", marginTop: isMobile ? "8px" : "10px", textAlign: "center" as const, textTransform: "uppercase" as const }}>{item.caption}</div>
              </div>
            )
          })}
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "center", gap: "8px", marginTop: isMobile ? "24px" : "32px" }}>
        {portfolioItems.map((_, i) => (
          <button key={i} onClick={() => { if (isTransitioning) return; const delta = i - realIdx; if (delta === 0) return; setIsTransitioning(true); setCurrentIndex(p => p + delta) }} style={{ width: realIdx === i ? "32px" : "8px", height: "3px", background: realIdx === i ? ACCENT : "rgba(255,255,255,0.2)", border: "none", cursor: "pointer", padding: 0, transition: "all 0.3s", borderRadius: "2px" }} />
        ))}
      </div>
      <div style={{ maxWidth: "1200px", margin: isMobile ? "24px auto 0" : "40px auto 0", padding: isMobile ? "0 20px" : "0 56px", display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: isMobile ? "flex-start" : "center", gap: isMobile ? "16px" : "0" }}>
        <p style={{ fontFamily: it, fontSize: isMobile ? "12px" : "14px", color: "rgba(255,255,255,0.2)", letterSpacing: "0.04em" }}>{t.production.portfolio.hint}</p>
        <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: "transparent", border: `1px solid ${ACCENT}`, color: ACCENT, padding: isMobile ? "11px 24px" : "13px 32px", fontFamily: os, fontSize: isMobile ? "11px" : "13px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const, transition: "all 0.2s" }} onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = ACCENT; (e.currentTarget as HTMLElement).style.color = "white" }} onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = ACCENT }}>{t.production.portfolio.cta}</a>
      </div>
    </section>
  )
}

// ── FAQ ───────────────────────────────────────────────────────────────────────
function FAQSection() {
  const isMobile = useIsMobile()
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const items = t.production.faq.items
  return (
    <section style={{ background: BG, padding: isMobile ? "60px 20px" : "120px 56px", borderTop: `1px solid ${BORDER}` }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        {isMobile ? (
          <>
            <h2
              style={{ fontFamily: os, fontSize: "36px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "36px" }}
              dangerouslySetInnerHTML={{ __html: t.production.faq.heading }}
            />
            {items.map((item, i) => (
              <div key={i} style={{ borderTop: `1px solid ${BORDER}` }}>
                <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "20px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const }}>
                  <span style={{ fontFamily: os, fontSize: "16px", color: "white", maxWidth: "85%" }}>{item.q}</span>
                  <span style={{ fontFamily: os, fontSize: "26px", color: openFaq === i ? ACCENT : "rgba(255,255,255,0.2)", flexShrink: 0, marginLeft: "16px", lineHeight: 1, transition: "color 0.2s" }}>{openFaq === i ? "−" : "+"}</span>
                </button>
                {openFaq === i && <p style={{ fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85, paddingBottom: "20px", maxWidth: "680px" }}>{item.a}</p>}
              </div>
            ))}
            <div style={{ borderTop: `1px solid ${BORDER}` }} />
          </>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1.4fr", gap: "80px", alignItems: "start" }}>
            <div style={{ position: "sticky", top: "96px" }}>
              <h2
                style={{ fontFamily: os, fontSize: "88px", color: "white", lineHeight: 0.9, textTransform: "uppercase" as const, fontWeight: 700, marginBottom: "28px" }}
                dangerouslySetInnerHTML={{ __html: t.production.faq.heading }}
              />
              <p style={{ fontFamily: it, fontSize: "16px", color: "rgba(255,255,255,0.25)", lineHeight: 1.7 }}>Не нашли ответ? Напишите нам.</p>
              <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-flex", alignItems: "center", gap: "8px", marginTop: "28px", fontFamily: it, fontSize: "14px", color: "rgba(255,255,255,0.4)", textDecoration: "none", borderBottom: "1px solid rgba(255,255,255,0.12)", paddingBottom: "2px" }}>{t.common.cta.writeTelegram}</a>
            </div>
            <div>
              {items.map((item, i) => (
                <div key={i} style={{ borderTop: `1px solid ${BORDER}` }}>
                  <button onClick={() => setOpenFaq(openFaq === i ? null : i)} style={{ width: "100%", display: "flex", justifyContent: "space-between", alignItems: "center", padding: "28px 0", cursor: "pointer", background: "none", border: "none", textAlign: "left" as const }}>
                    <span style={{ fontFamily: os, fontSize: "20px", color: "white", maxWidth: "85%" }}>{item.q}</span>
                    <span style={{ fontFamily: os, fontSize: "30px", color: openFaq === i ? ACCENT : "rgba(255,255,255,0.2)", flexShrink: 0, marginLeft: "20px", lineHeight: 1, transition: "color 0.2s" }}>{openFaq === i ? "−" : "+"}</span>
                  </button>
                  {openFaq === i && <p style={{ fontFamily: it, fontSize: "16px", color: "rgba(255,255,255,0.38)", lineHeight: 1.85, paddingBottom: "28px", maxWidth: "560px" }}>{item.a}</p>}
                </div>
              ))}
              <div style={{ borderTop: `1px solid ${BORDER}` }} />
            </div>
          </div>
        )}
      </div>
    </section>
  )
}

// ── Back to top ───────────────────────────────────────────────────────────────
function BackToTop() {
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    function onScroll() { setVisible(window.scrollY > 600) }
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])
  return (
    <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Наверх"
      style={{ position: "fixed", bottom: "32px", right: "32px", width: "48px", height: "48px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)", backdropFilter: "blur(12px)", borderRadius: "50%", color: "rgba(255,255,255,0.7)", fontSize: "18px", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, opacity: visible ? 1 : 0, pointerEvents: visible ? "auto" : "none", transform: visible ? "translateY(0)" : "translateY(12px)", transition: "opacity 0.3s, transform 0.3s" }}
    >↑</button>
  )
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function ProductionPage() {
  const isMobile = useIsMobile()
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <main style={{ overflowX: "hidden", fontFamily: it, background: BG }}>

      <BackToTop />

      {/* NAV */}
      <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, display: "flex", alignItems: "center", justifyContent: "space-between", padding: isMobile ? "0 20px" : "0 56px", height: isMobile ? "56px" : "68px", background: "rgba(10,10,20,0.85)", backdropFilter: "blur(12px)", borderBottom: `1px solid ${BORDER}` }}>
        <Link href="/" style={{ fontFamily: os, fontSize: isMobile ? "12px" : "16px", letterSpacing: "0.22em", color: "white", textTransform: "uppercase" as const, fontWeight: 700, textDecoration: "none" }}>{t.common.nav.logo}</Link>
        {isMobile ? (
          <button onClick={() => setMenuOpen(!menuOpen)} style={{ background: "none", border: "none", color: "white", fontSize: "20px", cursor: "pointer", padding: "8px" }}>{menuOpen ? "✕" : "☰"}</button>
        ) : (
          <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
            <NavCoursesDropdown isMobile={false} />
            {[
              { label: t.common.nav.trainings, href: "/corporate" },
              { label: t.common.nav.production, href: "/production" },
              { label: t.common.nav.contact, href: CTA_URL, external: true },
            ].map((item, i) => (
              <a key={item.label} href={item.href} target={(item as any).external ? "_blank" : undefined} rel={(item as any).external ? "noopener noreferrer" : undefined}
                style={{ fontFamily: it, fontSize: "13px", color: i === 2 ? "#111" : "rgba(255,255,255,0.6)", textDecoration: "none", padding: "8px 18px", background: i === 2 ? "white" : "transparent", letterSpacing: "0.03em" }}
              >{item.label}</a>
            ))}
          </div>
        )}
      </nav>

      {/* Mobile menu */}
      {isMobile && menuOpen && (
        <div style={{ position: "fixed", top: "56px", left: 0, right: 0, background: "rgba(10,10,20,0.95)", backdropFilter: "blur(12px)", zIndex: 49, borderBottom: `1px solid ${BORDER}`, padding: "20px" }}>
          {[
            { label: t.common.coursesDropdown.aiPhoto, href: "/photo" },
            { label: t.common.coursesDropdown.aiCreator, href: "/video" },
            { label: t.common.nav.trainings, href: "/corporate" },
            { label: t.common.nav.production, href: "/production" },
            { label: t.common.nav.contact, href: CTA_URL },
          ].map((item, i) => (
            <Link key={item.label} href={item.href} onClick={() => setMenuOpen(false)} style={{ display: "block", fontFamily: it, fontSize: "15px", color: "rgba(255,255,255,0.7)", textDecoration: "none", padding: "14px 0", borderBottom: i < 4 ? `1px solid ${BORDER}` : "none" }}>{item.label}</Link>
          ))}
        </div>
      )}

      {/* ══ HERO ══ */}
      <section style={{ position: "relative", minHeight: isMobile ? "600px" : "700px", background: "#06060f", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center", paddingTop: isMobile ? "100px" : "68px", paddingBottom: isMobile ? "80px" : "0" }}>
        <div style={{ position: "absolute", inset: 0, opacity: 0.015, backgroundImage: "radial-gradient(rgba(255,255,255,0.8) 1px, transparent 1px)", backgroundSize: "28px 28px" }} />
        {!isMobile && (
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "stretch", marginLeft: "-60px", marginRight: "-60px" }}>
            {heroBgCards.map((card, i) => <HeroBgCard key={i} card={card} />)}
          </div>
        )}
        {isMobile && (
          <div style={{ position: "absolute", inset: 0 }}>
            <video src={heroBgCards[0].video} autoPlay loop muted playsInline style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.4 }} />
          </div>
        )}
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: isMobile ? "80px" : "180px", background: "linear-gradient(to bottom, transparent, #06060f)", pointerEvents: "none", zIndex: 5 }} />
        {!isMobile && <div style={{ position: "absolute", top: "68px", left: 0, right: 0, height: "80px", background: "linear-gradient(to bottom, #06060f, transparent)", pointerEvents: "none", zIndex: 5 }} />}
        <div style={{ position: "relative", zIndex: 10, textAlign: "center" as const, maxWidth: "700px", padding: isMobile ? "0 20px" : "0 40px" }}>
          <div style={{ fontFamily: it, fontSize: isMobile ? "12px" : "11px", color: "rgba(255,255,255,0.25)", letterSpacing: "0.28em", textTransform: "uppercase" as const, marginBottom: isMobile ? "12px" : "18px" }}>{t.production.hero.label}</div>
          <div style={{ display: "inline-block", fontFamily: it, fontSize: isMobile ? "12px" : "11px", color: ACCENT, border: `1px solid ${ACCENT}40`, padding: "3px 12px", marginBottom: isMobile ? "20px" : "24px", letterSpacing: "0.14em", textTransform: "uppercase" as const }}>{t.production.hero.badge}</div>
          <h1 style={{ fontFamily: os, fontSize: isMobile ? "42px" : "96px", color: "white", textTransform: "uppercase" as const, lineHeight: 0.87, marginBottom: isMobile ? "20px" : "28px", fontWeight: 700, textShadow: "0 0 60px rgba(220,120,90,0.15)" }}>
            {t.production.hero.title}
          </h1>
          <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "18px", color: "rgba(255,255,255,0.4)", marginBottom: isMobile ? "28px" : "44px", lineHeight: 1.65 }}>
            {t.production.hero.subtitle}
          </p>
          <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: ACCENT, color: "white", padding: isMobile ? "16px 32px" : "18px 52px", fontFamily: os, fontSize: isMobile ? "14px" : "15px", letterSpacing: "0.1em", textDecoration: "none", textTransform: "uppercase" as const, minHeight: isMobile ? "48px" : "auto", width: isMobile ? "100%" : "auto", textAlign: "center" as const }}>
            {t.production.hero.cta}
          </a>
        </div>
      </section>

      {/* ══ STATS ══ */}
      <section style={{ background: BG2, padding: isMobile ? "40px 20px" : "88px 56px", borderBottom: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "grid", gridTemplateColumns: isMobile ? "repeat(2,1fr)" : "repeat(4,1fr)", gap: isMobile ? "24px 0" : "0" }}>
          {t.production.stats.map((s, i) => (
            <div key={i} style={{ padding: isMobile ? (i % 2 === 0 ? "0" : "0 0 0 20px") : "0 0 0 40px", borderLeft: isMobile ? (i % 2 === 1 ? `1px solid ${BORDER}` : "none") : (i > 0 ? `1px solid ${BORDER}` : "none") }}>
              <div style={{ fontFamily: os, fontSize: isMobile ? "40px" : "72px", color: "white", lineHeight: 1, fontWeight: 700 }}>{s.n}</div>
              <div style={{ fontFamily: it, fontSize: isMobile ? "12px" : "15px", color: "rgba(255,255,255,0.28)", marginTop: isMobile ? "6px" : "10px" }}>{s.l}</div>
            </div>
          ))}
        </div>
      </section>

      <DirectionsCarousel />
      <WhyAI />
      <Pricing />
      <Roadmap />
      <Deliverables />
      <PortfolioCarousel />
      <FAQSection />

      {/* ══ FINAL CTA ══ */}
      <section style={{ background: BG2, padding: isMobile ? "60px 20px" : "160px 56px 140px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ maxWidth: "1200px", margin: "0 auto", display: "grid", gridTemplateColumns: isMobile ? "1fr" : "1fr 1fr", gap: isMobile ? "32px" : "80px", alignItems: "center" }}>
          <h2
            style={{ fontFamily: os, fontSize: isMobile ? "38px" : "96px", color: "white", lineHeight: 0.88, textTransform: "uppercase" as const, fontWeight: 700 }}
            dangerouslySetInnerHTML={{ __html: t.production.finalCta.heading }}
          />
          <div>
            <p style={{ fontFamily: it, fontSize: isMobile ? "15px" : "18px", color: "rgba(255,255,255,0.38)", lineHeight: 1.75, marginBottom: isMobile ? "24px" : "40px" }}>{t.production.finalCta.body}</p>
            <a href={CTA_URL} target="_blank" rel="noopener noreferrer" style={{ display: "inline-block", background: "white", color: "#111110", padding: isMobile ? "15px 32px" : "19px 48px", fontFamily: os, fontSize: isMobile ? "13px" : "15px", letterSpacing: "0.14em", textDecoration: "none", textTransform: "uppercase" as const }}>{t.production.finalCta.button}</a>
            <p style={{ fontFamily: it, fontSize: isMobile ? "12px" : "14px", color: "rgba(255,255,255,0.18)", marginTop: isMobile ? "16px" : "20px" }}>{t.production.finalCta.hint}</p>
          </div>
        </div>
      </section>

      {/* ══ FOOTER ══ */}
      <footer style={{ background: BG, padding: isMobile ? "28px 20px" : "36px 56px", borderTop: `1px solid ${BORDER}` }}>
        <div style={{ display: "flex", flexDirection: isMobile ? "column" : "row", justifyContent: "space-between", alignItems: "center", gap: isMobile ? "20px" : "0" }}>
          <div style={{ textAlign: isMobile ? "center" : "left" as const }}>
            <Link href="/" style={{ fontFamily: os, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.15)", letterSpacing: "0.2em", textTransform: "uppercase" as const, textDecoration: "none" }}>{t.common.nav.logo}</Link>
            <p style={{ fontFamily: it, fontSize: isMobile ? "10px" : "12px", color: "rgba(255,255,255,0.1)", marginTop: "4px" }}>{t.production.footer.tagline}</p>
          </div>
          <div style={{ display: "flex", gap: isMobile ? "16px" : "32px", flexWrap: "wrap" as const, justifyContent: "center" }}>
            {[
              { label: t.common.coursesDropdown.aiPhoto, href: "/photo" },
              { label: t.common.coursesDropdown.aiCreator, href: "/video" },
              { label: t.common.nav.trainings, href: "/corporate" },
              { label: t.common.footer.telegram, href: CTA_URL },
            ].map(item => (
              <Link key={item.label} href={item.href} style={{ fontFamily: it, fontSize: isMobile ? "11px" : "13px", color: "rgba(255,255,255,0.18)", textDecoration: "none" }}>{item.label}</Link>
            ))}
          </div>
          <span style={{ fontFamily: it, fontSize: isMobile ? "10px" : "12px", color: "rgba(255,255,255,0.1)", textAlign: "center" as const }}>{t.common.footer.copyrightFull}</span>
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: "24px", marginTop: "20px", paddingTop: "16px", borderTop: `1px solid ${BORDER}` }}>
          <Link href="/terms" style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", textDecoration: "none" }}>Условия использования</Link>
          <Link href="/privacy" style={{ fontFamily: it, fontSize: "11px", color: "rgba(255,255,255,0.25)", textDecoration: "none" }}>Политика конфиденциальности</Link>
        </div>
      </footer>

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;700&family=Inter:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
      `}</style>
    </main>
  )
}